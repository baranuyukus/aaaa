import { FirebaseMessagingService } from '@aginix/nestjs-firebase-admin';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import {
  Notification,
  NotificationDocument,
} from 'src/schemas/notification.schema';
import { User, UserDocument } from 'src/schemas/user.schema';

@Injectable()
export class NotificationService {
  constructor(
    @InjectModel(User.name)
    private readonly userModel: Model<UserDocument>,
    @InjectModel(Notification.name)
    private readonly notificationModel: Model<NotificationDocument>, // private readonly firebaseMessaging: FirebaseMessagingService,
  ) {}

  async getNotifications(userId: ObjectId) {
    await this.notificationModel
      .updateMany(
        {
          user: userId,
        },
        {
          projection: {
            _id: 1,
          },
        },
      )
      .lean();

    return this.notificationModel
      .find({
        user: userId,
      })
      .populate({
        path: 'advert',
        populate: 'productGroup',
      })
      .lean();
  }

  getUnseenNotificationCount(userId: ObjectId) {
    return this.notificationModel.count({
      user: userId,
      seen: false,
    });
  }

  async setNotificationToken(currentUserId: ObjectId, setNotificationToken) {
    const user = await this.userModel.findById(currentUserId);

    user.notificationToken = setNotificationToken.notificationToken;

    await user.save();

    return user;
  }

  async sendNotification({ title, body, userId, advert }) {
    try {
      const user = await this.userModel
        .findById(userId, { notificationToken: 1 })
        .lean();

      await this.notificationModel.create({
        title,
        body: body,
        user: userId,
        advert,
      });

      /* await this.firebaseMessaging
        .send({
          notification: {
            title,
            body,
          },
          android: {
            notification: {
              defaultSound: true,
            },
          },
          data: {},
          apns: {
            payload: {
              aps: {
                sound: 'default',
              },
            },
          },
          token: user.notificationToken,
        })
        .then((x) => {
          console.log('x', x);
        }); */

      return { success: true };
    } catch (error) {}
  }
}
