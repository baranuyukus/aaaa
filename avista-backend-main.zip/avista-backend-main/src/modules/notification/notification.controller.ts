import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { NotificationService } from './notification.service';
import { CurrentUser } from 'src/decorators/current-user';

@UseGuards(JwtAuthGuard)
@Controller('notification')
export class NotificationController {
  constructor(private readonly notificationService: NotificationService) {}

  @Get()
  getNotifications(@CurrentUser() currentUser) {
    return this.notificationService.getNotifications(currentUser._id);
  }

  @Get('unseen-count')
  getUnseenNotificationCount(@CurrentUser() currentUser) {
    return this.notificationService.getUnseenNotificationCount(currentUser._id);
  }

  @Post('token')
  setNotificationToken(
    @CurrentUser() currentUser,
    @Body() setNotificationTokenDto,
  ) {
    return this.notificationService.setNotificationToken(
      currentUser._id,
      setNotificationTokenDto,
    );
  }
}
