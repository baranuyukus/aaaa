import {
  Body,
  Controller,
  Get,
  Post,
  Param,
  Put,
  Delete,
  Query,
  UseGuards,
} from '@nestjs/common';
import { PanelService } from './panel.service';
import { Product } from 'src/schemas/product/product.schema';
import { CreateProductDto } from './dto/create-product.dto';
import { Brand } from 'src/schemas/brand.schema';
import { CreateBrandDto } from './dto/create-brand.dto';
import { UpdateBrandDto } from './dto/update-brand.dto';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';
import { Category } from 'src/schemas/category.schema';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { UpdateFeesDto } from '../user/dto/update-fees-dto';

@UseGuards(JwtAuthGuard)
@Controller('panel')
export class PanelController {
  constructor(private panelService: PanelService) { }

  @Post('/contactUs')
  contactUs(@Body() body: any) {
    return this.panelService.contactUs(body);
  }

  @Get('/statistics')
  getStatistics(@CurrentUser() currentUser, @Query() query) {
    return this.panelService.getStatistics(currentUser._id, query);
  }

  @Get('/sutok-products')
  getSutokProducts(@CurrentUser() currentUser, @Query() query) {
    return this.panelService.getSutokProducts(currentUser?._id, query);
  }

  @Get('/sutok-products-counts')
  getSutokProductsCounts(@CurrentUser() currentUser) {
    return this.panelService.getSutokProductsCounts(currentUser?._id);
  }

  @Get('/home-sections')
  findAllHomeSections(@Query() query) {
    return this.panelService.findAllHomeSections(query);
  }

  @Post('/home-sections')
  createHomeSection(@Body() dto) {
    return this.panelService.createHomeSection(dto);
  }

  @Put('/home-sections/order-swap')
  swapHomeSections(@Body() dto) {
    return this.panelService.swapHomeSections(dto);
  }

  @Put('/home-sections/:id')
  updateHomeSection(@Param('id') sectionId: ObjectId, @Body() dto) {
    return this.panelService.updateHomeSection(sectionId, dto);
  }

  @Delete('/home-sections/:id')
  deleteHomeSection(@Param('id') sectionId: ObjectId) {
    return this.panelService.deleteHomeSection(sectionId);
  }

  @Get('/product-groups')
  findAllProductGroups(@CurrentUser() currentUser, @Query() query) {
    return this.panelService.findAllProductGroups(currentUser._id, query);
  }

  @Get('/product-detail/:id')
  getProductGroupDetails(@Param("id") groupId: ObjectId) {
    return this.panelService.getProductGroupDetails(groupId);
  }

  @Get('/group-attributes/:groupId')
  getGroupAttributes(
    @Param('groupId', new ParseObjectIdPipe()) groupId: ObjectId,
  ) {
    return this.panelService.getGroupAttributes(groupId);
  }

  @Get('/products/:groupId')
  findAllProducts(
    @Param('groupId', new ParseObjectIdPipe()) groupId: ObjectId,
    @Query() query,
  ) {
    return this.panelService.findAllProducts(groupId, query);
  }

  @Get('/products/:id')
  findProductById(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<Product> {
    return this.panelService.findProductById(id);
  }

  @Get('/products/brand/:id')
  findProductsByBrandId(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.panelService.findProductsByBrandId(id);
  }

  @Post('/products')
  createProduct(@CurrentUser() currentUser, @Body() product: CreateProductDto): Promise<Product> {
    return this.panelService.createProduct(currentUser._id, product);
  }

  @Put('/products/:id')
  updateProduct(
    @CurrentUser() currentUser,
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
    @Body() body: { terms: { size: any, color: any }, product: CreateProductDto },
  ) {
    return this.panelService.updateProduct(currentUser._id, id, body.product, body.terms);
  }

  @Post('/products/delete/:id')
  deleteProduct(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<{ message: string }> {
    return this.panelService.deleteProduct(id);
  }

  @Get('/brands')
  findAllBrands(@Query() query) {
    return this.panelService.findAllBrands(query);
  }

  @Get('/brands/popular')
  findPopularBrands(): Promise<Brand[]> {
    return this.panelService.findPopularBrands();
  }

  @Get('/brands/:id')
  findBrandById(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<Brand> {
    return this.panelService.findBrandById(id);
  }

  @Post('/brands')
  createBrand(@Body() brand: CreateBrandDto): Promise<Brand> {
    return this.panelService.createBrand(brand);
  }

  @Put('/brands/:id')
  updateBrand(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
    @Body() brand: UpdateBrandDto,
  ): Promise<Brand> {
    return this.panelService.updateBrand(id, brand);
  }

  @Post('/brands/delete/:id')
  deleteBrand(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<{ message: string }> {
    return this.panelService.deleteBrand(id);
  }

  @Get('/sliders')
  listSliders() {
    return this.panelService.listSliders();
  }

  @Post('/sliders')
  createSlider(@Body() createSliderDto) {
    return this.panelService.createSlider(createSliderDto);
  }

  @Put('/sliders/:sliderId')
  updateSlider(@Param('sliderId') sliderId: ObjectId, @Body() updateSliderDto) {
    return this.panelService.updateSlider(sliderId, updateSliderDto);
  }

  @Post('/sliders/delete/:sliderId')
  deleteSlider(@Param('sliderId') sliderId: ObjectId) {
    return this.panelService.deleteSlider(sliderId);
  }

  @Get('/users')
  listUsers(@Query() query) {
    return this.panelService.listUsers(query);
  }

  @Get('/users/:userId')
  getUserById(@Param('userId') userId: ObjectId) {
    return this.panelService.getUserById(userId);
  }

  @Post('/delete-users/:userId')
  deleteUser(@Param('userId') userId: ObjectId) {
    return this.panelService.deleteUser(userId);
  }

  @Post('/users/')
  createUser(@Body() createUserDto) {
    return this.panelService.createUser(createUserDto);
  }

  @Put('/users/:userId')
  updateUser(@Param('userId') userId: ObjectId, @Body() updateUserDto) {
    return this.panelService.updateUser(userId, updateUserDto);
  }

  @Put('/users/:userId/verify')
  verifyUser(@Param('userId') userId: ObjectId) {
    return this.panelService.verifyUser(userId);
  }

  @Put('/users/:userId/deny')
  denyUser(@Param('userId') userId: ObjectId) {
    return this.panelService.denyUser(userId);
  }

  @Get('/orders')
  listOrders(@CurrentUser() currentUser, @Query() query) {
    return this.panelService.listOrders(currentUser._id, query);
  }

  @Get('/order/:id')
  getOrderDetails(@Param("id") id: string) {
    return this.panelService.getOrderDetails(id);
  }

  @Put('/orders/update/:orderId')
  updateOrder(
    @Param('orderId', new ParseObjectIdPipe()) orderId: ObjectId,
    @Body() body,
  ) {
    return this.panelService.updateOrder(orderId, body);
  }

  @Get('/group')
  listGroup() {
    return this.panelService.listGroup();
  }

  @Post('/group')
  createGroup(@CurrentUser() currentUser, @Body() createGroupDto) {
    return this.panelService.createGroup(currentUser._id, createGroupDto);
  }

  @Post('/group/copy-variant')
  copyVariant(@Body() dto) {
    return this.panelService.copyVariant(dto);
  }

  @Put('/group/:id')
  updateGroup(@Param('id') groupId: ObjectId, @Body() updateGroupDto) {
    return this.panelService.updateGroup(groupId, updateGroupDto);
  }

  @Delete('/group/:id')
  deleteGroup(@Param('id') groupId: ObjectId) {
    return this.panelService.deleteGroup(groupId);
  }

  @Get('/attribute')
  listAttribute(@Query() query) {
    return this.panelService.listAttribute(query);
  }

  @Post('/attribute')
  createAttribute(@Body() createAttributeDto) {
    return this.panelService.createAttribute(createAttributeDto);
  }

  @Put('/attribute/:id')
  updateAttribute(
    @Param('id') attributeId: ObjectId,
    @Body() updateAttributeDto,
  ) {
    return this.panelService.updateAttribute(attributeId, updateAttributeDto);
  }

  @Post('/attribute/delete/:id')
  deleteAttribute(@Param('id') attributeId: ObjectId) {
    return this.panelService.deleteAttribute(attributeId);
  }

  @Get('/terms/:attributeId')
  listTerm(@Param('attributeId') attributeId: ObjectId, @Query() query) {
    return this.panelService.listTerm(attributeId, query);
  }

  @Post('/terms')
  createTerm(@Body() createTermDto) {
    return this.panelService.createTerm(createTermDto);
  }

  @Put('/terms/:id')
  updateTerm(@Param('id') termId: ObjectId, @Body() updateTermDto) {
    return this.panelService.updateTerm(termId, updateTermDto);
  }

  @Post('/terms/delete/:id')
  deleteTerm(@Param('id') termId: ObjectId) {
    return this.panelService.deleteTerm(termId);
  }

  @Get('/models')
  findAllModels(@CurrentUser() currentUser,@Query() query) {
    return this.panelService.findAllModels(currentUser?._id,query);
  }

  @Get('/getModelDetails/:id')
  getModelDetails(@Param("id") id: any) {
    return this.panelService.getModelDetails(id);
  }

  @Post('/models')
  createModel(@Body() dto) {
    return this.panelService.createModel(dto);
  }

  @Put('/models/:id')
  updateModel(@Param('id', new ParseObjectIdPipe()) id: ObjectId, @Body() dto) {
    return this.panelService.updateModel(id, dto);
  }

  @Post('/models/delete/:id')
  deleteModel(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.panelService.deleteModel(id);
  }

  @Get('/categories')
  findAllCategories(@Query() query) {
    return this.panelService.findAllCategories(query);
  }

  @Get('/categories/:id')
  findCategoryById(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<Category> {
    return this.panelService.findCategoryById(id);
  }

  @Post('/categories')
  createCategory(@Body() category): Promise<Category> {
    return this.panelService.createCategory(category);
  }

  @Put('/categories/order-swap')
  swapOrders(@Body() dto) {
    return this.panelService.swapOrders(dto);
  }

  @Put('/categories/:id')
  updateCategory(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
    @Body() dto,
  ) {
    return this.panelService.updateCategory(id, dto);
  }

  @Post('/categories/delete/:id')
  deleteCategory(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<{ message: string }> {
    return this.panelService.deleteCategory(id);
  }

  @Get('/sellers')
  listSellers(@Query() query) {
    return this.panelService.listSellers(query);
  }

  @Get('/userDetail/:id')
  getUserDetail(@Param("id") id: ObjectId) {
    return this.panelService.getUserDetail(id);
  }

  @Get('/userOrders')
  getUserOrders(@Query() query) {
    return this.panelService.getUserOrders(query);
  }

  @Get('/sales')
  listSales(@Query() query) {
    return this.panelService.listSales(query);
  }

  @Get('/offers')
  listOffers(@Query() query) {
    return this.panelService.listOffers(query);
  }

  @Get('/advert/:id')
  getAdvert(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.panelService.getAdvert(id);
  }

  @Get('/adverts')
  listAdverts(@Query() query) {
    return this.panelService.listAdverts(query);
  }

  @Get('/sale-settings')
  getSaleSettings() {
    return this.panelService.getSaleSettings();
  }

  @Put('/sale-settings')
  updateSaleSettings(@Body() dto) {
    return this.panelService.updateSaleSettings(dto);
  }

  @Get('articles')
  listArticles(@Query() query) {
    return this.panelService.listArticles(query)
  }

  @Get('articles/:id')
  getArticle(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.panelService.getArticle(id)
  }

  @Post('articles')
  createArticle(@Body() dto) {
    return this.panelService.createArticle(dto)
  }

  @Put('articles/:id')
  updateArticle(@Body() dto, @Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.panelService.updateArticle(id, dto)
  }

  @Delete('articles/:id')
  deleteArticle(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.panelService.deleteArticle(id)
  }

  @Put('/agreement')
  updateAgreementContent(@Body() dto) {
    return this.panelService.updateAgreementContent(dto);
  }

  @Get('/agreement/:type')
  getAgreementContent(@Param('type') type: string) {
    return this.panelService.getAgreementContent(type);
  }

  @Post('/updateUserFees')
  updateUserFees(@Body() body: UpdateFeesDto) {
    return this.panelService.updateUserFees(body);
  }

  @Post('/increaseStock')
  increaseStock(@Body() body: any) {
    return this.panelService.increaseStock(body);
  }

  @Get('/getCargos')
  getCargos(@Query() query) {
    return this.panelService.getCargos(query);
  }

  @Post('/createUserComment')
  createUserComment(@Body() body: any): Promise<Boolean> {
    return this.panelService.createUserComment(body);
  }

  @Get('/listVariants/:id')
  listVariants(@Param("id") groupId) {
    return this.panelService.listVariants(groupId);
  }

  @Get('/listAllProductattributes')
  listAllProductattributes() {
    return this.panelService.listAllProductattributes();
  }

  @Get('/listAllProductattributeterms/:id')
  listAllProductattributeterms(@Param("id") attributeId: string) {
    return this.panelService.listAllProductattributeterms(attributeId);
  }

  @Get('/getTerm/:id')
  getTerm(@Param("id") id) {
    return this.panelService.getTerm(id);
  }

  @Get('/sellerPayments')
  listAllSellerPayment(@CurrentUser() currentUser, @Query() query) {
    return this.panelService.listAllSellerPayment(currentUser?._id, query);
  }

  @Get('/sellerPayments/:id')
  getSellerPayment(@Param("id") id) {
    return this.panelService.getSellerPayment(id);
  }

  @Post('/sellerPayments')
  createSellerPayment(@Body() body) {
    return this.panelService.createSellerPayment(body);
  }

  @Put('/sellerPayments/:id')
  updateSellerPayment(@Param("id") paymentRequestId, @Body() body: any) {
    return this.panelService.updateSellerPayment(paymentRequestId, body);
  }

  @Get("/productsPendingApproval")
  listProductsPendingApproval(@Query() query) {
    console.log(query)
    return this.panelService.listProductsPendingApproval(query);
  }

  @Post('/productsPendingApproval')
  createProductsPendingApproval(@CurrentUser() currentUser, @Body() body) {
    return this.panelService.createProductsPendingApproval(currentUser?._id, body);
  }

  @Delete('/productsPendingApproval/:id')
  deleteProductsPendingApproval(@Param("id") id) {
    return this.panelService.deleteProductsPendingApproval(id);
  }

  @Get('/updateAllOrders')
  updateAllOrders() {
    return this.panelService.updateAllOrders();
  }

  @Get('/sellerRequests')
  listSellerRequests(@Query() query) {
    return this.panelService.listSellerRequests(query);
  }

  @Get('/sellerRequests/:id')
  getSellerRequest(@Param("id") id) {
    return this.panelService.getSellerRequest(id);
  }

  @Put('/sellerRequests/:id')
  updateSellerRequest(@Param("id") id, @Body() body) {
    return this.panelService.updateSellerRequest(id, body);
  }

  @Delete('/sellerRequests/:id')
  deleteSellerRequest(@Param("id") id) {
    return this.panelService.deleteSellerRequest(id);
  }
}
