import { Module } from '@nestjs/common';
import { PanelController } from './panel.controller';
import { PanelService } from './panel.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Product, ProductSchema } from '../../schemas/product/product.schema';
import { Brand, BrandSchema } from 'src/schemas/brand.schema';
import { User, UserSchema } from 'src/schemas/user.schema';
import { Order, OrderSchema } from 'src/schemas/order.schema';
import {
  ProductGroup,
  ProductGroupSchema,
} from 'src/schemas/product/product-group.schema';
import {
  ProductAttribute,
  ProductAttributeSchema,
} from 'src/schemas/product/product-attribute.schema';
import {
  ProductAttributeTerm,
  ProductAttributeTermSchema,
} from 'src/schemas/product/product-attribute-term.schema';
import { Category, CategorySchema } from 'src/schemas/category.schema';
import { Slider, SliderSchema } from 'src/schemas/slider.schema';
import { Advert, AdvertSchema } from 'src/schemas/advert.schema';
import { Offer, OfferSchema } from 'src/schemas/offer.schema';
import {
  SaleSettings,
  SaleSettingsSchema,
} from 'src/schemas/sale-settings.schema';
import {
  ProductModel,
  ProductModelSchema,
} from 'src/schemas/product-model.schema';
import {
  HomeSection,
  HomeSectionSchema,
} from 'src/schemas/home-section.schema';
import { Article, ArticleSchema } from 'src/schemas/article.schema';
import { Agreements, AgreementsSchema } from 'src/schemas/agreements.schema';
import { ConfigService } from '@nestjs/config';
import { MailerModule } from '@nestjs-modules/mailer';
import { Cargo, CargoSchema } from 'src/schemas/cargo.schema';
import { Address, AddressSchema } from 'src/schemas/address.schema';
import { Payment, PaymentSchema } from 'src/schemas/payment.schema';
import { Comment, CommentSchema } from 'src/schemas/comment.schema';
import { SellerPayment, SellerPaymentSchema } from 'src/schemas/seller-payments.schema';
import { ProductsPendingApproval, ProductsPendingApprovalSchema } from 'src/schemas/productsPendingApproval';
import { SellerRequests, SellerRequestsSchema } from 'src/schemas/sellerRequests.schema';

@Module({
  imports: [
    MailerModule.forRootAsync({
      useFactory: async (configService: ConfigService) => ({
        transport: {
          host: configService.get<string>('SMTP_HOST'),
          port: configService.get<number>('SMTP_PORT'),
          secure: false, // upgrade later with STARTTLS
          auth: {
            user: configService.get<string>('SMTP_USER'),
            pass: configService.get<string>('SMTP_PASSWORD'),
          },
          tls: {
            // do not fail on invalid certs
            rejectUnauthorized: false,
          },
        },
      }),
      inject: [ConfigService],
    }),
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Order.name, schema: OrderSchema },
      { name: Cargo.name, schema: CargoSchema },
      { name: Brand.name, schema: BrandSchema },
      { name: ProductGroup.name, schema: ProductGroupSchema },
      { name: Product.name, schema: ProductSchema },
      { name: ProductAttribute.name, schema: ProductAttributeSchema },
      { name: ProductAttributeTerm.name, schema: ProductAttributeTermSchema },
      { name: Category.name, schema: CategorySchema },
      { name: Slider.name, schema: SliderSchema },
      { name: Advert.name, schema: AdvertSchema },
      { name: Offer.name, schema: OfferSchema },
      { name: SaleSettings.name, schema: SaleSettingsSchema },
      { name: ProductModel.name, schema: ProductModelSchema },
      { name: HomeSection.name, schema: HomeSectionSchema },
      { name: Article.name, schema: ArticleSchema },
      { name: Agreements.name, schema: AgreementsSchema },
      { name: Address.name, schema: AddressSchema },
      { name: Payment.name, schema: PaymentSchema },
      { name: Comment.name, schema: CommentSchema },
      { name: SellerPayment.name, schema: SellerPaymentSchema },
      { name: ProductsPendingApproval.name, schema: ProductsPendingApprovalSchema },
      { name: SellerRequests.name, schema: SellerRequestsSchema },
    ]),
  ],
  controllers: [PanelController],
  providers: [PanelService],
})
export class PanelModule { }
