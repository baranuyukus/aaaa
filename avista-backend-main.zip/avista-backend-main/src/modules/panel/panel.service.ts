import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { Brand, BrandDocument } from 'src/schemas/brand.schema';
import { Product, ProductDocument } from '../../schemas/product/product.schema';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { User, UserDocument } from 'src/schemas/user.schema';
import { Order, OrderDocument } from 'src/schemas/order.schema';
import { CreateProductDto } from './dto/create-product.dto';
import { CreateBrandDto } from './dto/create-brand.dto';
import {
  ProductGroup,
  ProductGroupDocument,
} from 'src/schemas/product/product-group.schema';
import {
  ProductAttribute,
  ProductAttributeDocument,
} from 'src/schemas/product/product-attribute.schema';
import {
  ProductAttributeTerm,
  ProductAttributeTermDocument,
} from 'src/schemas/product/product-attribute-term.schema';
import { Category, CategoryDocument } from 'src/schemas/category.schema';
import { v4 as uuidv4 } from 'uuid';
import { FirebaseMessagingService } from '@aginix/nestjs-firebase-admin';
import { Slider, SliderDocument } from 'src/schemas/slider.schema';
import { Advert, AdvertDocument } from 'src/schemas/advert.schema';
import { Offer, OfferDocument } from 'src/schemas/offer.schema';
import {
  SaleSettings,
  SaleSettingsDocument,
} from 'src/schemas/sale-settings.schema';
import {
  ProductModel,
  ProductModelDocument,
} from 'src/schemas/product-model.schema';
import {
  HomeSection,
  HomeSectionDocument,
} from 'src/schemas/home-section.schema';
import moment from 'moment';
import 'moment/locale/tr';
import { Article, ArticleDocument } from 'src/schemas/article.schema';
import { Agreements, AgreementsDocument } from 'src/schemas/agreements.schema';
import { UpdateFeesDto } from '../user/dto/update-fees-dto';
import { MailerService } from '@nestjs-modules/mailer';
import { ConfigService } from '@nestjs/config';
import { CargoDocument } from 'src/schemas/cargo.schema';
import { Address, AddressDocument } from 'src/schemas/address.schema';
import { Payment, PaymentDocument } from 'src/schemas/payment.schema';
import { CreateCommentDto } from '../comment/dto/create-comment.dto';
import { Comment, CommentDocument } from 'src/schemas/comment.schema';
import { SellerPayment, SellerPaymentDocument } from 'src/schemas/seller-payments.schema';
import { nanoid } from 'nanoid';
import slugify from 'slugify';
import getEmailTemplate from 'src/utils/emailTemplate';
import axios from 'axios';
import { ProductsPendingApproval, ProductsPendingApprovalDocument } from 'src/schemas/productsPendingApproval';
import sutokAddress from 'src/utils/sutokAddress';
import { SellerRequests, SellerRequestsDocument } from 'src/schemas/sellerRequests.schema';

@Injectable()
export class PanelService {
  constructor(
    private readonly configService: ConfigService,
    private readonly mailerService: MailerService,
    @InjectModel(ProductGroup.name)
    private readonly productGroupModel: Model<ProductGroupDocument>,
    @InjectModel(Product.name)
    private readonly productModel: Model<ProductDocument>,
    @InjectModel(ProductAttribute.name)
    private readonly productAttributeModel: Model<ProductAttributeDocument>,
    @InjectModel(ProductAttributeTerm.name)
    private readonly productAttributeTermModel: Model<ProductAttributeTermDocument>,
    @InjectModel(Brand.name)
    private readonly brandModel: Model<BrandDocument>,
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
    @InjectModel(Order.name) private readonly orderModel: Model<OrderDocument>,
    @InjectModel(Order.name) private readonly cargoModel: Model<CargoDocument>,
    @InjectModel(ProductModel.name)
    private readonly productModelModel: Model<ProductModelDocument>,
    @InjectModel(Category.name)
    private readonly categoryModel: Model<CategoryDocument>,
    @InjectModel(Slider.name)
    private readonly sliderModel: Model<SliderDocument>,
    @InjectModel(Advert.name)
    private readonly advertModel: Model<AdvertDocument>,
    @InjectModel(Offer.name)
    private readonly offerModel: Model<OfferDocument>,
    @InjectModel(SaleSettings.name)
    private readonly saleSettingsModel: Model<SaleSettingsDocument>,
    @InjectModel(HomeSection.name)
    private readonly homeSectionsModel: Model<HomeSectionDocument>,
    @InjectModel(Article.name)
    private readonly articleModel: Model<ArticleDocument>,
    @InjectModel(Agreements.name)
    private readonly agreementsModel: Model<AgreementsDocument>,
    @InjectModel(Address.name)
    private readonly addressModel: Model<AddressDocument>,
    @InjectModel(Payment.name)
    private readonly paymentModel: Model<PaymentDocument>,
    @InjectModel(Comment.name)
    private readonly commentModel: Model<CommentDocument>,
    @InjectModel(SellerPayment.name)
    private readonly sellerPaymentModel: Model<SellerPaymentDocument>,
    @InjectModel(ProductsPendingApproval.name)
    private readonly productsPendingApprovalModel: Model<ProductsPendingApprovalDocument>,
    @InjectModel(SellerRequests.name)
    private readonly sellerRequestsModel: Model<SellerRequestsDocument>,
  ) { }

  async contactUs(body: any) {
    try {
      const html = `
    <h3>${body.subject}</h3>
    <h1>${body.message}</h1>
    `;

      await this.mailerService.sendMail({
        from: this.configService.get<string>('SMTP_USER'),
        to: this.configService.get<string>('SMTP_USER'),
        subject: `Sutok.com - ${body.subject} - ${body.from}`,
        html: html,
      });

      return await { success: true };
    } catch (error) {
      return await { success: false };
    }
  }

  async getStatistics(currentUserId, query) {
    try {
      // Kullanıcının rolünü belirle
      const { role } = await this.userModel
        .findById(currentUserId, { role: 1 })
        .lean();

      // Kullanıcının rolüne göre filtre oluştur
      const filter: any = {};
      const filterOrders: any = {};

      if (role === "SELLER") {
        filter.user = currentUserId;
        filterOrders.sellers = { $in: [currentUserId] };
      }

      let dateFilter: any = role !== "ADMIN" ? { sellers: { $in: [currentUserId] } } : {}; // Tarih filtresi için boş bir obje oluşturuldu
      let dateFilterForOrder: any = role !== "ADMIN" ? { sellers: { $in: [currentUserId] } } : {};
      let dateFilterForSutokAdvert: any = {};

      // statisticType'a göre tarih filtresini belirle
      switch (query.statisticType) {
        case 'daily':
          dateFilter = { ...dateFilter, createdAt: { $gte: moment().subtract(1, 'days').startOf('day').toDate() } };
          dateFilterForOrder = { ...dateFilterForOrder, updatedAt: { $gte: moment().subtract(1, 'days').startOf('day').toDate() } };
          dateFilterForSutokAdvert = { ...dateFilterForSutokAdvert, updatedAt: { $gte: moment().subtract(1, 'days').startOf('day').toDate() } };
          break;
        case 'weekly':
          dateFilter = { ...dateFilter, createdAt: { $gte: moment().startOf('week').toDate() } };
          dateFilterForOrder = { ...dateFilterForOrder, updatedAt: { $gte: moment().startOf('week').toDate() } };
          dateFilterForSutokAdvert = { ...dateFilterForSutokAdvert, updatedAt: { $gte: moment().startOf('week').toDate() } };
          break;
        case 'monthly':
          dateFilter = { ...dateFilter, createdAt: { $gte: moment().startOf('month').toDate() } };
          dateFilterForOrder = { ...dateFilterForOrder, updatedAt: { $gte: moment().startOf('month').toDate() } };
          dateFilterForSutokAdvert = { ...dateFilterForSutokAdvert, updatedAt: { $gte: moment().startOf('month').toDate() } };
          break;
        case 'yearly':
          dateFilter = { ...dateFilter, createdAt: { $gte: moment().startOf('year').toDate() } };
          dateFilterForOrder = { ...dateFilterForOrder, updatedAt: { $gte: moment().startOf('year').toDate() } };
          dateFilterForSutokAdvert = { ...dateFilterForSutokAdvert, updatedAt: { $gte: moment().startOf('year').toDate() } };
          break;
        case 'yesterday':
          dateFilter = { ...dateFilter, createdAt: { $gte: moment().subtract(1, 'days').startOf('day').toDate(), $lt: moment().startOf('day').toDate() } };
          dateFilterForOrder = { ...dateFilterForOrder, updatedAt: { $gte: moment().subtract(1, 'days').startOf('day').toDate(), $lt: moment().startOf('day').toDate() } };
          dateFilterForSutokAdvert = { ...dateFilterForSutokAdvert, updatedAt: { $gte: moment().subtract(1, 'days').startOf('day').toDate(), $lt: moment().startOf('day').toDate() } };
          break;
        default:
          dateFilter = { ...dateFilter, createdAt: { $gte: moment(query.statisticType).startOf('day').toDate() } };
          dateFilterForOrder = { ...dateFilterForOrder, updatedAt: { $gte: moment(query.statisticType).startOf('day').toDate() } };
          dateFilterForSutokAdvert = { ...dateFilterForSutokAdvert, updatedAt: { $gte: moment(query.statisticType).startOf('day').toDate() } };
      }

      /*console.log(dateFilter)
      console.log(dateFilterForOrder)
      console.log(dateFilterForSutokAdvert)*/
      // Alışveriş sayısını al
      const totalOrdersCount = await this.orderModel.count({
        ...filterOrders,
        status: 'PENDING',
        ...dateFilter
      });

      const totalOrdersForPending = await this.orderModel.count({
        ...filterOrders,
        status: 'PENDING',
        ...dateFilterForOrder
      });
      const totalOrdersForDelivered = await this.orderModel.count({
        ...filterOrders,
        status: 'DELIVERED',
        ...dateFilterForOrder
      });
      const totalOrdersForDeclined = await this.orderModel.count({
        ...filterOrders,
        status: 'DECLINED',
        ...dateFilterForOrder
      });
      const totalOrdersForShipped = await this.orderModel.count({
        ...filterOrders,
        status: 'SHIPPED',
        ...dateFilterForOrder
      });

      // Satılan reklamları al
      const soldAdverts = await this.advertModel
        .find(
          {
            status: { $ne: 'PENDING' },
            ...filter,
            ...dateFilter, // Tarih filtresini uygula
          },
          {
            price: 1,
            serviceFee: 1,
            commission: 1,
            finalAmount: 1,
            createdAt: 1,
          },
        )
        .lean();

      // Toplam satılan reklamları al
      const totalSoldAdverts = await this.advertModel.count({
        status: 'SOLD',
        ...filter,
        ...dateFilter, // Tarih filtresini uygula
      });

      // İstatistikleri topla
      const statistics = soldAdverts.reduce((prev, cur: any) => {
        const day = moment(cur.createdAt).format('DD MMM YYYY');
        const weeklyDay = prev.weekly[day];

        return {
          totalEarnings: prev.totalEarnings + cur.price,
          totalProfit: prev.totalProfit + cur.finalAmount,
          totalServiceFee: prev.totalServiceFee + cur.serviceFee,
          totalCommission: prev.totalCommission + cur.commission,
          weeklyTotal: prev.weeklyTotal + (weeklyDay ? cur.price : 0),
          weekly: {
            ...prev.weekly,
            [day]: {
              ...weeklyDay,
              totalEarnings: (weeklyDay ? weeklyDay.totalEarnings : 0) + cur.price,
              totalProfit: (weeklyDay ? weeklyDay.totalProfit : 0) + cur.finalAmount,
              totalServiceFee: (weeklyDay ? weeklyDay.totalServiceFee : 0) + cur.serviceFee,
              totalCommission: (weeklyDay ? weeklyDay.totalCommission : 0) + cur.commission,
              day
            },
          },
        };
      }, {
        totalEarnings: 0,
        totalProfit: 0,
        totalServiceFee: 0,
        totalCommission: 0,
        weeklyTotal: 0,
        weekly: {},
      });

      // Eğer özel istatistik alınıyorsa, sadece istenen tarih aralığını döndür
      if (query.statisticType === 'custom') {
        statistics.weekly = Object.keys(statistics.weekly)
          .filter(day => moment(day, 'DD MMM YYYY').isSameOrAfter(moment().subtract(30, 'days'), 'day'))
          .reduce((weekly, day) => {
            weekly[day] = statistics.weekly[day];
            return weekly;
          }, {});
      }

      return {
        totalSoldAdverts,
        totalOrdersCount,
        ...statistics,
        orders: { totalOrdersForPending, totalOrdersForDeclined, totalOrdersForDelivered, totalOrdersForShipped },
      };
    } catch (error) {
      console.error("An error occurred in getStatistics:", error);
      throw error;
    }
  }


  async getSutokProducts(currentUserId, query: any) {
    try {
      const { role } = await this.userModel
        .findById(currentUserId, { role: 1 })
        .lean();

      const skip = (query.page - 1) * query.limit
      let filter: any = {};
      let filterForAdvert: any = {};
      let totalPage: number;
      let aggregate: any = [];

      if (query?.productState === "allProducts") {
        totalPage = 0;
        filterForAdvert.status = 'PENDING'
        filterForAdvert.vacationMode = false
      } else if (query?.productState === "noStock") {
        filter.stockState = false
        totalPage = 0;
        filterForAdvert.status = 'PENDING'
        filterForAdvert.vacationMode = false
      } else if (query?.productState === "lowStock") {
        totalPage = 0;
        filter.stockState = true
        filter.variantCount = {
          $gt: 0,
        }
        filterForAdvert.status = 'PENDING'
        filterForAdvert.vacationMode = false
      } else if (query?.productState === "soldOut") {
        totalPage = 0;
        filterForAdvert.status = 'PENDING'
        filterForAdvert.vacationMode = false
      }

      if (role !== "ADMIN") {
        filter.createdBy = currentUserId;
        filterForAdvert.user = currentUserId;
      }

      aggregate = [
        {
          $match:
          {
            ...filter
          }
        },
        {
          $lookup: {
            from: this.advertModel.collection.name,
            localField: '_id',
            foreignField: 'productGroup',
            as: 'adverts',
            pipeline: [
              {
                $match: {
                  ...filterForAdvert
                }
              },
            ]
          }
        },
        {
          $addFields: {
            stock: { $size: "$adverts" }
          }
        },
      ];

      if (query?.productState === "lowStock") {
        aggregate = [...aggregate, {
          $match: {
            stock: { $lt: 10 } // Sadece 'stock' sayısı 0'dan büyük olan belgeleri döndür
          }
        }, { $sort: { stock: 1 } }]
      } else if (query?.productState === "soldOut") {
        aggregate = [...aggregate, {
          $lookup: {
            from: this.advertModel.collection.name,
            localField: '_id',
            foreignField: 'productGroup',
            as: 'soldAdverts',
            pipeline: [
              {
                $match: {
                  status: "SOLD",
                  vacationMode: false
                }
              },
            ]
          }
        },
        {
          $addFields: {
            sold: { $size: "$soldAdverts" }
          }
        }, {
          $match: {
            sold: { $gt: 0 } // Sadece 'stock' sayısı 0'dan büyük olan belgeleri döndür
          }
        }, { $sort: { sold: -1 } }]
      }
      aggregate = [...aggregate, { $skip: skip },
      { $limit: parseInt(query.limit) }]

      const result = await this.productGroupModel
        .aggregate(aggregate);

      const totalCount = await this.productGroupModel
        .aggregate(aggregate);

      await this.updateStockStates(result)

      return {
        pageData: result,
        totalPage,
      }
    } catch (error) {
      console.error("An error occurred in getSutokProducts:", error);
      throw error;
    }
  }

  async getSutokProductsCounts(currentUserId) {
    try {
      const { role } = await this.userModel
        .findById(currentUserId, { role: 1 })
        .lean();

      const filter: any = {};

      if (role !== "ADMIN") {
        filter.createdBy = currentUserId;
      }
      const totalCount = await this.productGroupModel.count(filter);
      const stockTotalCount = await this.productGroupModel.count({
        ...filter,
        stockState: true
      });
      const noStockCount = await this.productGroupModel.count({
        ...filter,
        stockState: false
      });
      const lowStockCount = await this.productGroupModel.aggregate([
        {
          $match:
          {
            ...filter,
            stockState: true,
            variantCount: {
              $gt: 0,
            }
          }
        },
        {
          $lookup: {
            from: this.advertModel.collection.name,
            localField: '_id',
            foreignField: 'productGroup',
            as: 'adverts',
            pipeline: [
              {
                $match: {
                  status: 'PENDING',
                  vacationMode: false
                }
              },
            ]
          }
        },
        {
          $addFields: {
            stock: { $size: "$adverts" }
          }
        },
        {
          $match: {
            stock: { $lt: 10 } // Sadece 'stock' sayısı 0'dan büyük olan belgeleri döndür
          }
        }, {
          $group: {
            _id: null, // Tüm belgeleri gruplamak için null kullanılır
            count: { $sum: 1 } // Her eşleşen belge için 1 ekleyerek toplam sayıyı hesaplar
          }
        }
      ]);

      const soldOutStockCount = await this.productGroupModel.aggregate([
        {
          $match:
          {
            ...filter,
          }
        },
        {
          $lookup: {
            from: this.advertModel.collection.name,
            localField: '_id',
            foreignField: 'productGroup',
            as: 'soldAdverts',
            pipeline: [
              {
                $match: {
                  status: "SOLD",
                  vacationMode: false
                }
              },
            ]
          }
        },
        {
          $addFields: {
            sold: { $size: "$soldAdverts" }
          }
        }, {
          $match: {
            sold: { $gt: 0 } // Sadece 'satış' sayısı 0'dan büyük olan belgeleri döndür
          }
        }, {
          $group: {
            _id: null, // Tüm belgeleri gruplamak için null kullanılır
            count: { $sum: 1 } // Her eşleşen belge için 1 ekleyerek toplam sayıyı hesaplar
          }
        }
      ]);

      return {
        totalCount,
        noStockCount,
        stockTotalCount,
        lowStockCount: lowStockCount[0].count,
        soldOutStockCount: soldOutStockCount[0].count,
      }
    } catch (error) {
      console.error("An error occurred in getSutokProducts:", error);
      throw error;
    }
  }

  async findAllHomeSections(query) {
    const filter: any = {};

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const searchKeywords = query.filterName.split(/\s+/).filter(Boolean);
      const andConditions = [
        {
          $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
        }
      ];

      filter.$and = [...(filter.$and || []), ...andConditions];
    }

    const totalHomeSections = await this.homeSectionsModel.count(filter);

    const page = await this.homeSectionsModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .populate({
        path: 'products',
        select: 'title',
      })
      .limit(10)
      .sort({
        order: 1,
      })
      .lean();

    return {
      totalHomeSections,
      page,
    };
  }

  async createHomeSection(dto) {
    const lastSection = await this.homeSectionsModel
      .findOne({}, { order: 1 })
      .sort({
        order: -1,
      })
      .lean();

    return this.homeSectionsModel.create({
      ...dto,
      order: (lastSection?.order || 0) + 1,
    });
  }

  updateHomeSection(sectionId: ObjectId, dto) {
    return this.homeSectionsModel.findByIdAndUpdate(sectionId, dto);
  }

  updateStockState(groupId: any, value: boolean) {
    return this.productGroupModel
      .findByIdAndUpdate(groupId, { stockState: value })
      .lean();
  }

  async updateStockStates(products) {
    products.map(async item => {
      const advert = await this.advertModel.findOne({
        productGroup: item._id,
        status: 'PENDING'
      });
      if (advert) {
        await this.productGroupModel.findByIdAndUpdate(item._id, {
          stockState: true
        })
      } else {
        await this.productGroupModel.findByIdAndUpdate(item._id, {
          stockState: false
        })
      }
    });
  }

  deleteHomeSection(sectionId: ObjectId) {
    return this.homeSectionsModel.findByIdAndDelete(sectionId);
  }

  async findAllProductGroups(userId: ObjectId, query) {
    const user = await this.userModel.findById(userId, { role: 1 }).lean();

    const filter: any = {};
    let sorted: any = null
    const skip = (parseInt(query.page) - 1) * 10;

    if (query.modelId) {
      filter.$or = [
        { models: new mongoose.Types.ObjectId(query.modelId) }
      ];
    }
    if (query.brandId) {
      filter.$or = [
        { brands: new mongoose.Types.ObjectId(query.brandId) }
      ];
    }
    if (query.categoryId) {
      filter.category = new mongoose.Types.ObjectId(query.categoryId);
    }
    if (user.role !== 'ADMIN') filter.createdBy = userId;
    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const searchKeywords = query.filterName.split(/\s+/).filter(Boolean);
      const andConditions = [
        {
          $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
        }
      ];

      filter.$and = [...(filter.$and || []), ...andConditions];
    }
    /*if (query.category) {
      filter.category = new mongoose.Types.ObjectId(query.category)
    }*/
    if (query.stock) {
      filter.stockState = query.stock === "stock" ? true : false
    }
    if (query.categoryLabel) {
      filter.category = query.categoryContaining === "true" ?
        new mongoose.Types.ObjectId(query.categoryLabel) :
        { $ne: new mongoose.Types.ObjectId(query.categoryLabel) }
    }
    if (query.modelLabel) {
      query.modelContaining === "true" ?
        filter.$or = [
          { models: new mongoose.Types.ObjectId(query.modelLabel) }
        ] :
        filter.$or = [
          { models: { $ne: new mongoose.Types.ObjectId(query.modelLabel) } }
        ]
    }
    if (query.brandLabel) {
      filter.brands = query.brandContaining === "true" ?
        [new mongoose.Types.ObjectId(query.brandLabel)] :
        { $ne: new mongoose.Types.ObjectId(query.brandLabel) }
    }

    if (query.modelId) {
      filter.$or = [
        { models: new mongoose.Types.ObjectId(query.modelId) }
      ];
    }
    /*if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      if (query.category) {
        filter.$and = [
          {
            title: { $regex: query.filterName, $options: 'i' },
          },
          {
            category: new mongoose.Types.ObjectId(query.category),
          },
        ];
      } else {
        filter.$or = [
          {
            title: { $regex: query.filterName, $options: 'i' },
          },
        ];
      }
    }
    if (query.category) {
      if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
        filter.$and = [
          {
            title: { $regex: query.filterName, $options: 'i' },
          },
          {
            category: new mongoose.Types.ObjectId(query.category),
          },
        ];
      } else {
        filter.$or = [
          {
            category: new mongoose.Types.ObjectId(query.category),
          },
        ];
      }
    }*/

    /*const page = await Promise.all((await this.productGroupModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .populate('brands', 'title')
      .populate('models', 'title')
      .limit(10)
      .lean())
      .map(async (item) => {
        const advertsCount = await this.advertModel.count({
          productGroup: item._id,
          status: "PENDING"
        })
        return {
          ...item,
          advertsCount
        }
      }));*/

    if (query?.sorted) {
      if (query.sorted === "price_asc") {
        sorted = { price: 1 }
      } else if (query.sorted === "price_desc") {
        sorted = { price: -1 }
      } else if (query.sorted === "stock_asc") {
        sorted = { advertsCount: 1 }
      } else if (query.sorted === "stock_desc") {
        sorted = { advertsCount: -1 }
      } else if (query.sorted === "new") {
        sorted = { createdAt: -1 }
      } else if (query.sorted === "old") {
        sorted = { createdAt: 1 }
      }
    }

    let aggregate = [
      {
        $match: {
          ...filter
        }
      },
      {
        $lookup: {
          from: this.advertModel.collection.name,
          localField: '_id',
          foreignField: 'productGroup',
          as: 'adverts',
          pipeline: [
            {
              $match: {
                status: "PENDING"
              }
            }
          ]
        }
      },
      {
        $addFields: {
          advertsCount: { $size: "$adverts" }
        }
      },
    ];

    const aggregateLimitAndSkip = [
      { $skip: skip },
      { $limit: parseInt(query.limit) },
    ]

    const page = await this.productGroupModel.aggregate(sorted ? [...aggregate, { $sort: sorted }, ...aggregateLimitAndSkip] : [...aggregate, ...aggregateLimitAndSkip]);

    await this.updateStockStates(page)

    const totalCount = await this.productGroupModel.count(filter)
    const totalPage = Math.ceil(totalCount / parseInt(query.limit))

    return {
      page,
      totalCount,
      totalPage
    };
  }

  async getProductGroupDetails(groupId: ObjectId) {
    const filter: any = {
      _id: new mongoose.Types.ObjectId(groupId)
    }

    const result = await this.productGroupModel.aggregate([
      {
        $match: filter
      }
    ]);

    return { productGroup: result[0] };
  }

  async getGroupAttributes(groupId: ObjectId) {
    const group = await this.productGroupModel
      .findById(groupId, { attributes: 1 })
      .populate('attributes')
      .lean();

    const terms = await this.productAttributeTermModel
      .find({
        attribute: group.attributes.map((item) => item._id),
      })
      .lean();

    return group.attributes.map((attribute) => {
      return {
        ...attribute,
        terms: terms.filter(
          (term) => term.attribute.toString() === attribute._id.toString(),
        ),
      };
    });
  }

  async findAllProducts(groupId: ObjectId, query) {
    const filter: any = {
      group: groupId,
    };

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      filter.$or = [
        {
          title: { $regex: query.filterName, $options: 'i' },
        },
      ];
    }

    const totalProducts = await this.productModel.count(filter);

    const page = await this.productModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .find()
      .populate('terms')
      .limit(10)
      .sort({ createdAt: -1 })
      .lean();

    return {
      totalProducts,
      page,
    };
  }

  async findProductById(id: ObjectId): Promise<Product> {
    const product = await this.productModel.findById(id);

    if (!product) {
      throw new NotFoundException(`Product not found`);
    }
    return product;
  }

  findProductsByBrandId(brandId: ObjectId) {
    return this.productModel.find({ brand: brandId });
  }

  async createProduct(currentUserId: ObjectId, product: CreateProductDto): Promise<Product> {
    const res = await this.productModel.create(product);

    const newVariantCount = await this.productModel.count({
      group: product.group,
    });

    await this.updateStockState(product.group, true);

    await this.productGroupModel
      .findByIdAndUpdate(
        product.group,
        {
          $set: {
            variantCount: newVariantCount,
          },
        },
        {
          projection: { _id: 1 },
        },
      )
      .lean();

    if (product.stock && product.price) {
      const saleSettings = await this.saleSettingsModel.findOne({});
      const currentUser = await this.userModel.findById(currentUserId);
      const productGroup = await this.productGroupModel.findById(product.group);

      const serviceFee: any = currentUser.serviceFee || (currentUser.role !== "SELLER" ? saleSettings.serviceFee : saleSettings.sellerServiceFee);
      const commission: any = (+product.price * ((currentUser.commissionRate || currentUser.role !== "SELLER" ? saleSettings.commissionRate : saleSettings.sellerCommissionRate) / 100)).toFixed(2);
      const finalAmount: any = (+product.price - commission - serviceFee).toFixed(2);

      const sellProduct = {
        user: currentUser._id,
        category: productGroup.category,
        brand: productGroup.brands[0],
        productGroup: productGroup._id,
        size: new mongoose.Types.ObjectId(product.terms[0]),
        usingStatus: "NEW",
        sku: "",
        price: product.price,
        serviceFee: serviceFee,
        commission,
        finalAmount,
      };

      for (let i = 0; i < parseInt(product.stock); i++) {
        await this.advertModel.create(sellProduct);
      }

      return res
    }

    return res;
  }

  async updateProduct(
    currentUserId: ObjectId,
    id: ObjectId,
    product: CreateProductDto,
    terms: { size: any, color: any }
  ) {
    if (product.stock && product.price) {

      const existsProduct = await this.productModel.findById(id);

      const saleSettings = await this.saleSettingsModel.findOne({});
      const currentUser = await this.userModel.findById(currentUserId);
      const productGroup = await this.productGroupModel.findById(product.group);

      const serviceFee: any = (currentUser.serviceFee) || (currentUser.role !== "SELLER" ? saleSettings.serviceFee : saleSettings.sellerServiceFee);
      const commission: any = (+product.price * ((currentUser.commissionRate || currentUser.role !== "SELLER" ? saleSettings.commissionRate : saleSettings.sellerCommissionRate) / 100)).toFixed(2);
      const finalAmount: any = (+product.price - commission - serviceFee).toFixed(2);

      const sellProduct = {
        user: currentUser._id,
        category: productGroup.category,
        brand: productGroup.brands[0],
        productGroup: productGroup._id,
        size: new mongoose.Types.ObjectId(terms.size),
        color: new mongoose.Types.ObjectId(terms.color),
        terms: product.terms,
        usingStatus: "NEW",
        sku: "",
        price: product.price,
        serviceFee: serviceFee,
        commission,
        finalAmount,
      };

      if (currentUser?.role !== "SELLER") {
        const adverts = await this.advertModel.findOne({
          productGroup: existsProduct.group
        });
        await this.updateStockState(existsProduct.group, (adverts ? true : false));

        if (existsProduct?.stock === undefined || (parseInt(product.stock) > parseInt(existsProduct.stock))) {
          console.log(existsProduct?.stock)
          for (let i = 0; i < (existsProduct?.stock ? parseInt(product.stock) - parseInt(existsProduct.stock) : parseInt(product.stock)); i++) {
            await this.advertModel.create(sellProduct);
          }

          const advertExists = await this.advertModel.find({
            user: currentUser._id,
            category: productGroup.category,
            brand: productGroup.brands[0],
            productGroup: productGroup._id,
            size: new mongoose.Types.ObjectId(product.terms[0])
          });

          for (let i = 0; i < advertExists.length; i++) {
            await this.advertModel.findByIdAndUpdate(advertExists[i]._id, {
              price: product.price,
              serviceFee: serviceFee,
              commission,
              finalAmount
            });
          }
        } else if (parseInt(existsProduct.stock) > parseInt(product.stock)) {
          const adverts = await this.advertModel.find({
            user: currentUser._id,
            category: productGroup.category,
            brand: productGroup.brands[0],
            productGroup: productGroup._id,
            size: new mongoose.Types.ObjectId(product.terms[0])
          });

          if (adverts.length !== 0) {
            for (let i = 0; i < (parseInt(existsProduct.stock) - parseInt(product.stock)); i++) {
              await this.advertModel.findByIdAndDelete(adverts[i]._id);
            }
          }

          const advertExists = await this.advertModel.find({
            user: currentUser._id,
            category: productGroup.category,
            brand: productGroup.brands[0],
            productGroup: productGroup._id,
            size: new mongoose.Types.ObjectId(product.terms[0])
          });

          for (let i = 0; i < advertExists.length; i++) {
            await this.advertModel.findByIdAndUpdate(advertExists[i]._id, {
              price: product.price,
              serviceFee: serviceFee,
              commission,
              finalAmount
            });
          }
        } else {
          const advertExists = await this.advertModel.find({
            user: currentUser._id,
            category: productGroup.category,
            brand: productGroup.brands[0],
            productGroup: productGroup._id,
            size: new mongoose.Types.ObjectId(product.terms[0])
          });

          for (let i = 0; i < advertExists.length; i++) {
            await this.advertModel.findByIdAndUpdate(advertExists[i]._id, {
              price: product.price,
              serviceFee: serviceFee,
              commission,
              finalAmount
            });
          }
        }
      } else {
        await this.productsPendingApprovalModel.create({
          advert: sellProduct,
          productGroup: null,
          stock: product.stock,
          price: product.price,
          type: "advert",
          createdBy: currentUserId
        });
      }
    }
    const updateProduct = await this.productModel.findByIdAndUpdate(
      id,
      product,
      {
        new: true,
        runValidators: true,
      },
    );

    if (!updateProduct) {
      throw new NotFoundException(`Product not found`);
    }
    return updateProduct;
  }

  async deleteProduct(id: ObjectId): Promise<{ message: string }> {
    const product = await this.productModel.findById(id);
    await product.delete();

    const newVariantCount = await this.productModel.count({
      group: product.group,
    });

    const adverts = await this.advertModel.findOne({
      productGroup: product.group
    });
    await this.updateStockState(product.group, (adverts ? true : false));

    await this.productGroupModel
      .findByIdAndUpdate(
        product.group,
        {
          $set: {
            variantCount: newVariantCount,
          },
        },
        {
          projection: { _id: 1 },
        },
      )
      .lean();

    return { message: `Product has been deleted` };
  }

  async findAllBrands(query) {
    const filter: any = {};
    const skip = (query.page - 1) * query.limit

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const searchKeywords = query.filterName.split(/\s+/).filter(Boolean);
      const andConditions = [
        {
          $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
        }
      ];

      filter.$and = [...(filter.$and || []), ...andConditions];
    }

    const totalBrands = await this.brandModel.count(filter);

    const page = await this.brandModel
      .find(filter)
      .populate('category')
      .skip(skip)
      .limit(query.limit)
      .sort({ createdAt: -1 })
      .lean();

    return {
      totalBrands,
      page,
    };
  }

  async findPopularBrands(): Promise<Brand[]> {
    const brands = await this.brandModel.find().limit(5);
    return brands;
  }

  async findBrandById(id: ObjectId): Promise<Brand> {
    const brand = await this.brandModel.findById(id);

    if (!brand) {
      throw new NotFoundException(`Brand not found`);
    }
    return brand;
  }

  async createBrand(brand: CreateBrandDto): Promise<Brand> {
    const response = await this.brandModel.create({
      ...brand,
      pageTitle: "",
      pageDescription: ""
    });
    return response;
  }

  async updateBrand(id: ObjectId, dto): Promise<Brand> {
    const updatedBrand = await this.brandModel.findByIdAndUpdate(id, dto, {
      new: true,
      runValidators: true,
    });
    if (!updatedBrand) {
      throw new NotFoundException(`Brand not found`);
    }
    return updatedBrand;
  }

  async deleteBrand(id: ObjectId): Promise<{ message: string }> {
    await this.brandModel.findByIdAndDelete(id);
    return { message: `Brand has been deleted` };
  }

  async listUsers(query) {
    const filter: any = {
      $or: [],
    };
    const skip = (query.page - 1) * query.limit

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const searchKeywords = query.filterName.split(/\s+/).filter(Boolean);
      filter.$or = [
        ...filter.$or,
        {
          email: { $regex: query.filterName, $options: 'i' },
        },
        {
          $or: searchKeywords.map(keyword => ({ name: { $regex: keyword, $options: 'i' } }))
        },
        {
          $or: searchKeywords.map(keyword => ({ surname: { $regex: keyword, $options: 'i' } }))
        }
      ];
    }

    if (query.filterStatus !== 'ALL') {
      if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
        filter.$or = [
          ...filter.$or,
          {
            status: query.filterStatus,
            email: { $regex: query.filterName, $options: 'i' },
          },
        ];
      } else {
        filter.$or = [
          ...filter.$or,
          {
            status: query.filterStatus,
          },
        ];
      }
    }

    if (!filter.$or.length) delete filter.$or;

    const totalUsers = await this.userModel.count(filter);
    const totalPage = Math.ceil(totalUsers / query.limit)
    const page = await Promise.all((await this.userModel
      .find(filter)
      .skip(skip)
      .limit(query.limit)
      .select({ password: 0 })
      .lean()).map(async (user) => {
        const purchasedsFilter: any = {};
        purchasedsFilter['sendData.buyer.id'] = user?._id.toString();
        const purchaseds: any = await this.paymentModel.find(purchasedsFilter);

        let totalOrdersPrice = 0;
        let totalOrdersCount = 0;
        for (let i = 0; i < purchaseds.length; i++) {
          totalOrdersCount += 1;
          totalOrdersPrice += parseInt(purchaseds[i].sendData.price);
        }

        return { ...user, totalOrdersCount, totalOrdersPrice }
      }));

    for (let i = 0; i < page.length; i++) {
      if (page[i]?.role === "ADMIN") {
        let pendingPayments = 0;
        const adverts = await this.advertModel.find({
          user: page[i]?._id,
          status: "SOLD"
        });
        for (let j = 0; j < adverts.length; j++) {
          pendingPayments += adverts[j].finalAmount;
        }
        await this.userModel.findByIdAndUpdate(page[i]?._id, { pendingPayment: pendingPayments }, { new: true })
      }
    }

    return {
      page,
      totalUsers,
      totalPage
    };
  }

  listSliders() {
    return this.sliderModel.find();
  }

  createSlider(createSliderDto) {
    return this.sliderModel.create(createSliderDto);
  }

  updateSlider(userId: ObjectId, updateSliderDto) {
    return this.sliderModel.findByIdAndUpdate(userId, updateSliderDto);
  }

  deleteSlider(sliderId: ObjectId) {
    return this.sliderModel.findByIdAndDelete(sliderId);
  }

  getUserById(userId: ObjectId) {
    return this.userModel.findById(userId).lean();
  }

  deleteUser(userId: ObjectId) {
    return this.userModel.findByIdAndDelete(userId);
  }

  createUser(createUserDto) {
    return this.userModel.create(createUserDto);
  }

  updateUser(userId: ObjectId, updateUserDto) {
    return this.userModel.findByIdAndUpdate(userId, updateUserDto);
  }

  verifyUser(userId: ObjectId) {
    return this.userModel.findByIdAndUpdate(
      userId,
      { status: 'VERIFIED' },
      { new: true, lean: true },
    );
  }

  denyUser(userId: ObjectId) {
    return this.userModel.findByIdAndUpdate(
      userId,
      { status: 'NOT_VERIFIED' },
      { new: true, lean: true },
    );
  }

  async listOrders(currentUserId: ObjectId, query) {
    const { role } = await this.userModel
      .findById(currentUserId, { role: 1 })
      .lean();

    const filter: any = {
      $or: [],
    };

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const user = await this.userModel.findOne({
        email: { $regex: query.filterName, $options: 'i' }
      });
      if (user) {
        filter.user = user._id
      } else {
        filter._id = query.filterName
      }
    }

    if (role !== 'ADMIN') {
      filter.sellers = { $in: [currentUserId] }
    }

    if (query.filterStatus !== 'ALL') {
      filter.status = query.filterStatus
    }

    filter.$or = [
      ...filter.$or,
      {
        createdAt: {
          $gt: moment(query.filterDate),
        },
      },
    ];

    const totalOrders = await this.orderModel.count(filter);
    const page = await this.orderModel
      .find(filter)
      .populate({
        path: 'user',
        select: 'email phoneNumber name surname city district openAddress ibanNumber',
      })
      .populate({
        path: 'basket.advert',
        populate: {
          path: 'productGroup user',
        },
      })
      .skip((query.page - 1) * 10)
      .limit(10)
      .sort({ createdAt: -1 })
      .lean();

    return {
      totalOrders,
      page,
    };
  }

  async getOrderDetails(id: string) {
    const order: any = await this.orderModel.findById(id)
      .populate("user");

    const sellers = [];
    for (let i = 0; i < order.sellers.length; i++) {
      const seller = await this.userModel.findById(new mongoose.Types.ObjectId(order.sellers[i].toString()));
      sellers.push(seller)
    }

    return { ...order?._doc, sellers };
  }

  async createCargo({ senderAddress, recipientAddress }) {
    const data = {
      test: true,
      length: '40',
      height: '25',
      width: '25',
      distanceUnit: 'cm',
      weight: '1',
      massUnit: 'kg',
      items: [{ title: 'test product', quantity: 1 }],
      productPaymentOnDelivery: false,
      senderAddress,
      recipientAddress,
    };

    const response = await axios.post(
      'https://api.geliver.io/api/v1/shipments',
      data,
      {
        headers: {
          Authorization: 'Bearer ' + this.configService.get('GELIVER_TOKEN'),
          'Content-Type': 'application/json',
        },
      },
    );

    console.log(response.data.data)
    const selectedOffer =
      response.data.data.offers.list.find(
        (item) => item.providerServiceCode === 'YURTICI_STANDART',
      ) || response.data.data.offers.cheapest;

    return await this.acceptCargoOffer(selectedOffer.id);
  }

  async acceptCargoOffer(offerID) {
    const data = {
      offerID,
    };

    const response = await axios.post(
      'https://api.geliver.io/api/v1/transactions',
      data,
      {
        headers: {
          Authorization: 'Bearer ' + this.configService.get('GELIVER_TOKEN'),
          'Content-Type': 'application/json',
        },
      },
    );

    return {
      shipmentId: response.data.data.shipment.id,
      tranckingUrl: `https://app.geliver.io/tracking/${response.data.data.shipment.id}`,
      apiTrackingUrl: `https://api.geliver.io/api/v1/tracking/${response.data.data.shipment.id}`
    };
  }

  async updateOrder(orderId: ObjectId, body) {
    const createdBy = body.createdBy;
    delete body.createdBy;
    const order: any = await this.orderModel.findByIdAndUpdate(orderId, { ...body }, { new: true }).populate('user');

    if (!order) {
      throw new NotFoundException(`Order not found`);
    }

    //const res = await order.save();

    let isHaveSeller: any = false;
    for (let i = 0; i < order?.sellers?.length; i++) {
      const user = await this.userModel.findById(order?.sellers[i]);
      if (user.role === "SELLER") {
        isHaveSeller = user;
      }
    }

    if (order.status === body.status) {
      const emailTemplate = getEmailTemplate(false,
        `<div class="container">
          <img class="logo" src="https://sutok.com/assets/logo-7cfd6467.png" alt="logo" />
          <h2>${((order.user.name && order.user.surname) && `${order.user.name} ${order.user.surname}`) || (order.user.name && `${order.user.name} -`) || (order.user.name && `- ${order.user.surname}`) || order.user.email}</h2>
          <p class="txt6b"><a class="customRed" href="https://sutok.com">sutok.com</a> hesabınızdan yaptığınız siparişin durumu değiştirildi.</p>
          <p class="txt6b">${body.status === "DELIVERED" && "Siparişiniz Teslim Edildi"
        || body.status === "SHIPPED" && "Siparişiniz Kargoya Verildi"
        || body.status === "DECLINED" && "Siparişiniz Reddedildi"
        || body.status === "PENDING" && "Siparişiniz Beklemede"}</p>
          <p class="txt6b">Kargo Takip Url'i: <a class="customRed" href="${order?.trackingUrl || ""}">${order?.trackingUrl || ""}</a></p>
          <div class="footer">
            <p>Sorularınız mı var? Bize <a class="customRed" href="mailto:info@sutok.com">info@sutok.com</a> adresinden e-posta gönderin.</p>
          </div>
        </div>`);

      await this.mailerService.sendMail({
        from: this.configService.get<string>('SMTP_USER'),
        to: order?.user?.email,
        subject: `Sutok.com - Sipariş Durumu`,
        html: emailTemplate
      });

      if (body?.status === "DELIVERED") {
        await this.orderModel.findByIdAndUpdate(order?._id, { status: "PAYMENTPENDING" }, { new: true })
        const defaultSaleSettings: any = await this.saleSettingsModel.findOne().exec();
        const commissionFee = defaultSaleSettings?.sellerCommissionRate;
        //const amount = order.basket[i].price - (order.basket[i].price * commissionFee) / 100;
        const adverts = [];
        for (let i = 0; i < order?.basket?.length; i++) {
          const advert = await this.advertModel.findById(order.basket[i].advert);
          adverts?.push(advert);
        }
        if (adverts?.length !== 0) {
          const sellers = [];
          // Adverts listesindeki her bir öğeyi kontrol et
          adverts?.forEach((advert, index) => {
            // Önceki öğelerde aynı kullanıcı bilgisine sahip bir öğe var mı kontrol et
            let userExists = false;
            for (let i = 0; i < index; i++) {
              if (adverts[i].user === advert.user) {
                userExists = true;
                break;
              }
            }

            // Aynı kullanıcı bilgisine sahip bir öğe yoksa yeni listeye ekle
            if (!userExists) {
              sellers.push(advert?.user);
            }
          });

          if (sellers?.length !== 0) {
            for (let i = 0; i < sellers.length; i++) {
              const sellerData = await this.userModel.findById(sellers[i]);

              if (sellerData?.role === "SELLER") {
                const advertsForSeller = adverts?.filter(item => item?.user === sellers[i]);
                const basketForSeller = [];
                for (let j = 0; j < advertsForSeller?.length; j++) {
                  const basket = order?.basket?.find(item => item?.advert.toString() == advertsForSeller[j]?._id.toString())
                  if (basket) {
                    basketForSeller.push(basket)
                  }
                }

                if (basketForSeller?.length !== 0) {
                  let amount = 0;
                  for (let k = 0; k < basketForSeller?.length; k++) {
                    amount += basketForSeller[i]?.price - (basketForSeller[i]?.price * commissionFee) / 100;
                  }

                  await this.createSellerPayment({
                    createdBy,
                    seller: new mongoose.Types.ObjectId(sellers[i]),
                    method: "Havale/EFT",
                    status: "PENDING",
                    amount,
                    products: basketForSeller
                  });
                }
              }
            }
          }
        }
        /*await this.createSellerPayment({
          createdBy,
          seller: advert?.user,
          method: "Havale/EFT",
          status: "PENDING",
          amount,
          products: order.basket[i]
        });*/
      }

      if (body?.status === "SHIPPED" && isHaveSeller) {
        const senderAddress = sutokAddress;
        const recipientAddress = {
          name: order?.billingAddress?.nameSurname,
          email: order?.billingAddress?.email,
          //phone: order?.billingAddress?.phone,
          phone: "+905051234567",
          address1: order?.billingAddress?.addressDefinition,
          countryCode: 'TR',
          cityName: order?.billingAddress?.city,
          districtName: order?.billingAddress?.district,
        }

        const trackingUrl = await this.createCargo({
          senderAddress: senderAddress,
          recipientAddress: recipientAddress,
        });

        /*const trackingUrl2 = await this.createCargo({
          senderAddress: senderAddress,
          recipientAddress: recipientAddress,
        });*/

        await this.orderModel.findByIdAndUpdate(order?._id,
          { shipmentId: trackingUrl.shipmentId, trackingUrl: trackingUrl.tranckingUrl, apiTrackingUrl: trackingUrl.apiTrackingUrl },
          { new: true });
        await this.cargoModel.findOneAndUpdate({ order: order?._id, sender: "USER" }, { trackingUrl: trackingUrl.tranckingUrl }, { new: true });
        await this.cargoModel.findOneAndUpdate({ order: order?._id, sender: "SUTOK" }, { trackingUrl: trackingUrl.tranckingUrl }, { new: true });
      }

      /*await this.firebaseMessaging.send({
        notification: {
          title: 'Sipariş Durumu',
          body: `Siparişinizin durumu "${body.status}" olarak güncellendi.`,
        },
        android: {
          notification: {
            defaultSound: true,
          },
        },
        data: {},
        apns: {
          payload: {
            aps: {
              sound: 'default',
            },
          },
        },
        token: order.user.notificationToken,
      });*/
    }

    return order;
  }

  listGroup() {
    return this.productGroupModel.find();
  }

  async createGroup(userId: ObjectId, createGroupDto) {
    const subtitle = createGroupDto?.subtitle ? createGroupDto?.subtitle : createGroupDto?.title
    const slug = createGroupDto?.slug ? createGroupDto?.slug : slugify(createGroupDto.title, {
      strict: true,
    }) +
      '-' +
      nanoid(5)
    const sku = createGroupDto?.sku ? createGroupDto?.sku : uuidv4().split('-').join('').slice(0, 20);
    const { variantFrom, ...rest } = createGroupDto;

    const createdGroup = await this.productGroupModel.create({
      ...rest,
      subtitle,
      pageTitle: createGroupDto?.pageTitle || createGroupDto?.title,
      pageDescription: createGroupDto?.pageTitle || `${createGroupDto?.title}`,
      slug,
      sku,
      createdBy: createGroupDto?.createdBy || userId,
    });

    if (variantFrom) {
      await this.copyVariant({
        origin: variantFrom,
        target: createdGroup._id,
      });
    }

    return createdGroup;
  }

  async copyVariant(dto) {
    const originGroupVariants = await this.productModel
      .find({
        group: dto.origin,
      })
      .lean();

    await this.productModel.insertMany(
      originGroupVariants.map(({ _id: unused, ...item }) => ({
        ...item,
        group: dto.target,
      })),
    );

    await this.productGroupModel
      .findByIdAndUpdate(
        dto.target,
        {
          variantCount: originGroupVariants.length,
        },
        {
          projection: {
            _id: 1,
          },
        },
      )
      .lean();

    return originGroupVariants.length;
  }

  updateGroup(groupId: ObjectId, updateGroupDto) {
    return this.productGroupModel.findByIdAndUpdate(groupId, updateGroupDto, { new: true });
  }

  deleteGroup(groupId: ObjectId) {
    return this.productGroupModel.findByIdAndDelete(groupId);
  }

  async listAttribute(query) {
    const filter: any = {};

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      filter.$or = [
        {
          title: { $regex: query.filterName, $options: 'i' },
        },
      ];
    }

    const totalCount = await this.productAttributeModel.count(filter);
    const totalPage = Math.ceil(totalCount / query.limit)
    const page = await this.productAttributeModel
      .find(filter)
      .skip((query.page - 1) * query.limit)
      .limit(query.limit)
      .lean();

    return {
      page,
      totalCount,
      totalPage,
    };
  }

  createAttribute(createAttributeDto) {
    return this.productAttributeModel.create(createAttributeDto);
  }

  updateAttribute(attributeId: ObjectId, updateAttributeDto) {
    return this.productAttributeModel.findByIdAndUpdate(
      attributeId,
      updateAttributeDto,
    );
  }

  async deleteAttribute(attributeId: ObjectId) {
    const terms = await this.productAttributeTermModel.find({ attribute: attributeId });
    for (let i = 0; i < terms.length; i++) {
      await this.productAttributeTermModel.findByIdAndDelete(terms[i]?._id);
    }
    return this.productAttributeModel.findByIdAndDelete(attributeId);
  }

  async listTerm(attributeId: ObjectId, query) {
    const filter: any = {
      attribute: attributeId,
    };

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      filter.$or = [
        {
          title: { $regex: query.filterName, $options: 'i' },
        },
      ];
    }

    const totalTerms = await this.productAttributeTermModel.count(filter);
    const page = await this.productAttributeTermModel
      .find(filter)
      .skip((query.page - 1) * query.limit)
      .limit(query.limit)
      .lean();

    return {
      totalTerms,
      page,
    };
  }

  createTerm(createTermDto) {
    return this.productAttributeTermModel.create(createTermDto);
  }

  updateTerm(termId: ObjectId, updateTermDto) {
    return this.productAttributeTermModel.findByIdAndUpdate(
      termId,
      updateTermDto,
    );
  }

  deleteTerm(termId: ObjectId) {
    return this.productAttributeTermModel.findByIdAndDelete(termId);
  }

  async findAllModels(currentUserId, query) {
    const filter: any = {};

    const currentUser = await this.userModel.findById(currentUserId);

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const searchKeywords = query.filterName.split(/\s+/).filter(Boolean);
      const andConditions = [
        {
          $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
        }
      ];

      filter.$and = [...(filter.$and || []), ...andConditions];
    }

    if (currentUser?.role === "SELLER") {
      filter._id = { $in: currentUser?.models }
    }

    if (query.brandLabel) {
      filter.brand = query.brandContaining === "true" ?
        [new mongoose.Types.ObjectId(query.brandLabel)] :
        { $ne: new mongoose.Types.ObjectId(query.brandLabel) }
    }
    if (query.parentModelLabel) {
      filter.parentModel = query.parentModelContaining === "true" ?
        [new mongoose.Types.ObjectId(query.parentModelLabel)] :
        { $ne: new mongoose.Types.ObjectId(query.parentModelLabel) }
    }

    const totalModels = await this.productModelModel.count(filter);
    const totalPage = Math.ceil(totalModels / query.limit);

    const page = await this.productModelModel
      .find(filter)
      .skip((query.page - 1) * query.limit)
      .sort({
        order: 1,
      })
      .limit(query.limit)
      .populate('parentModel')
      .populate('brand')
      .sort({ createdAt: -1 })
      .lean();

    return {
      page,
      totalModels,
      totalPage
    };
  }

  async getModelDetails(id: any) {
    const model = await this.productModelModel.findOne({
      _id: new mongoose.Types.ObjectId(id)
    }).populate("brand").populate("parentModel");

    return model;
  }

  async createModel(dto) {
    const newModel = await this.productModelModel.create(dto);

    return newModel;
  }

  async updateModel(id: ObjectId, dto) {
    const updatedModel = await this.productModelModel.findByIdAndUpdate(
      id,
      dto,
      { new: true, runValidators: true },
    );

    if (!updatedModel) {
      throw new NotFoundException(`Model not found`);
    }

    return updatedModel;
  }

  async deleteModel(id: ObjectId) {
    const deletedModel = await this.productModelModel.findByIdAndDelete(id);

    if (!deletedModel) {
      throw new NotFoundException(`Model not found`);
    }
    return { message: 'Model deleted successfully' };
  }

  async findAllCategories(query) {
    const filter: any = {};

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      const searchKeywords = query.filterName.split(/\s+/).filter(Boolean);
      const andConditions = [
        {
          $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
        }
      ];

      filter.$and = [...(filter.$and || []), ...andConditions];
    }

    const totalCategories = await this.categoryModel.count(filter);

    const page = await this.categoryModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .limit(10)
      .sort({ createdAt: -1 })
      .lean();

    return {
      totalCategories,
      page,
    };
  }

  async findCategoryById(id: ObjectId): Promise<Category> {
    const category = await this.categoryModel.findById(id);
    if (!category) {
      throw new NotFoundException(`Category not found`);
    }
    return category;
  }

  async createCategory(dto) {
    const lastCategory = await this.categoryModel
      .findOne({}, { order: 1 })
      .sort({
        order: -1,
      })
      .lean();

    return this.categoryModel.create({
      ...dto,
      pageTitle: "",
      pageDescription: "",
      order: (lastCategory?.order || 0) + 1,
    });
  }

  async updateCategory(id: ObjectId, dto) {
    const updatedCategory = await this.categoryModel.findByIdAndUpdate(
      id,
      dto,
      { new: true, runValidators: true },
    );

    if (!updatedCategory) {
      throw new NotFoundException(`Category not found`);
    }

    return updatedCategory;
  }

  async deleteCategory(id: ObjectId): Promise<{ message: string }> {
    const deletedCategory = await this.categoryModel.findByIdAndDelete(id);
    if (!deletedCategory) {
      throw new NotFoundException(`Category not found`);
    }
    return { message: 'Category deleted successfully' };
  }

  async swapOrders(dto) {
    const originItem = await this.categoryModel.findById(dto.originId);
    const targetItem = await this.categoryModel.findById(dto.targetId);

    const originOrder = new Number(originItem.order);
    const targetOrder = new Number(targetItem.order);

    targetItem.order = Math.random();
    await targetItem.save();

    originItem.order = targetOrder.valueOf();
    await originItem.save();

    targetItem.order = originOrder.valueOf();
    await targetItem.save();

    return true;
  }

  async swapHomeSections(dto) {
    const originItem = await this.homeSectionsModel.findById(dto.originId);
    const targetItem = await this.homeSectionsModel.findById(dto.targetId);

    const originOrder = new Number(originItem.order);
    const targetOrder = new Number(targetItem.order);

    targetItem.order = Math.random();
    await targetItem.save();

    originItem.order = targetOrder.valueOf();
    await originItem.save();

    targetItem.order = originOrder.valueOf();
    await targetItem.save();

    return true;
  }

  async listSellers(query) {

    const filter: any = {
      /*advertCount: {
        $gt: 0,
      },*/
      role: "SELLER"
    };
    let sorted: any = null

    if (query.filterName !== 'undefined' && query.filterName?.length > 0) {
      filter.$or = [
        {
          email: { $regex: query.filterName, $options: 'i' },
        },
      ];
    }

    if (query?.sorted) {
      if (query.sorted === "totalsold_asc") {
        sorted = { advertCount: 1 }
      } else if (query.sorted === "totalsold_desc") {
        sorted = { advertCount: -1 }
      }
    }

    const totalSellers = await this.userModel.count(filter);

    const paymentFilter =
      query.filterStatus === 'PENDING'
        ? [
          {
            $match: {
              'adverts.0': {
                $exists: true,
              },
            },
          },
        ]
        : query.filterStatus === 'PAID'
          ? [
            {
              $match: {
                'adverts.0': {
                  $exists: false,
                },
              },
            },
          ]
          : [];

    let aggregate = [
      {
        $match: filter,
      },
      {
        $lookup: {
          from: 'adverts',
          let: { userId: '$_id' },
          as: 'adverts',
          pipeline: [
            {
              $match: {
                $and: [
                  {
                    $expr: { $eq: ['$user', '$$userId'] },
                  },
                  {
                    status: {
                      $ne: 'PENDING',
                    },
                  },
                ],
              },
            },
            {
              $limit: 30,
            },
          ],
        },
      },
      ...paymentFilter,
    ]
    const aggregateLimitAndSkip = [
      { $skip: (query.page - 1) * 10 },
      { $limit: 10 },
    ]

    const page = await this.userModel.aggregate(sorted ? [...aggregate, { $sort: sorted }, ...aggregateLimitAndSkip] : [...aggregate, ...aggregateLimitAndSkip]);

    return {
      totalSellers,
      page: page.map((seller) => ({
        ...seller,
        /*pendingPayment: seller.adverts.reduce(
          (prev, cur) => prev + cur.price,
          0,
        ),*/
      })),
    };
  }

  async getUserDetail(userId) {
    const filter: any = {};
    const user = await this.userModel.findById(userId);
    filter.$or = [
      {
        _id: user._id
      },
    ];
    const result = await this.userModel.aggregate([
      {
        $match: {
          ...filter
        },
      },
      {
        $lookup: {
          from: 'adverts',
          let: { userId: '$_id' },
          as: 'adverts',
          pipeline: [
            {
              $match: {
                $and: [
                  {
                    $expr: { $eq: ['$user', '$$userId'] },
                  },
                  {
                    status: {
                      $ne: 'PENDING',
                    },
                  },
                ],
              },
            },
            {
              $limit: 30,
            },
          ],
        },
      },
      {
        $lookup: {
          from: this.addressModel.collection.name,
          as: 'address',
          pipeline: [
            {
              $match: {
                user: userId
              }
            },
          ]
        }
      },
    ]);

    const comments: any = await this.commentModel.find({
      user: userId
    });

    let averageBasketAmount: number = 0;
    let averageBasketSize: number = 0;
    let timelines: any = [
      { id: 1, type: "createdUser", date: result[0].createdAt }
    ];
    const purchasedsFilter: any = {};
    purchasedsFilter['sendData.buyer.id'] = userId;
    const purchaseds: any = await this.paymentModel.find(purchasedsFilter);
    for (let i = 0; i < purchaseds.length; i++) {
      averageBasketAmount += parseInt(purchaseds[i].sendData.price);
      averageBasketSize += purchaseds[i].sendData.basketItems.length
      timelines.push({
        _id: purchaseds[i]._id, type: "order", date: purchaseds[i].createdAt
      });
    }

    for (let i = 0; i < result[0].adverts.length; i++) {
      timelines.push({
        _id: result[0].adverts[i]._id, type: "sale", date: result[0].adverts[i].createdAt
      });
    }

    if (comments?.length !== 0) {
      for (let j = 0; j < comments.length; j++) {
        timelines.push({
          _id: comments[j]._id, type: "comment", date: comments[j].createdAt, description: comments[j].description
        });
      }
    }

    return {
      user: {
        ...result[0],
        timelines: timelines.sort((a, b) => b.date - a.date),
        averageBasketInformation: { averageBasketAmount: averageBasketAmount / purchaseds.length, averageBasketSize: averageBasketSize / purchaseds.length }
      }
    };
  }

  async getUserOrders(query) {

    const filter: any = {
      user: query.userId
    }
    const skip = (query.page - 1) * query.limit;
    const orders = await this.orderModel.find(filter).skip(skip).limit(query.limit);
    const totalCount = await this.orderModel.count(filter);
    const totalPage = Math.ceil(totalCount / query.limit);

    return {
      orders,
      totalCount,
      totalPage
    }
  }

  async listSales(query) {
    const filter: any = {
      user: new mongoose.Types.ObjectId(query.user),
      status: "SOLD"
    }
    const skip = (query.page - 1) * query.limit;

    const totalCount = await this.advertModel.count(filter);
    const totalPage = Math.ceil(totalCount / query.limit);

    const sales = await this.advertModel
      .find(filter)
      .skip(skip)
      .populate('user')
      .populate('productGroup')
      .limit(query.limit)
      .lean();

    return {
      sales,
      totalCount,
      totalPage
    };
  }

  async listOffers(query) {
    const filter: any = {};

    if (query.status !== 'ALL') {
      filter.status = query.status;
    }

    const totalOffers = await this.offerModel.count(filter);

    const page = await this.offerModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .populate('sender')
      .populate('receiver')
      .populate({
        path: 'advert',
        populate: 'productGroup',
      })
      .limit(10)
      .lean();

    return {
      totalOffers,
      page,
    };
  }

  async getAdvert(id: ObjectId) {
    const advert: any = await this.advertModel.findById(id).exec();
    const productGroup = await this.productGroupModel.findById(advert.productGroup)
      .populate("brands")
      .exec();

    return { ...advert?._doc, productGroup }
  }

  async listAdverts(query) {
    const filter: any = {
      status: query.status,
    };

    const totalAdverts = await this.advertModel.count(filter);

    const page = await this.advertModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .populate({
        path: 'user',
      })
      .populate({
        path: 'productGroup',
      })
      .limit(10)
      .lean();

    return {
      totalAdverts,
      page,
    };
  }

  async getSaleSettings() {
    return await this.saleSettingsModel.findOne({}).lean();
  }

  updateSaleSettings(dto) {
    return this.saleSettingsModel
      .findOneAndUpdate({}, dto, { new: true, upsert: true })
      .lean();
  }

  async listArticles(query) {
    const filter: any = {};

    const totalArticles = await this.articleModel.count(filter);
    const page = await this.articleModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .limit(10)
      .sort({ createdAt: -1 })
      .lean();

    return {
      totalArticles,
      page,
    };
  }

  getArticle(id: ObjectId) {
    return this.articleModel.findById(id).lean();
  }

  createArticle(dto) {
    return this.articleModel.create(dto);
  }

  updateArticle(id: ObjectId, dto) {
    return this.articleModel.findByIdAndUpdate(id, dto);
  }

  deleteArticle(id: ObjectId) {
    return this.articleModel.findByIdAndDelete(id);
  }

  updateAgreementContent(dto) {
    return this.agreementsModel
      .findOneAndUpdate({ type: dto.type }, dto, {
        upsert: true,
      })
      .lean();
  }

  async getAgreementContent(type: string) {
    const res = await this.agreementsModel.findOne({ type }).lean();

    if (!res) {
      return {
        type,
        content: '',
      };
    }

    return res;
  }

  async updateUserFees(body: UpdateFeesDto) {
    const data = { commissionFee: body.commissionFee, serviceFee: body.serviceFee }
    const updatedUser = await this.userModel.findByIdAndUpdate(body.userId, data, { new: true });
    return updatedUser
  }

  async increaseStock(body: any) {
    console.log(body)
  }

  async getCargos(query) {
    const filter: any = {
      status: query.status,
    };

    const totalAdverts = await this.orderModel.count(filter);

    const page = await this.orderModel
      .find(filter)
      .skip((query.page - 1) * 10)
      .populate({
        path: 'user',
      })
      .limit(10)
      .lean();

    return {
      totalAdverts,
      page,
    };
  }

  async createUserComment(body: CreateCommentDto): Promise<Boolean> {
    const newComment = await this.commentModel.create(body);
    if (newComment) {
      return true;
    } else {
      return false
    }
  }

  async listVariants(groupId: ObjectId) {
    const variants = await this.productModel
      .find({ group: groupId })
      .populate("terms");
    return variants;
  }

  async listAllProductattributes() {
    const productattributes = await this.productAttributeModel.find();
    return productattributes;
  }

  async listAllProductattributeterms(attributeId) {
    const productattributeterms = await this.productAttributeTermModel.find({
      attribute: new mongoose.Types.ObjectId(attributeId)
    });
    return productattributeterms;
  }

  async getTerm(id) {
    const productattributeterm = await this.productAttributeTermModel.findById(id);
    return productattributeterm
  }

  async listAllSellerPayment(userId, query) {
    const filter: any = {};
    const filterForUser: any = {};
    const limit = parseInt(query.limit)
    const skip = (parseInt(query.page) - 1) * limit;

    if (query.status && query.status !== "ALL") {
      filter.status = query.status
    }
    if (query.filterName) {
      filterForUser.email = { $regex: query.filterName, $options: 'i' };
    }
    const user = await this.userModel.findById(userId);
    if (user.role === "SELLER") {
      filter.seller = new mongoose.Types.ObjectId(userId);
    }
    const totalCount = await this.sellerPaymentModel.count(filter);
    const totalPage = Math.ceil(totalCount / limit);

    const page = await this.sellerPaymentModel.aggregate([
      {
        $match: {
          ...filter
        }
      },
      {
        $lookup: {
          from: this.userModel.collection.name,
          localField: 'seller',
          foreignField: '_id',
          as: 'seller',
          pipeline: [
            {
              $match: {
                ...filterForUser
              }
            },
          ]
        }
      },
      {
        $sort: { createdAt: -1 }
      },
      {
        $match: {
          $expr: { $ne: [{ $size: "$seller" }, 0] }
        }
      }
    ])

    return {
      page: page.map(item => { return { ...item, seller: item.seller[0] } }),
      totalCount, totalPage
    }
  }

  async getSellerPayment(id) {
    const sellerPayment = await this.sellerPaymentModel.findOne({ _id: id })
      .populate("seller");
    return sellerPayment;
  }

  async createSellerPayment(body) {
    const timelines = [
      {
        id: 1,
        type: "Created",
        label: "Ödeme Oluşturuldu",
        date: new Date()
      }
    ];
    const newSellerPayment = await this.sellerPaymentModel.create({
      ...body,
      timelines
    });
    return newSellerPayment;
  }

  async updateSellerPayment(sellerPaymentId, body) {
    const updatedSellerPayment = await this.sellerPaymentModel.findByIdAndUpdate(sellerPaymentId, body, { new: true });
    if (body?.status && body?.status === "PAID") {
      // ödenmiş olarak işaretlendiğinde bekleyen ödemeden kısılacak
    }
    return updatedSellerPayment;
  }

  async listProductsPendingApproval(query) {
    const filter: any = {};
    const limit = parseInt(query.limit)
    const skip = (parseInt(query.page) - 1) * limit;

    if (query.filterName) {
      filter._id = query.filterName
    }

    const totalCount = await this.productsPendingApprovalModel.count(filter);
    const totalPage = Math.ceil(totalCount / limit);

    const productsPendingApproval = await this.productsPendingApprovalModel.find(filter)
      .skip(skip)
      .limit(limit)
      .sort({ createdAt: -1 })
      .populate("createdBy");

    return {
      page: productsPendingApproval,
      totalPage,
      totalCount
    }
  }

  async createProductsPendingApproval(currentUserId, body) {
    const productsPendingApprovalModel = await this.productsPendingApprovalModel.create({
      ...body,
      createdBy: currentUserId
    });
    return productsPendingApprovalModel;
  }

  async deleteProductsPendingApproval(id) {
    const productsPendingApprovalModel = await this.productsPendingApprovalModel.findByIdAndDelete(id);
    return productsPendingApprovalModel;
  }

  async updateAllOrders() {
    const totalOrdersCount = await this.orderModel.count({
      status: { $ne: "DELIVERED" }
    });
    let limit = 10;
    //let skip = (page - 1) * limit;
    let totalPage = Math.ceil(totalOrdersCount / limit);

    for (let a = 0; a < totalPage; a++) {
      const orders = await this.orderModel.find({
        status: { $ne: "DELIVERED" }
      }).skip(a * limit).limit(limit);

      for (let i = 0; i < orders.length; i++) {
        if (orders[i]?.apiTrackingUrl) {
          const response = await axios.get(orders[i]?.apiTrackingUrl);
          const trackingStatus = response?.data?.data?.trackingStatus;

          if (trackingStatus === "DELIVERED") {
            await this.updateOrder(orders[i]?._id, { status: "DELIVERED" });
          }
        }
      }
    }
  }

  async listSellerRequests(query) {
    const filter: any = {};
    const limit = parseInt(query.limit)
    const skip = (parseInt(query.page) - 1) * limit;

    if (query?.filterName) {
      filter.email = { $regex: query?.filterName, $options: 'i' }
    }

    const totalCount = await this.sellerRequestsModel.count(filter);
    const totalPage = Math.ceil(totalCount / limit);

    const sellerRequests = await this.sellerRequestsModel.find(filter)
      .skip(skip)
      .limit(limit)
      .sort({ createdAt: -1 })
      .populate("createdBy");

    return {
      page: sellerRequests,
      totalPage,
      totalCount
    }
  }

  async getSellerRequest(id) {
    const sellerRequest = await this.sellerRequestsModel.findById(id);
    return sellerRequest;
  }

  async updateSellerRequest(id, body) {
    const updatedSellerRequest = await this.sellerRequestsModel.findByIdAndUpdate(id, body, { new: true });
    return updatedSellerRequest;
  }

  async deleteSellerRequest(id) {
    const deletedSellerRequest = await this.sellerRequestsModel.findByIdAndDelete(id);
    return deletedSellerRequest;
  }
}
