/* eslint-disable prettier/prettier */
import { IsOptional, IsString, IsUrl } from 'class-validator';

export class UpdateBrandDto {
  @IsString()
  @IsOptional()
  title: string;

  @IsOptional()
  @IsUrl()
  logo: string;

  @IsOptional()
  @IsUrl()
  background: string;
}
