/* eslint-disable prettier/prettier */
import {
  IsArray,
  IsDate,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
} from 'class-validator';
import { Types } from 'mongoose';

export class CreateProductDto {
  @IsMongoId()
  @IsNotEmpty()
  group: Types.ObjectId;

  @IsArray()
  @IsMongoId({ each: true })
  terms: string[];

  @IsString()
  @IsOptional()
  sku: string;

  @IsString()
  @IsOptional()
  releaseDate: Date;

  @IsString()
  @IsOptional()
  colorway: string;

  @IsString()
  @IsOptional()
  style: string;

  @IsString()
  @IsOptional()
  stock: string;

  @IsString()
  @IsOptional()
  price: string;

  @IsArray()
  @IsOptional()
  Images: string[];

  @IsNumber()
  @IsOptional()
  kg: number;

  @IsNumber()
  @IsOptional()
  cmU: number;

  @IsNumber()
  @IsOptional()
  cmY: number;

  @IsNumber()
  @IsOptional()
  cmG: number;
}
