import { IsOptional, IsString, IsUrl } from 'class-validator';

export class UpdateCategoryDto {
  @IsString()
  @IsOptional()
  title: string;

  @IsOptional()
  @IsUrl()
  photo: string;
}
