import { Controller, Post, Body, Inject, UseGuards, Get, Query } from '@nestjs/common';
import { PaymentService } from './payment.service';
import { ConfigService } from '@nestjs/config';
import Iyzipay from 'iyzipay';
import { v4 as uuidv4 } from 'uuid';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('payment')
export class PaymentController {
  constructor(
    private readonly paymentService: PaymentService,
    private readonly configService: ConfigService,
    @Inject('Iyzipay') private readonly iyzipay: Iyzipay,
  ) {}

  @Post()
  createPayment(@Body() body: any) {
    const {
      cardHolderName,
      cardNumber,
      expireMonth,
      expireYear,
      cvc,
      price,
      paidPrice,
    } = body;

    const data = {
      locale: 'tr',
      conversationId: '123456789',
      price,
      paidPrice,
      currency: 'TRY',
      installment: '1',
      basketId: 'B67832',
      paymentChannel: 'MOBILE',
      paymentCard: {
        cardHolderName,
        cardNumber,
        expireMonth,
        expireYear,
        cvc,
        registerCard: '0',
      },
      buyer: {
        id: 'BY789',
        name: 'John',
        surname: 'Doe',
        gsmNumber: '+905350000000',
        email: 'email@email.com',
        identityNumber: '74300864791',
        lastLoginDate: '2015-10-05 12:43:35',
        registrationDate: '2013-04-21 15:12:09',
        registrationAddress:
          'Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1',
        ip: '85.34.78.112',
        city: 'Istanbul',
        country: 'Turkey',
        zipCode: '34732',
      },
      shippingAddress: {
        contactName: 'Jane Doe',
        city: 'Istanbul',
        country: 'Turkey',
        address: 'Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1',
        zipCode: '34742',
      },
      billingAddress: {
        contactName: 'Jane Doe',
        city: 'Istanbul',
        country: 'Turkey',
        address: 'Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1',
        zipCode: '34742',
      },
      basketItems: [
        {
          id: 'BI101',
          name: 'Binocular',
          category1: 'Collectibles',
          category2: 'Accessories',
          itemType: Iyzipay.BASKET_ITEM_TYPE.PHYSICAL,
          price: price,
        },
      ],
    };
    return this.paymentService.makePayment(data);
  }

  @Post('/threeds-initial')
  createThreedsPayment(@Body() body: any) {
    const {
      cardHolderName,
      cardNumber,
      expireMonth,
      expireYear,
      cvc,
      price,
      paidPrice,
    } = body;

    const data = {
      locale: 'tr',
      conversationId: '123456789',
      price,
      paidPrice,
      currency: 'TRY',
      installment: '1',
      basketId: 'B67832',
      paymentChannel: 'MOBILE',
      callbackUrl: 'https://www.merchant.com/callback',
      paymentCard: {
        cardHolderName,
        cardNumber,
        expireMonth,
        expireYear,
        cvc,
        registerCard: '0',
      },
      buyer: {
        id: 'BY789',
        name: 'John',
        surname: 'Doe',
        gsmNumber: '+905350000000',
        email: 'email@email.com',
        identityNumber: '74300864791',
        lastLoginDate: '2015-10-05 12:43:35',
        registrationDate: '2013-04-21 15:12:09',
        registrationAddress:
          'Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1',
        ip: '85.34.78.112',
        city: 'Istanbul',
        country: 'Turkey',
        zipCode: '34732',
      },
      shippingAddress: {
        contactName: 'Jane Doe',
        city: 'Istanbul',
        country: 'Turkey',
        address: 'Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1',
        zipCode: '34742',
      },
      billingAddress: {
        contactName: 'Jane Doe',
        city: 'Istanbul',
        country: 'Turkey',
        address: 'Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1',
        zipCode: '34742',
      },
      basketItems: [
        {
          id: 'BI101',
          name: 'Binocular',
          category1: 'Collectibles',
          category2: 'Accessories',
          itemType: Iyzipay.BASKET_ITEM_TYPE.PHYSICAL,
          price: price,
        },
      ],
    };

    return this.paymentService.makeThreedsInitial(data);
  }

  @Post('/threeds-payment')
  createThreedsPaymentResult(@Body() body: any) {
    const data = {
      locale: 'tr',
      conversationId: '123456789',
      conversationData: 'conversation data',
      paymentId: '1',
    };

    return this.paymentService.makeThreedsPayment(data);
  }

  @Post('/checkout-form-initialize')
  checkoutFormInitialize(@Body() body: any) {
    // console.log('body======>>>>>>>>>>>>>>>>>>>>', body);
    const {
      price,
      buyerId,
      name,
      surname,
      gsmNumber,
      email,
      identityNumber,
      registrationAddress,
      city,
      ip,
      country,
      callbackUrl = 'https://www.merchant.com/callback',
    } = body;

    const id = uuidv4();

    const data = {
      locale: Iyzipay.LOCALE.TR,
      conversationId: id,
      price,
      paidPrice: price,
      currency: Iyzipay.CURRENCY.TRY,
      paymentChannel: 'MOBILE_WEB',
      callbackUrl: callbackUrl + '?conversationId=' + id,
      enabledInstallments: [2, 3, 6, 9],
      buyer: {
        id: buyerId,
        name,
        surname,
        gsmNumber,
        email,
        identityNumber,
        registrationAddress,
        ip,
        city,
        country,
      },
      shippingAddress: {
        contactName: name,
        city,
        country,
        address: registrationAddress,
      },
      billingAddress: {
        contactName: name,
        city,
        country,
        address: registrationAddress,
      },
      basketItems: [
        {
          id,
          name: 'Transporting products by courier',
          category1: 'Courier service',
          itemType: Iyzipay.BASKET_ITEM_TYPE.VIRTUAL,
          price,
        },
      ],
    };

    return this.paymentService.checkoutFormInitialize(data);
  }

  @Post('/checkout-form-result')
  checkoutFormResult(@Body() body: any) {
    const { token, conversationId } = body;

    const data = {
      locale: Iyzipay.LOCALE.TR,
      conversationId,
      token,
    };

    return this.paymentService.checkoutFormResult(data);
  }

  @Get('/token')
  getTokenByConversationId(@Query() query: any) {
    return this.paymentService.getTokenByConversationId(query);
  }
}
