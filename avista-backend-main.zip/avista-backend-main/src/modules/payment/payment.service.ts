import { Injectable, Inject } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Payment, PaymentDocument } from 'src/schemas/payment.schema';
import Iyzipay from 'iyzipay';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';

@Injectable()
export class PaymentService {
  constructor(
    @Inject('Iyzipay') private readonly iyzipay: Iyzipay,
    @InjectModel(Payment.name)
    private readonly paymentModel: Model<PaymentDocument>,
  ) {}

  async makePayment(request: any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      this.iyzipay.payment.create(request, async (err, result) => {
        if (err) {
          return reject(err.message);
        }

        const saveData = new this.paymentModel({
          sendData: request,
          resultData: result,
        });

        await saveData
          .save()
          .then((res) => {
            console.log('*****************res********', res);
          })
          .catch((err) => {
            console.log('*****************err********', err);
          });

        resolve(result);
      });
    });
  }

  async makeThreedsInitial(request: any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      this.iyzipay.threedsInitialize.create(request, async (err, result) => {
        if (err) {
          return reject(err.message);
        }

        const saveData = new this.paymentModel({
          sendData: request,
          resultData: result,
        });

        await saveData
          .save()
          .then((res) => {
            console.log('*****************res********', res);
          })
          .catch((err) => {
            console.log('*****************err********', err);
          });

        resolve(result);
      });
    });
  }

  async makeThreedsPayment(request: any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      this.iyzipay.threedsPayment.create(request, async (err, result) => {
        if (err) {
          return reject(err.message);
        }

        const saveData = new this.paymentModel({
          sendData: request,
          resultData: result,
        });

        await saveData
          .save()
          .then((res) => {
            console.log('*****************res********', res);
          })
          .catch((err) => {
            console.log('*****************err********', err);
          });

        resolve(result);
      });
    });
  }

  async checkoutFormInitialize(data: any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      this.iyzipay.checkoutFormInitialize.create(data, async (err, result) => {
        if (err) {
          return reject(err.message);
        }

        const saveData = new this.paymentModel({
          sendData: data,
          resultData: result,
        });

        const response = await saveData.save();

        resolve(response);
      });
    });
  }

  async checkoutFormResult(data: any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      this.iyzipay.checkoutForm.retrieve(data, async (err, result) => {
        if (err) {
          return reject(err.message);
        }

        const saveData = new this.paymentModel({
          sendData: data,
          resultData: result,
        });

        const response = await saveData.save();

        resolve(response);
      });
    });
  }

  async getTokenByConversationId(query: any) {
    const { conversationId } = query;

    const payment: any = await this.paymentModel
      .findOne(
        { 'resultData.conversationId': conversationId },
        { resultData: 1 },
      )
      .lean();

    return payment.resultData.token;
  }
}
