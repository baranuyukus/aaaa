import { Module } from '@nestjs/common';
import { PaymentService } from './payment.service';
import { PaymentController } from './payment.controller';
import { Payment, PaymentSchema } from 'src/schemas/payment.schema';
import { MongooseModule } from '@nestjs/mongoose';
import Iyzipay from 'iyzipay';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Payment.name, schema: PaymentSchema }]),
  ],
  providers: [
    PaymentService,
    {
      provide: 'Iyzipay',
      useValue: new Iyzipay({
        apiKey: 'sandbox-YFdfirb5b8Pin3XbhCwUWWhgcP03HWnN',
        secretKey: 'sandbox-5iS1P83cdjjMsgZzGaADlEcZh8SiRP2A',
        uri: 'https://sandbox-api.iyzipay.com',
      }),
    },
  ],
  exports: [PaymentService],
  controllers: [PaymentController],
})
export class PaymentModule {}
