import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AdvertService } from './advert.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { AdvertDto } from '../product/dto/advert.dto';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';

@UseGuards(JwtAuthGuard)
@Controller('advert')
export class AdvertController {
  constructor(private readonly advertService: AdvertService) { }

  @Get()
  getUserAdverts(@CurrentUser() currentUser) {
    return this.advertService.getUserAdverts(currentUser._id);
  }

  @Get(":advertId")
  getAdvertById(@Param("advertId") advertId: string) {
    console.log(advertId)
    return this.advertService.getAdvertById(advertId);
  }

  @Get("sellerQuery/:groupId")
  sellerQuery(@CurrentUser() currentUser, @Param("groupId", new ParseObjectIdPipe()) groupId: ObjectId) {
    return this.advertService.sellerQuery(currentUser, groupId);
  }

  @Post()
  createAdvert(@CurrentUser() currentUser, @Body() AdvertDto: { stock: string, data: any }) {
    return this.advertService.createAdvert(currentUser._id, AdvertDto);
  }

  @Put('/:advertId')
  updateAdvert(
    @CurrentUser() currentUser,
    @Param('advertId', new ParseObjectIdPipe()) advertId: ObjectId,
    @Body() dto,
  ) {
    return this.advertService.updateAdvert(currentUser._id, advertId, dto);
  }

  @Delete('/:advertId')
  deleteAdvert(
    @CurrentUser() currentUser,
    @Param('advertId', new ParseObjectIdPipe()) advertId: ObjectId,
  ) {
    return this.advertService.deleteAdvert(currentUser._id, advertId);
  }

  @Get('/findOne/advert/search')
  findOneAdvert(
    @Query() query
  ) {
    return this.advertService.findOneAdvert(query);
  }
}
