import { Module } from '@nestjs/common';
import { AdvertController } from './advert.controller';
import { AdvertService } from './advert.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Offer, OfferSchema } from 'src/schemas/offer.schema';
import { Advert, AdvertSchema } from 'src/schemas/advert.schema';
import { User, UserSchema } from 'src/schemas/user.schema';
import { Brand, BrandSchema } from 'src/schemas/brand.schema';
import { ProductGroup, ProductGroupSchema } from 'src/schemas/product/product-group.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: Advert.name,
        schema: AdvertSchema,
      },
      {
        name: Offer.name,
        schema: OfferSchema,
      },
      {
        name: User.name,
        schema: UserSchema,
      },
      {
        name: Brand.name,
        schema: BrandSchema,
      },
      {
        name: ProductGroup.name,
        schema: ProductGroupSchema,
      },
    ]),
  ],
  controllers: [AdvertController],
  providers: [AdvertService],
})
export class AdvertModule { }
