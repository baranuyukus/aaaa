import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Advert, AdvertDocument } from 'src/schemas/advert.schema';
import { Offer, OfferDocument } from 'src/schemas/offer.schema';
import { AdvertDto } from '../product/dto/advert.dto';
import { User, UserDocument } from 'src/schemas/user.schema';
import { Brand, BrandDocument } from 'src/schemas/brand.schema';
import { ProductGroup, ProductGroupDocument } from 'src/schemas/product/product-group.schema';

@Injectable()
export class AdvertService {
  constructor(
    @InjectModel(Offer.name) private readonly offerModel: Model<OfferDocument>,
    @InjectModel(Advert.name)
    private readonly advertModel: Model<AdvertDocument>,
    @InjectModel(User.name)
    private readonly userModel: Model<UserDocument>,
    @InjectModel(Brand.name)
    private readonly brandModel: Model<BrandDocument>,
    @InjectModel(ProductGroup.name)
    private readonly productGroupModel: Model<ProductGroupDocument>,
  ) { }

  async getUserAdverts(currentUserId: ObjectId) {
    const soldAdverts = await this.advertModel
      .find({
        user: currentUserId,
        status: {
          $ne: 'PENDING',
        },
      })
      .populate([
        {
          path: 'productGroup',
          select: 'photos title brands',
        },
        {
          path: 'size',
        },
      ])
      .lean();

    const pendingAdverts = await this.advertModel
      .find({
        user: currentUserId,
        status: 'PENDING',
      })
      .populate([
        {
          path: 'productGroup',
          select: 'photos title brands',
        },
        {
          path: 'size',
        },
      ])
      .lean();

    const totalEarnings = soldAdverts.reduce(
      (prev, cur) => prev + cur.price,
      0,
    );

    return {
      soldAdverts,
      pendingAdverts,
      totalSaleCount: soldAdverts.length,
      totalEarnings,
    };
  }

  async getAdvertById(advertId: string) {
    const advert = await this.advertModel.findById(advertId)
      .populate([
        {
          path: 'productGroup',
          select: 'photos title brands',
        },
        {
          path: 'size',
        },
      ])
      .lean();
    const brandForAdvert = await this.brandModel.findById(advert.productGroup.brands[0]);
    const result = { ...advert, brand: brandForAdvert.title }

    return result;
  }

  async sellerQuery(userId: ObjectId, groupId: ObjectId) {
    const adverts = await this.advertModel.find({
      user: userId,
      productGroup: groupId
    })
      .lean();

    if (adverts.length !== 0) {
      return true
    } else {
      return false
    }
  }


  updateStockState(groupId: any, value: boolean) {
    return this.productGroupModel
      .findByIdAndUpdate(groupId, { stockState: value })
      .lean();
  }

  async createAdvert(userId: ObjectId, advertDto: { stock: string, data: any }) {
    let list = [];

    for (let i = 0; i < parseInt(advertDto.stock); i++) {

      const advert = await this.advertModel.create({
        ...advertDto.data,
        user: advertDto?.data?.user || userId,
      });

      await this.userModel.findByIdAndUpdate(
        advertDto?.data?.user || userId,
        { $inc: { advertCount: 1 } },
        { new: true }
      );

      list.push(advert);
      if (i + 1 === parseInt(advertDto.stock)) {
        const product = await this.productGroupModel.findById(list[0].productGroup).exec();
        await this.updateStockState(product._id, true);
        return { adverts: list, slug: product.slug }
      }
    }
  }

  async updateAdvert(currentUserId: ObjectId, advertId: ObjectId, dto) {
    const advert = await this.advertModel.findById(advertId).lean();
    const adverts = await this.advertModel.findOne({
      productGroup: advert.productGroup
    });
    await this.updateStockState(advert.productGroup, (adverts ? true : false));
    return this.advertModel
      .findOneAndUpdate(
        {
          _id: advertId,
          user: currentUserId,
        },
        {
          price: dto.price,
        },
      )
      .lean();
  }

  async deleteAdvert(currentUserId: ObjectId, advertId: ObjectId) {
    const user = await this.userModel.findById(currentUserId);

    const advert = await this.advertModel.findOneAndDelete({
      _id: advertId,
      user: currentUserId,
    });
    const adverts = await this.advertModel.findOne({
      productGroup: advert.productGroup
    });
    await this.updateStockState(advert.productGroup, (adverts ? true : false));
    if (advert) {
      await this.offerModel
        .deleteMany({
          advert: advertId,
        })
        .lean();

      user.advertCount -= 1;
      await user.save();
    }

    return advert;
  }

  async findOneAdvert(query) {
    const advert = await this.advertModel.findOne(query).populate("productGroup").populate("size");
    return advert;
  }
}
