import { Injectable, UploadedFile, UploadedFiles } from '@nestjs/common';
import { UploadApiErrorResponse, UploadApiResponse, v2 } from 'cloudinary';
import toStream = require('buffer-to-stream');
// import { MulterFile } from '@webundsoehne/nest-fastify-file-upload/dist/interfaces/multer-options.interface';

@Injectable()
export class MediaService {
  async uploadImage(
    // @UploadedFile('file') file: MulterFile,
    @UploadedFile() file: Express.Multer.File,
  ): Promise<UploadApiResponse | UploadApiErrorResponse> {
    return new Promise((resolve, reject) => {
      const upload = v2.uploader.upload_stream((error, result) => {
        if (error) return reject(error);
        resolve(result);
      });

      toStream(file.buffer).pipe(upload);
    });
  }

  uploadMultipleImages(@UploadedFiles() files: Express.Multer.File[]) {
    return Promise.all(
      files.map(async (file) => {
        const fileResponse = await this.uploadImage(file);
        return fileResponse;
      }),
    );
  }
}
