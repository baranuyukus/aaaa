import { v2 } from 'cloudinary';

const CLOUDINARY = 'Cloudinary';

export const MediaProvider = {
  provide: CLOUDINARY,
  useFactory: (): any => {
    return v2.config({
      cloud_name: 'dlyc459vr',
      api_key: '645633573846547',
      api_secret: 'ur3xoY0f9ZiQGCZObyzfzVhjk4w',
      secure: true,
      secure_cdn_subdomain: true,
    });
  },
};
