import { Module } from '@nestjs/common';
import { MediaService } from './media.service';
import { MediaProvider } from './media.provider';
import { MediaController } from './media.controller';

@Module({
  providers: [MediaProvider, MediaService],
  exports: [MediaProvider, MediaService],
  controllers: [MediaController],
})
export class MediaModule {}
