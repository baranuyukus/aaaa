import {
  Body,
  Controller,
  Post,
  Req,
  Res,
  UploadedFile,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { MediaService } from './media.service';
import { FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';
// import { FileInterceptor } from '@webundsoehne/nest-fastify-file-upload';

// @UseGuards(JwtAuthGuard)
@Controller('media')
export class MediaController {
  constructor(private readonly mediaService: MediaService) {}

  //tek resim yükleme
  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  uploadImage(@UploadedFile() file: Express.Multer.File) {
    return this.mediaService.uploadImage(file);
  }

  //çoklu resim yükleme
  @Post('multiple-uploads')
  @UseInterceptors(FilesInterceptor('files'))
  uploadMultipleImages(@UploadedFiles() files: Express.Multer.File[]) {
    return this.mediaService.uploadMultipleImages(files);
  }
}
