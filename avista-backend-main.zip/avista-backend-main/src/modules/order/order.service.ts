import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Order, OrderDocument } from 'src/schemas/order.schema';
import { CreateOrderDto } from './dtos/create-order.dto';
import { ProductService } from '../product/product.service';
import { Brand, BrandDocument } from 'src/schemas/brand.schema';
import {
  ProductGroup,
  ProductGroupDocument,
} from 'src/schemas/product/product-group.schema';
import { Advert, AdvertDocument } from 'src/schemas/advert.schema';
import { Offer, OfferDocument } from 'src/schemas/offer.schema';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';
import { Cargo, CargoDocument } from 'src/schemas/cargo.schema';
import { User, UserDocument } from 'src/schemas/user.schema';
import { MailerService } from '@nestjs-modules/mailer';
import getEmailTemplate from 'src/utils/emailTemplate';
import { DiscountCoupon, DiscountCouponDocument } from 'src/schemas/discount-coupon';
import sutokAddress from 'src/utils/sutokAddress';

@Injectable()
export class OrderService {
  constructor(
    private readonly configService: ConfigService,
    private readonly productService: ProductService,
    private readonly mailerService: MailerService,
    @InjectModel(Order.name) private readonly orderModel: Model<OrderDocument>,
    @InjectModel(Brand.name) private readonly brandModel: Model<BrandDocument>,
    @InjectModel(Advert.name)
    private readonly advertModel: Model<AdvertDocument>,
    @InjectModel(Offer.name)
    private readonly offerModel: Model<OfferDocument>,
    @InjectModel(ProductGroup.name)
    private readonly productGroupModel: Model<ProductGroupDocument>,
    @InjectModel(User.name)
    private readonly userModel: Model<UserDocument>,
    @InjectModel(Cargo.name)
    private readonly cargoModel: Model<CargoDocument>,
    @InjectModel(DiscountCoupon.name)
    private readonly discountCouponModel: Model<DiscountCouponDocument>,
  ) { }

  async createCargo({ senderAddress, recipientAddress }) {
    const data = {
      test: true,
      length: '40',
      height: '25',
      width: '25',
      distanceUnit: 'cm',
      weight: '1',
      massUnit: 'kg',
      items: [{ title: 'test product', quantity: 1 }],
      productPaymentOnDelivery: false,
      senderAddress,
      recipientAddress,
    };

    const response = await axios.post(
      'https://api.geliver.io/api/v1/shipments',
      data,
      {
        headers: {
          Authorization: 'Bearer ' + this.configService.get('GELIVER_TOKEN'),
          'Content-Type': 'application/json',
        },
      },
    );

    //console.log(response.data.data)
    const selectedOffer =
      response.data.data.offers.list.find(
        (item) => item.providerServiceCode === 'YURTICI_STANDART',
      ) || response.data.data.offers.cheapest;

    return await this.acceptCargoOffer(selectedOffer.id);
  }

  async acceptCargoOffer(offerID) {
    const data = {
      offerID,
    };

    const response = await axios.post(
      'https://api.geliver.io/api/v1/transactions',
      data,
      {
        headers: {
          Authorization: 'Bearer ' + this.configService.get('GELIVER_TOKEN'),
          'Content-Type': 'application/json',
        },
      },
    );
    return {
      barcode: response.data.data.shipment.barcode,
      shipmentId: response.data.data.shipment.id,
      tranckingUrl: `https://app.geliver.io/tracking/${response.data.data.shipment.id}`,
      apiTrackingUrl: `https://api.geliver.io/api/v1/tracking/${response.data.data.shipment.id}`
    };
  }

  async getCargoTrackingUrl(shipmentID) {
    const response = await axios.get(
      'https://api.geliver.io/api/v1/shipments/' + shipmentID,
      {
        headers: {
          Authorization: 'Bearer ' + this.configService.get('GELIVER_TOKEN'),
          'Content-Type': 'application/json',
        },
      },
    );
  }

  async createOrder(userId: ObjectId, createOrderDto: CreateOrderDto) {
    let advertIds = [];
    for (let i = 0; i < createOrderDto.basket.length; i++) {
      const items = await this.advertModel.find({
        productGroup: createOrderDto.basket[i]?.productGroup,
        size: createOrderDto.basket[i]?.size
      }).limit(createOrderDto.basket[i]?.quantity);

      for (let j = 0; j < items.length; j++) {
        advertIds = [...advertIds, items[i]?._id]
      }
    }
    /*const advertIds = createOrderDto.basket.map(
      (basketItem) => basketItem.advert,
    );*/
    const offerIds = createOrderDto.basket
      .filter((basketItem) => !!basketItem.offer)
      .map((basketItem) => basketItem.offer);

    const adverts = await this.advertModel.find({ _id: advertIds }).lean();
    const offers = await this.offerModel.find({ _id: offerIds }).lean();

    const advertsNormalized = adverts.reduce((prev, cur) => {
      return {
        ...prev,
        [cur._id]: cur,
      };
    }, {});

    const offersNormalized = offers.reduce((prev, cur) => {
      return {
        ...prev,
        [cur._id]: cur,
      };
    }, {});

    /*let totalAmount = 0;*/



    const basketWithPrices = await Promise.all(createOrderDto.basket.map(async (basketItem) => {
      const price = basketItem?.offer
        ? (await this.offerModel.findById(basketItem?.offer))?.price
        : (await this.advertModel.findById(basketItem?.advert))?.price;

      if (!price) throw new BadRequestException('PRODUCT_NOT_FOUND');

      return {
        advert: basketItem.advert,
        offer: basketItem.offer,
        quantity: basketItem.quantity,
        price,
      };
    }));

    //const seller = adverts[0].user;
    const sellers = [];
    if (adverts?.length !== 0) {
      // Adverts listesindeki her bir öğeyi kontrol et
      adverts?.forEach((advert, index) => {
        // Önceki öğelerde aynı kullanıcı bilgisine sahip bir öğe var mı kontrol et
        let userExists = false;
        for (let i = 0; i < index; i++) {
          if (adverts[i].user === advert.user) {
            userExists = true;
            break;
          }
        }

        // Aynı kullanıcı bilgisine sahip bir öğe yoksa yeni listeye ekle
        if (!userExists) {
          sellers.push(advert?.user);
        }
      });
    }

    let now = new Date();
    let timelines = [
      { id: 1, type: "CREATED", date: new Date(now.getTime() - 1000) },
      { id: 2, type: "PENDING", date: now },
    ];

    for (let i = 0; i < sellers.length; i++) {
      const user = await this.userModel.findById(sellers[i]);
      if (user.role === "SELLER") {
        timelines = [
          { id: 1, type: "CREATED", date: new Date(now.getTime() - 2000) },
          { id: 2, type: "PENDING", date: new Date(now.getTime() - 1000) },
          { id: 3, type: "SUTOKCARGO", date: now },
        ]
      }
    }

    const order = await this.orderModel.create({
      user: userId,
      sellers,
      basket: basketWithPrices,
      totalAmount: createOrderDto.totalAmount,
      serviceFee: createOrderDto.serviceFee,
      kdv: createOrderDto.kdv,
      cargoPrice: createOrderDto.cargoPrice,
      discountCoupon: createOrderDto?.discountCoupon ? (new mongoose.Types.ObjectId(createOrderDto?.discountCoupon)) : null,
      shippingAddress: createOrderDto.shippingAddress,
      billingAddress: createOrderDto.billingAddress,
      creditCard: createOrderDto.creditCard,
      paymentId: createOrderDto.paymentId,
      timelines
    });

    for (let i = 0; i < sellers.length; i++) {
      const user = await this.userModel.findById(sellers[i]);
      if (user.role === "SELLER") {
        await this.orderModel.findByIdAndUpdate(order?._id, { status: "SUTOKCARGO" }, { new: true })
      }
    }

    try {
      const advert = await this.advertModel
        .findById(advertIds[0], { user: 1 })
        .lean();
      const senderUser = await this.userModel
        .findById(advert.user, {
          name: 1,
          surname: 1,
          city: 1,
          district: 1,
          openAddress: 1,
          phoneNumber: 1,
          email: 1,
        })
        .lean();
      const receiverUser = await this.userModel
        .findById(userId, {
          name: 1,
          surname: 1,
          city: 1,
          district: 1,
          openAddress: 1,
          phoneNumber: 1,
          email: 1,
        })
        .lean();

      let isHaveSeller: any = false;
      for (let i = 0; i < sellers.length; i++) {
        const user = await this.userModel.findById(sellers[i]);
        if (user.role === "SELLER") {
          isHaveSeller = user;
        }
      }

      const senderAddress = !isHaveSeller ? sutokAddress : {
        name: `${senderUser.name} ${senderUser.surname}`,
        email: senderUser.email,
        //phone: "+905051234567",
        phone: senderUser.phoneNumber,
        address1: senderUser.openAddress,
        countryCode: 'TR',
        cityName: senderUser.city,
        districtName: senderUser.district,
      }
      const recipientAddress = isHaveSeller ? sutokAddress : {
        name: order.billingAddress.nameSurname,
        email: order.billingAddress.email,
        //phone: "+905051234567",
        phone: order.billingAddress.phone,
        address1: order.billingAddress.addressDefinition,
        countryCode: 'TR',
        cityCode: '45',
        districtName: order.billingAddress.district,
      }

      const trackingUrl1 = await this.createCargo({
        senderAddress: senderAddress,
        /*senderAddress: {
          name: 'Test Company Name',
          email: 'Test Email',
          phone: '+905051234567',
          address1: 'Celal Bayar Üniversitesi Teknokenti Daire 102',
          countryCode: 'TR',
          cityCode: '45',
          districtName: 'Yunusemre',
        },*/
        recipientAddress: recipientAddress,
      });

      /*const trackingUrl2 = await this.createCargo({
        senderAddress: senderAddress,
        recipientAddress: recipientAddress,
        //  senderAddress: {
        //    name: 'Test Company Name',
        //    email: 'Test Email',
        //    phone: '+905051234567',
        //    address1: 'Celal Bayar Üniversitesi Teknokenti Daire 102',
        //    countryCode: 'TR',
        //    "cityName": "Istanbul",
        //    "districtName": "Yunusemre",
        //  },
        // recipientAddress: {
        //   name: `${receiverUser.name} ${receiverUser.surname}`,
        //   email: receiverUser.email,
        //   phone: "+90505123456",
        //   // phone: createOrderDto.shippingAddress.phone,
        //   address1: createOrderDto.shippingAddress.addressDefinition,
        //   countryCode: 'TR',
        //   "cityName": "Istanbul",
        //   "districtName": "Yunusemre",
        // },
      });*/

      await this.cargoModel.create({
        trackingUrl: trackingUrl1.tranckingUrl,
        sender: 'USER',
        order: order._id,
      });

      await this.cargoModel.create({
        trackingUrl: trackingUrl1.tranckingUrl,
        sender: 'SUTOK',
        order: order._id,
      });

      await this.orderModel.findByIdAndUpdate(order._id, {
        trackingUrl: trackingUrl1.tranckingUrl,
        apiTrackingUrl: trackingUrl1.apiTrackingUrl,
        shipmentId: trackingUrl1.shipmentId,
        barcode: trackingUrl1.barcode
      })

      const receiverUserEmailTemplate = getEmailTemplate(false,
        `<div class="container">
          <h2>
            <img class="logo" src="https://sutok.com/assets/logo-7cfd6467.png" alt="logo" />
          </h2>
          <h2>${((receiverUser.name && receiverUser.surname) && `${receiverUser.name} ${receiverUser.surname}`) || (receiverUser.name && `${receiverUser.name} -`) || (receiverUser.name && `- ${receiverUser.surname}`) || receiverUser.email}</h2>
          <p class="txt6b"><a class="customRed" href="https://sutok.com">sutok.com</a> hesabınız ile yaptığınız siparişinizin kargo takip bağlantısı aşağıdadır.</p>
          <a class="customRed pl8" href="${trackingUrl1.tranckingUrl}">${trackingUrl1.tranckingUrl}</a>
          <p class="txt6b">Bu bağlantı ile kargonuzun durumunu öğrenebilirsiniz.</p>
          <div class="footer">
            <p>Sorularınız mı var? Bize <a class="customRed" href="mailto:info@sutok.com">info@sutok.com</a> adresinden e-posta gönderin.</p>
          </div>
        </div>`);


      await this.mailerService.sendMail({
        to: receiverUser.email,
        from: this.configService.get<string>('SMTP_USER'),
        subject: 'Kargo takip bağlantısı',
        html: receiverUserEmailTemplate,
      });

      const senderUserEmailTemplate = getEmailTemplate(false,
        `<div class="container">
          <h2>
            <img class="logo" src="https://sutok.com/assets/logo-7cfd6467.png" alt="logo" />
          </h2>
          <h2>${((senderUser.name && senderUser.surname) && `${senderUser.name} ${senderUser.surname}`) || (senderUser.name && `${senderUser.name} -`) || (senderUser.name && `- ${senderUser.surname}`) || senderUser.email}</h2>
          <p class="txt6b"><a class="customRed" href="https://sutok.com">sutok.com</a> hesabınız ile yaptığınız satış için gerekli bilgiler aşağıdadır.</p>
          <h4>Proje Kodu: 233930</h4>
          <h4>Sipariş Numarası: ${trackingUrl1.barcode}</h4>
          <h4>Kargo Takip Url'i: <a class="customRed" href="${trackingUrl1.tranckingUrl}">${trackingUrl1.tranckingUrl}</a></h4>
          <div class="footer">
            <p>Sorularınız mı var? Bize <a class="customRed" href="mailto:info@sutok.com">info@sutok.com</a> adresinden e-posta gönderin.</p>
          </div>
        </div>`);

      await this.mailerService.sendMail({
        from: this.configService.get<string>('SMTP_USER'),
        to: senderUser.email,
        subject: 'Sutok.com - Kargo Bilgileri',
        html: senderUserEmailTemplate,
      });

      if (isHaveSeller) {
        const emailTemplate = getEmailTemplate(false,
          `<div class="container">
            <h2>
              <img class="logo" src="https://sutok.com/assets/logo-7cfd6467.png" alt="logo" />
            </h2>
            <h2>${((isHaveSeller.name && isHaveSeller.surname) && `${isHaveSeller.name} ${isHaveSeller.surname}`) || (isHaveSeller.name && `${isHaveSeller.name} -`) || (isHaveSeller.name && `- ${isHaveSeller.surname}`) || isHaveSeller.email}</h2>
            <p class="txt6b"><a class="customRed" href="https://sutok.com">sutok.com</a> hesabınız ile yaptığınız satış tarafımıza incelenmek üzere yola çıkmıştır</p>
            <h4>Proje Kodu: 233930</h4>
            <h4>Sipariş Numarası: ${trackingUrl1.barcode}</h4>
            <h4>Kargo Takip Url'i: <a class="customRed" href="${trackingUrl1.tranckingUrl}">${trackingUrl1.tranckingUrl}</a></h4>
            <div class="footer">
              <p>Sorularınız mı var? Bize <a class="customRed" href="mailto:info@sutok.com">info@sutok.com</a> adresinden e-posta gönderin.</p>
            </div>
          </div>`);

        await this.mailerService.sendMail({
          from: this.configService.get<string>('SMTP_USER'),
          to: isHaveSeller.email,
          subject: 'Sutok.com - Kargo Bilgileri',
          html: emailTemplate,
        });
      }

    } catch (error) {
      console.log('error', error?.response?.data);
    }

    const populateOrder = await order.populate({
      path: 'basket',
      populate: {
        path: 'advert',
        populate: {
          path: 'productGroup',
        },
      },
    });

    const brandQuantityInBasket = populateOrder.basket.reduce((prev, cur) => {
      const brandId = cur.advert.productGroup.brands[0].toString();

      return {
        ...prev,
        [brandId]: prev[brandId] ? prev[brandId] + 1 : 1,
      };
    }, {});

    await Promise.all([
      ...Object.entries(brandQuantityInBasket).map(
        ([brandId, brandQuantity]) => {
          return this.brandModel.findByIdAndUpdate(brandId, {
            $inc: {
              soldCount: brandQuantity,
            },
          });
        },
      ),
      ...order.basket.map(({ advert, quantity }) => {
        return this.productGroupModel.findByIdAndUpdate(
          // @ts-ignore
          advert.productGroup._id,
          {
            $inc: {
              soldCount: quantity,
            },
          },
        );
      }),
      this.advertModel.updateMany(
        {
          _id: advertIds,
        },
        {
          status: 'SOLD',
        },
      ),
    ]);

    // Satıcının bekleyen ödemesini arttırma döngüsü
    for (let i = 0; i < advertIds?.length; i++) {
      const advert: any = await this.advertModel.findById(advertIds[i]);
      const user = await this.userModel.findById(advert?.user?._id);

      if (advert?._id && user?._id) {
        await this.userModel.findByIdAndUpdate(user?._id, { pendingPayment: (user?.pendingPayment || 0) + advert?.finalAmount });
      }
    }
    if (order?.discountCoupon) {
      const discountCoupon = await this.discountCouponModel.findById(order?.discountCoupon);
      await this.discountCouponModel.findByIdAndUpdate(order?.discountCoupon, { thoseWhoUse: [...discountCoupon?.thoseWhoUse, userId] })
    }

    return order;
  }

  async getUserOrders(userId: ObjectId) {
    const orders = await this.orderModel
      .find({
        user: userId,
      })
      .limit(10)
      .lean()
      .populate({
        path: 'basket',
        populate: {
          path: 'advert',
          populate: [
            {
              path: 'productGroup',
              populate: 'brands',
            },
            {
              path: 'size',
            },
          ],
        },
      });

    return await Promise.all(
      orders.map(async order => {
        const cargo = await this.cargoModel.findOne({ order: order._id, sender: 'USER' }, { trackingUrl: 1 }).lean();

        return {
          ...order,
          trackingUrl: cargo?.trackingUrl
        }
      })
    )
  }

  async getOrder(id: ObjectId) {
    const order = await this.orderModel
      .findOne({
        _id: id
      })
      .lean()
      .populate("user")
      .populate("discountCoupon")
      .populate({
        path: 'basket',
        populate: {
          path: 'advert',
          populate: [
            {
              path: 'productGroup',
              populate: 'brands',
            },
            {
              path: 'size',
            },
          ],
        },
      });

    return order;
  }
}

