import { Body, Controller, Post, UseGuards, Get, Param } from '@nestjs/common';
import { OrderService } from './order.service';
import { CurrentUser } from 'src/decorators/current-user';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateOrderDto } from './dtos/create-order.dto';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';

@UseGuards(JwtAuthGuard)
@Controller('order')
export class OrderController {
  constructor(private readonly orderService: OrderService) { }

  @Post()
  createOrder(
    @CurrentUser() currentUser,
    @Body() createOrderDto: CreateOrderDto,
  ) {
    return this.orderService.createOrder(currentUser._id, createOrderDto);
  }

  @Get()
  getUserOrders(@CurrentUser() currentUser) {
    return this.orderService.getUserOrders(currentUser._id);
  }

  @Get(":id")
  getOrder(@Param("id", new ParseObjectIdPipe()) id: ObjectId) {
    return this.orderService.getOrder(id);
  }
}
