import {
  IsArray,
  ValidateNested,
  ArrayMinSize,
  IsMongoId,
  IsNumber,
  Min,
  IsNotEmpty,
  IsOptional,
  IsObject,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ObjectId, Types } from 'mongoose';
import { CreditCard } from 'src/schemas/credit-card.schema';

class OrderProduct {
  @IsMongoId()
  advert: Types.ObjectId;

  @IsMongoId()
  size: Types.ObjectId;

  @IsMongoId()
  productGroup: Types.ObjectId;

  @IsMongoId()
  @IsOptional()
  offer: Types.ObjectId;

  @IsNumber()
  @Min(1)
  quantity: number;
}

export class CreateOrderDto {
  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(1)
  @Type(() => OrderProduct)
  basket: OrderProduct[];

  @IsObject()
  @IsNotEmpty()
  billingAddress: any;

  @IsObject()
  @IsNotEmpty()
  shippingAddress: any;

  @IsObject()
  @IsNotEmpty()
  creditCard: any;

  @IsMongoId()
  @IsNotEmpty()
  paymentId: any;

  @IsNumber()
  @IsNotEmpty()
  totalAmount: any;

  @IsNumber()
  @IsNotEmpty()
  cargoPrice: number;

  @IsNumber()
  @IsNotEmpty()
  serviceFee: number;

  @IsNumber()
  @IsNotEmpty()
  kdv: number;

  discountCoupon: any;
}
