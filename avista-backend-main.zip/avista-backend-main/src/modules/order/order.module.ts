import { Module } from '@nestjs/common';
import { OrderController } from './order.controller';
import { OrderService } from './order.service';
import { MongooseModule, getConnectionToken } from '@nestjs/mongoose';
import { Order, OrderSchema } from 'src/schemas/order.schema';
import { ProductModule } from '../product/product.module';
import { Brand, BrandSchema } from 'src/schemas/brand.schema';
import { Product, ProductSchema } from 'src/schemas/product/product.schema';
import {
  ProductGroup,
  ProductGroupSchema,
} from 'src/schemas/product/product-group.schema';
import { Advert, AdvertSchema } from 'src/schemas/advert.schema';
import { Offer, OfferSchema } from 'src/schemas/offer.schema';
import { AutoIncrementFactory } from 'src/utils/auto-increment-plugin';
import { Connection } from 'mongoose';
import { Cargo, CargoSchema } from 'src/schemas/cargo.schema';
import { User, UserSchema } from 'src/schemas/user.schema';
import { Address, AddressSchema } from 'src/schemas/address.schema';
import { ConfigService } from '@nestjs/config';
import { MailerModule } from '@nestjs-modules/mailer';
import { DiscountCoupon, DiscountCouponSchema } from 'src/schemas/discount-coupon';

@Module({
  imports: [
    MailerModule.forRootAsync({
      useFactory: async (configService: ConfigService) => ({
        transport: {
          host: configService.get<string>('SMTP_HOST'),
          port: configService.get<number>('SMTP_PORT'),
          secure: false, // upgrade later with STARTTLS
          auth: {
            user: configService.get<string>('SMTP_USER'),
            pass: configService.get<string>('SMTP_PASSWORD'),
          },
          tls: {
            // do not fail on invalid certs
            rejectUnauthorized: false,
          },
        },
      }),
      inject: [ConfigService],
    }),
    MongooseModule.forFeatureAsync([
      {
        name: Order.name,
        useFactory: async (connection: Connection) => {
          const schema = OrderSchema;
          const AutoIncrement = AutoIncrementFactory(connection);

          return schema.plugin(AutoIncrement, {
            id: 'identifier',
            forCompany: false,
          });
        },
        inject: [getConnectionToken()],
      },
    ]),
    MongooseModule.forFeature([
      {
        name: Brand.name,
        schema: BrandSchema,
      },
      {
        name: Product.name,
        schema: ProductSchema,
      },
      {
        name: ProductGroup.name,
        schema: ProductGroupSchema,
      },
      {
        name: Advert.name,
        schema: AdvertSchema,
      },
      {
        name: Offer.name,
        schema: OfferSchema,
      },
      {
        name: Cargo.name,
        schema: CargoSchema
      },
      {
        name: User.name,
        schema: UserSchema
      },
      {
        name: Address.name,
        schema: AddressSchema
      },
      {
        name: DiscountCoupon.name,
        schema: DiscountCouponSchema
      }
    ]),
    ProductModule,
  ],
  controllers: [OrderController],
  providers: [OrderService],
})
export class OrderModule {}
