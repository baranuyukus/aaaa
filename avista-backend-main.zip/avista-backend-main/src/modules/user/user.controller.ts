import {
  Body,
  Controller,
  Delete,
  Post,
  Put,
  UseGuards,
  Param,
  Get,
  Query,
} from '@nestjs/common';
import { CurrentUser } from 'src/decorators/current-user';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { UserService } from './user.service';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';
import { HelpCenterDto } from './dto/help-center.dto';
import { QueryDto } from '../product/dto/query.dto';

@UseGuards(JwtAuthGuard)
@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) { }

  @Get()
  getProfile(@CurrentUser() currentUser) {
    return this.userService.getProfile(currentUser._id);
  }

  @Put('vacation-mode')
  setVacationMode(@CurrentUser() currentUser, @Body() body) {
    return this.userService.setVacationMode(currentUser._id, body);
  }

  @Delete('delete-account')
  deleteAccount(@CurrentUser() currentUser) {
    return this.userService.deleteAccount(currentUser._id);
  }

  @Put('update-profile')
  updateProfile(@CurrentUser() currentUser, @Body() updateProfileDto) {
    return this.userService.updateProfile(currentUser._id, updateProfileDto);
  }

  @Put('/product/:id/:sizeId')
  addFavoriteProduct(
    @CurrentUser() currentUser,
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
    @Param('sizeId', new ParseObjectIdPipe()) sizeId: ObjectId,
  ) {
    return this.userService.addFavoriteProduct(currentUser._id, id, sizeId);
  }

  @Get('/favorites')
  getFavoriteProducts(@CurrentUser() currentUser) {
    return this.userService.getFavoriteProducts(currentUser._id);
  }

  @Put('/mostviewed/:id')
  addMostViewedProduct(
    @CurrentUser() currentUser,
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ) {
    return this.userService.addMostViewedProduct(currentUser._id, id);
  }

  @Post('/help')
  getHelp(@CurrentUser() currentUser, @Body() helpCenterDto: HelpCenterDto) {
    return this.userService.getHelp(currentUser._id, helpCenterDto);
  }

  @Post('/sellerRequests')
  createSellerRequests(@Body() body) {
    return this.userService.createSellerRequests(body);
  }
}
