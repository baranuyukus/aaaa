/* eslint-disable prettier/prettier */
import { IsNotEmpty, IsString } from 'class-validator';

export class UpdateFeesDto {
    @IsNotEmpty()
    @IsString()
    userId: string;

    @IsNotEmpty()
    @IsString()
    commissionFee: string;

    @IsNotEmpty()
    @IsString()
    serviceFee: number;
}
