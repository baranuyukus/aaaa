import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from '../../schemas/user.schema';
import { UserController } from './user.controller';
import { UserService } from './user.service';
import {
  ProductGroup,
  ProductGroupSchema,
} from 'src/schemas/product/product-group.schema';
import { HelpCenter, HelpCenterSchema } from 'src/schemas/help-center.schema';
import { Advert, AdvertSchema } from 'src/schemas/advert.schema';
import { ProductAttributeTerm, ProductAttributeTermSchema } from 'src/schemas/product/product-attribute-term.schema';
import { Brand, BrandSchema } from 'src/schemas/brand.schema';
import { SellerRequests, SellerRequestsSchema } from 'src/schemas/sellerRequests.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: User.name,
        schema: UserSchema,
      },
      {
        name: Advert.name,
        schema: AdvertSchema,
      },
      {
        name: ProductGroup.name,
        schema: ProductGroupSchema,
      },
      {
        name: ProductAttributeTerm.name,
        schema: ProductAttributeTermSchema,
      },
      {
        name: Brand.name,
        schema: BrandSchema,
      },
      {
        name: HelpCenter.name,
        schema: HelpCenterSchema,
      },
      {
        name: SellerRequests.name,
        schema: SellerRequestsSchema
      },
    ]),
  ],
  controllers: [UserController],
  providers: [UserService],
  exports: [UserService],
})
export class UserModule { }
