import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { User, UserDocument } from '../../schemas/user.schema';
import { HelpCenterDto } from './dto/help-center.dto';
import { HelpCenter, HelpCenterDocument } from 'src/schemas/help-center.schema';
import { Advert, AdvertDocument } from 'src/schemas/advert.schema';
import { ProductAttributeTerm, ProductAttributeTermDocument } from 'src/schemas/product/product-attribute-term.schema';
import { ProductGroup, ProductGroupDocument } from 'src/schemas/product/product-group.schema';
import { Brand, BrandDocument } from 'src/schemas/brand.schema';
import { SellerRequests, SellerRequestsDocument } from 'src/schemas/sellerRequests.schema';

@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
    @InjectModel(Advert.name)
    private readonly advertModel: Model<AdvertDocument>,
    @InjectModel(ProductGroup.name)
    private readonly productModel: Model<ProductGroupDocument>,
    @InjectModel(ProductAttributeTerm.name)
    private readonly sizeModel: Model<ProductAttributeTermDocument>,
    @InjectModel(Brand.name)
    private readonly brandModel: Model<BrandDocument>,
    @InjectModel(HelpCenter.name)
    private readonly helpCenterModel: Model<HelpCenterDocument>,
    @InjectModel(SellerRequests.name)
    private readonly sellerRequestsModel: Model<SellerRequestsDocument>,
  ) { }

  getProfile(currentUserId: ObjectId) {
    return this.userModel.findById(currentUserId).lean();
  }

  async setVacationMode(currentUserId: ObjectId, dto) {
    const updatedUser = await this.userModel.findByIdAndUpdate(
      currentUserId,
      {
        vacationMode: dto.vacationMode,
      },
      {
        new: true,
        lean: true,
      },
    );

    await this.advertModel
      .updateMany(
        {
          user: currentUserId,
        },
        {
          vacationMode: dto.vacationMode,
        },
        {
          projection: {
            _id: 1,
          },
        },
      )
      .lean();

    return updatedUser;
  }

  deleteAccount(currentUserId: ObjectId) {
    return this.userModel.findByIdAndDelete(currentUserId).lean();
  }

  async updateProfile(currentUserId: ObjectId, updateProfileDto) {
    const user = await this.userModel.findById(currentUserId);

    const updatedUser = await this.userModel.findByIdAndUpdate(currentUserId, updateProfileDto, { new: true })

    if (user.vacationMode !== updatedUser.vacationMode) {
      await this.setVacationMode(currentUserId, updatedUser);
    }

    return updatedUser;
  }

  async addFavoriteProduct(currentUserId: ObjectId, id: ObjectId, sizeId: ObjectId) {
    const user = await this.userModel.findById(currentUserId);

    // Grup dizisindeki ürünün index'ini bul
    const productGroup = user.group.find(
      (product) => product._id.toString() == id.toString(),
    );

    if (productGroup) {
      const user = await this.userModel.findByIdAndUpdate(
        currentUserId,
        {
          $pull: { group: productGroup },
        },
        { new: true },
      );
      return user;
    } else {
      const user = await this.userModel.findByIdAndUpdate(
        currentUserId,
        {
          $push: { group: { _id: id, size: sizeId } },
        },
        { new: true },
      );
      return user;
    }
  }

  async getFavoriteProducts(currentUserId: ObjectId) {
    const user = await this.userModel.findById(currentUserId);
    const favorites = await Promise.all(
      user.group.map(async (favorite) => {
        const productPromise = await this.productModel.findById(favorite._id);
        const sizePromise = this.sizeModel.findById(favorite.size);
        const brandPromise = this.brandModel.findById(productPromise.brands[0]);

        const [product, size, brand] = await Promise.all([productPromise, sizePromise, brandPromise]);

        return {
          ...product,
          size: size, // veya sadece size (gerekirse)
          brand: brand, // veya sadece brand (gerekirse)
        };
      })
    );

    return favorites;
  }



  async addMostViewedProduct(currentUserId: ObjectId, id: ObjectId) {
    const user = await this.userModel.findByIdAndUpdate(
      currentUserId,
      {
        $push: { mostViewed: id },
      },
      { new: true },
    );
    return user;
  }

  async getHelp(currentUserId: ObjectId, helCenterDto: HelpCenterDto) {
    const user = await this.userModel.findById(currentUserId);

    if (!user) {
      throw new NotFoundException(`User not found`);
    }

    const helpCenter = await this.helpCenterModel.create({
      user: currentUserId,
      ...helCenterDto,
    });

    return helpCenter;
  }

  async createSellerRequests(body) {
    if (body.createdBy) {
      body.createdBy = new mongoose.Types.ObjectId(body.createdBy)
    }
    const newSellerRequests = await this.sellerRequestsModel.create(body);
    return newSellerRequests;
  }
}
