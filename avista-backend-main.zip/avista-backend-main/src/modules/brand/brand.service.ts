import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Brand, BrandDocument } from 'src/schemas/brand.schema';

@Injectable()
export class BrandService {
  constructor(
    @InjectModel(Brand.name)
    private readonly brandModel: Model<BrandDocument>,
  ) { }

  findAllBrands() {
    return this.brandModel.find().populate('category').lean();
  }

  async findBrandsForCategory(id: string): Promise<Brand[]> {
    const brands = await this.brandModel.find({
      category: id
    });

    if (!brands) {
      throw new NotFoundException(`Brands not found`);
    }

    return brands;
  }

  async findPopularBrands(): Promise<Brand[]> {
    const brands = await this.brandModel.find({
      popularityStatus: true
    }).limit(5);
    return brands;
  }

  async findBrandById(id: ObjectId): Promise<Brand> {
    const brand = await this.brandModel.findById(id);

    if (!brand) {
      throw new NotFoundException(`Brand not found`);
    }
    return brand;
  }
}
