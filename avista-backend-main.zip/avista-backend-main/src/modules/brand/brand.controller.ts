import { Controller, Get, Param } from '@nestjs/common';
import { BrandService } from './brand.service';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';
import { Brand } from 'src/schemas/brand.schema';

@Controller('brands')
export class BrandController {
  constructor(private brandService: BrandService) { }

  @Get()
  findAllBrands() {
    return this.brandService.findAllBrands();
  }

  @Get("/forCategory/:id")
  findBrandsForCategory(@Param("id") categoryId: string) {
    return this.brandService.findBrandsForCategory(categoryId);
  }

  @Get('/popular')
  findPopularBrands(): Promise<Brand[]> {
    return this.brandService.findPopularBrands();
  }

  @Get('/:id')
  findBrandById(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<Brand> {
    return this.brandService.findBrandById(id);
  }
}
