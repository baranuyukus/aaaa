import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LocalAuthGuard } from './guards/local-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { RegisterDto, RegisterDtoForSeller } from './dto/register.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @UseGuards(LocalAuthGuard)
  @Post('login')
  login(@CurrentUser() currentUser) {
    return this.authService.login(currentUser);
  }

  @Post('register')
  register(@Body() registerDto: (RegisterDto|RegisterDtoForSeller)) {
    return this.authService.register(registerDto);
  }

  @Post('google')
  loginViaGoogle(@Body() loginViaGoogleDto) {
    return this.authService.loginViaGoogle(loginViaGoogleDto);
  }

  @Post('apple')
  loginViaApple(@Body() loginViaAppleDto) {
    return this.authService.loginViaApple(loginViaAppleDto);
  }

  @Post('facebook')
  loginViaFacebook(@Body() loginViaFacebookDto) {
    return this.authService.loginViaFacebook(loginViaFacebookDto);
  }

  @Post('forget-password')
  forgetPassword(@Body('email') email: string) {
    return this.authService.forgetPassword(email);
  }

  @Post('reset-password')
  resetPassword(@Body() dto: any) {
    return this.authService.resetPassword(dto);
  }

  @Post('check-reset-password-token')
  checkResetPasswordToken(@Body() dto: any) {
    return this.authService.checkResetPasswordToken(dto);
  }

  @Get('/agreement/:type')
  getAgreementContent(@Param('type') type: string) {
    return this.authService.getAgreementContent(type);
  }
}
