import {
  Injectable,
  BadRequestException,
  UnauthorizedException,
} from '@nestjs/common';
import axios from 'axios';
import { User, UserDocument } from '../../schemas/user.schema';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { JwtService } from '@nestjs/jwt';
import verifyAppleToken from 'verify-apple-id-token';
import { RegisterDto, RegisterDtoForSeller } from './dto/register.dto';
import * as bcrypt from 'bcrypt';
import { ConfigService } from '@nestjs/config';
import { MailerService } from '@nestjs-modules/mailer';
import { Agreements, AgreementsDocument } from 'src/schemas/agreements.schema';
import getEmailTemplate from 'src/utils/emailTemplate';
const fs = require('fs');

@Injectable()
export class AuthService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly mailerService: MailerService,
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
    @InjectModel(Agreements.name)
    private readonly agreementsModel: Model<AgreementsDocument>,
  ) { }

  async validateUser(email: string, password: string) {
    const user = await this.userModel.findOne({ email });

    if (!user) {
      throw new UnauthorizedException('USER_IS_NOT_EXISTS');
    }

    const isPasswordMatch = await bcrypt.compare(password, user.password);

    if (!isPasswordMatch) throw new UnauthorizedException('WRONG_PASSWORD');

    return user;
  }

  async login(user: any) {
    const newUserPayload = { _id: user._id };

    return {
      user,
      accessToken: this.jwtService.sign(newUserPayload),
    };
  }

  async register(registerDto: (RegisterDto | RegisterDtoForSeller)) {
    const isUserExists = await this.userModel.findOne({
      email: registerDto.email,
    });

    if (!!isUserExists) {
      throw new BadRequestException('EMAIL_IS_EXISTS');
    }

    const user = await this.userModel.create({
      authType: 'EMAIL',
      ...registerDto,
      role: registerDto.role === 'SELLER' ? 'SELLER' : 'NONE',
    });

    const newUserPayload = { _id: user._id };

    return {
      user,
      accessToken: this.jwtService.sign(newUserPayload),
    };
  }

  async loginViaGoogle(loginViaGoogleDto) {
    const { data } = await axios.get(
      `https://oauth2.googleapis.com/tokeninfo?id_token=${loginViaGoogleDto.token}`,
    );

    const existingUser = await this.userModel.findOne({
      authType: 'GOOGLE',
      authId: data.sub,
    });

    if (!existingUser) {
      const newUser = await this.userModel.create({
        authType: 'GOOGLE',
        authId: data.sub,
        name: data.name,
      });

      const newUserPayload = { _id: newUser._id };

      return {
        user: newUser,
        accessToken: this.jwtService.sign(newUserPayload),
      };
    }

    const existingUserPayload = { _id: existingUser._id };

    return {
      user: existingUser,
      accessToken: this.jwtService.sign(existingUserPayload),
    };
  }

  async loginViaApple(loginViaAppleDto) {
    const { identityToken } = loginViaAppleDto;

    const data = await verifyAppleToken({
      idToken: identityToken,
      clientId: 'com.kutamericano.app',
    });
    const existingUser = await this.userModel.findOne({
      authType: 'APPLE',
      authId: data.sub,
    });

    if (!existingUser) {
      const newUser = await this.userModel.create({
        authType: 'APPLE',
        authId: data.sub,
        name: 'noname',
      });

      const newUserPayload = { _id: newUser._id };

      return {
        user: newUser,
        accessToken: this.jwtService.sign(newUserPayload),
      };
    }

    const existingUserPayload = { _id: existingUser._id };

    return {
      user: existingUser,
      accessToken: this.jwtService.sign(existingUserPayload),
    };
  }

  async loginViaFacebook(loginViaFacebookDto) {
    const { data } = await axios.get(
      `https://graph.facebook.com/me?access_token=${loginViaFacebookDto.token}&fields=picture,name`,
    );

    const existingUser = await this.userModel.findOne({
      authType: 'FACEBOOK',
      authId: data.id,
    });

    if (!existingUser) {
      const newUser = await this.userModel.create({
        authType: 'FACEBOOK',
        authId: data.id,
        name: 'noname',
      });

      const newUserPayload = { _id: newUser._id };

      return {
        user: newUser,
        accessToken: this.jwtService.sign(newUserPayload),
      };
    }

    const existingUserPayload = { _id: existingUser._id };

    return {
      user: existingUser,
      accessToken: this.jwtService.sign(existingUserPayload),
    };
  }

  async forgetPassword(email: string) {
    const user = await this.userModel.findOne({ email });

    if (!user) {
      throw new BadRequestException('Kullanıcı bulunamadı.');
    }

    const resetPasswordToken = user.getResetPasswordTokenFromUser();

    console.log('resetPasswordToken', resetPasswordToken);

    await user.save();

    const emailTemplate = getEmailTemplate(false,
      `<div class="container">
          <h2>
            <img class="logo" src="https://sutok.com/assets/logo-7cfd6467.png" alt="logo" />
          </h2>
          <h2>${((user.name && user.surname) && `${user.name} ${user.surname}`) || (user.name && `${user.name} -`) || (user.name && `- ${user.surname}`) || user.email}</h2>
          <p class="txt6b"><a class="customRed" href="https://sutok.com">sutok.com</a> hesabınız için bir şifre değiştirme talebi aldık.</p>
          <p class="txt6b">Bu şifre değişikliğini siz talep ettiyseniz, aşağıdaki kodu kullanarak şifrenizi sıfırlayabilirsiniz:</p>
          <a class="code-button">${resetPasswordToken?.resetPasswordToken}</a>
          <p class="txt6b">Bu talebi siz yapmadıysanız, bu mesajı dikkate almayarak şifrenizin aynı kalmasını sağlayabilirsiniz.</p>
          <div class="footer">
            <p>Sorularınız mı var? Bize <a class="customRed" href="mailto:info@sutok.com">info@sutok.com</a> adresinden e-posta gönderin.</p>
          </div>
        </div>`);

    try {
      await this.mailerService.sendMail({
        to: email,
        from: this.configService.get<string>('SMTP_USER'),
        subject: 'Şifre Sıfırlama Talebi',
        html: emailTemplate,
      });
    } catch (error) {
      console.error(error);
    }

    return { success: true };
  }

  async resetPassword({ resetPasswordToken, password, email }: any) {
    const user = await this.userModel.findOne({
      email,
      resetPasswordToken,
      resetPasswordExpires: { $gt: Date.now() },
    });

    if (!user) {
      throw new BadRequestException('Gecersiz ya da süresi dolmus token');
    }

    user.password = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;

    await user.save();

    return { success: true };
  }

  async checkResetPasswordToken({
    resetPasswordToken,
    email,
  }: {
    resetPasswordToken: string;
    email: string;
  }) {
    const user = await this.userModel.findOne({
      resetPasswordToken,
      email,
      resetPasswordExpires: { $gt: Date.now() },
    });

    if (!user) {
      throw new BadRequestException(
        'girmis oldugunuz kod yanlıs ya da suresi dolmus!',
      );
    }

    return { success: true };
  }

  async getAgreementContent(type: string) {
    const res = await this.agreementsModel.findOne({ type }).lean();

    if (!res) {
      return {
        type,
        content: '',
      };
    }

    return res;
  }
}
