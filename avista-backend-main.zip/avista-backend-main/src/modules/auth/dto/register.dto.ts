import { IsString, IsEmail, IsEnum } from 'class-validator';

export class RegisterDto {
  @IsEmail(
    {},
    {
      message: 'Geçersiz Mail',
    },
  )
  email: string;

  @IsString()
  password: string;

  @IsEnum(['NONE', 'SELLER'])
  role: string;

  @IsString()
  name: string;

  @IsString()
  surname: string;

  @IsString()
  identityNumber: string;

  @IsString()
  gender: string;

  @IsString()
  birthDate: Date;

  @IsString()
  phoneNumber: string;

  @IsString()
  city: string;

  @IsString()
  district: string;

  @IsString()
  openAddress: string;
}

export class RegisterDtoForSeller extends RegisterDto  {
  
  @IsString()
  companyName: string;

  @IsString()
  vkn: string;

  @IsString()
  vd: string;
}
