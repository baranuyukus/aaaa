import { Module } from '@nestjs/common';
import { DiscountCouponController } from './discountcoupon.controller';
import { DiscountCouponService } from './discountcoupon.service';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from 'src/schemas/user.schema';
import { DiscountCoupon, DiscountCouponSchema } from 'src/schemas/discount-coupon';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: DiscountCoupon.name, schema: DiscountCouponSchema },
      {
        name: User.name,
        schema: UserSchema,
      },
    ]),
  ],
  controllers: [DiscountCouponController],
  providers: [DiscountCouponService],
})
export class DiscountCouponModule { }
