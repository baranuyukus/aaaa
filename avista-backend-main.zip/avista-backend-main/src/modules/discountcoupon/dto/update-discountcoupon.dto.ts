import { IsArray, IsNumber, IsString } from 'class-validator';

export class UpdateDiscountCouponDto {
    @IsString()
    couponCode: string;

    @IsNumber()
    discountRate: number;

    @IsArray()
    thoseWhoUse: string[];
}
