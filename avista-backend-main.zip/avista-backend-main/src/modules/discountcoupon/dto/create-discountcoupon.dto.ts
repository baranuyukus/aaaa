import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateDiscountCouponDto {
  @IsString()
  @IsNotEmpty()
  couponCode: string;

  @IsNotEmpty()
  @IsNumber()
  discountRate: number;
}
