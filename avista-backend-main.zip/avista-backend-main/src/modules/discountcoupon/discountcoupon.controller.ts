import {
  Controller,
  Post,
  UseGuards,
  Body,
  Get,
  Delete,
  Param,
  Query,
  Put,
} from '@nestjs/common';
import { DiscountCouponService } from './discountcoupon.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { CreateDiscountCouponDto } from './dto/create-discountcoupon.dto';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';
import { UpdateDiscountCouponDto } from './dto/update-discountcoupon.dto';

@UseGuards(JwtAuthGuard)
@Controller('discountcoupons')
export class DiscountCouponController {
  constructor(private discountCouponService: DiscountCouponService) { }

  @Post()
  createDiscountCoupon(
    @Body() createDiscountCouponDto: CreateDiscountCouponDto,
  ) {
    return this.discountCouponService.createDiscountCoupon(createDiscountCouponDto);
  }

  @Get()
  listDiscountCoupons(@Query() query) {
    return this.discountCouponService.listDiscountCoupons(query);
  }

  @Get("/findOne")
  findOne(@CurrentUser() currentUser, @Query() query) {
    return this.discountCouponService.findOne(currentUser?._id, query);
  }

  @Delete('/:id')
  deleteDiscountCoupon(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.discountCouponService.deleteDiscountCoupon(id);
  }

  @Put('/:id')
  updateDiscountCoupon(@Param('id', new ParseObjectIdPipe()) id: ObjectId, @Body() body: UpdateDiscountCouponDto) {
    return this.discountCouponService.updateDiscountCoupon(id, body);
  }
}
