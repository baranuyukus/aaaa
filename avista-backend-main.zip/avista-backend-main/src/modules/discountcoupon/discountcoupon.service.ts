import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { User, UserDocument } from 'src/schemas/user.schema';
import { CreateDiscountCouponDto } from './dto/create-discountcoupon.dto';
import { DiscountCoupon, DiscountCouponDocument } from 'src/schemas/discount-coupon';
import { UpdateDiscountCouponDto } from './dto/update-discountcoupon.dto';

@Injectable()
export class DiscountCouponService {
  constructor(
    @InjectModel(DiscountCoupon.name)
    private readonly discountcouponModel: Model<DiscountCouponDocument>,
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
  ) { }

  async createDiscountCoupon(createDiscountCouponDto: CreateDiscountCouponDto) {
    const discountCoupon = await this.discountcouponModel.findOne({ couponCode: createDiscountCouponDto.couponCode });

    if (!discountCoupon) {
      const newDiscountCoupon = await this.discountcouponModel.create({
        ...createDiscountCouponDto,
        thoseWhoUse: []
      });

      return newDiscountCoupon;
    } else {
      return { isThereDiscountCoupon: true };
    }
  }

  async listDiscountCoupons(query) {
    const filter: any = {};
    const limit = parseInt(query.limit)
    const skip = (parseInt(query.page) - 1) * limit;

    if (query.filterName) {
      filter.couponCode = { $regex: query.filterName, $options: 'i' };
    }

    const totalCount = await this.discountcouponModel.count(filter);
    const totalPage = Math.ceil(totalCount / limit);

    const discountCoupons = await this.discountcouponModel
      .find(filter)
      .skip(skip)
      .limit(limit)
      .populate("thoseWhoUse")
      .sort({ createdAt: -1 });

    return {
      page: discountCoupons,
      totalPage,
      totalCount
    }
  }

  async findOne(userId, data) {
    const discountCoupon = await this.discountcouponModel.findOne({ ...data, thoseWhoUse: { $ne: userId } });
    return discountCoupon;
  }

  async updateDiscountCoupon(id: ObjectId, data: UpdateDiscountCouponDto) {
    const findDiscountCoupon = await this.discountcouponModel.findOne({ couponCode: data.couponCode });

    if (findDiscountCoupon?._id?.toString() !== id?.toString() && findDiscountCoupon?.couponCode === data.couponCode) {
      return { isThereDiscountCoupon: true };
    } else {
      const updatedDiscountCoupon = await this.discountcouponModel.findByIdAndUpdate(id, { ...data }, { new: true });
      return updatedDiscountCoupon;
    }
  }

  async deleteDiscountCoupon(id: ObjectId) {
    const discountCoupon = await this.discountcouponModel.findByIdAndDelete(id);

    if (!discountCoupon) {
      throw new NotFoundException(`Discount Coupon not found`);
    }

    return discountCoupon;
  }
}
