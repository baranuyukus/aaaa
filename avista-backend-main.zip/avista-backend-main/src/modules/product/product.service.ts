import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Product, ProductDocument } from '../../schemas/product/product.schema';
import {
  ProductAttributeTerm,
  ProductAttributeTermDocument,
} from 'src/schemas/product/product-attribute-term.schema';
import {
  ProductGroup,
  ProductGroupDocument,
} from 'src/schemas/product/product-group.schema';
import {
  ProductAttribute,
  ProductAttributeDocument,
} from 'src/schemas/product/product-attribute.schema';
import { QueryDto } from './dto/query.dto';
import { Advert, AdvertDocument } from 'src/schemas/advert.schema';
import { Brand, BrandDocument } from 'src/schemas/brand.schema';
import { Slider, SliderDocument } from 'src/schemas/slider.schema';
import {
  ProductModel,
  ProductModelDocument,
} from 'src/schemas/product-model.schema';
import {
  HomeSection,
  HomeSectionDocument,
} from 'src/schemas/home-section.schema';
import { isArray } from 'class-validator';

@Injectable()
export class ProductService {
  constructor(
    @InjectModel(ProductGroup.name)
    private readonly productGroupModel: Model<ProductGroupDocument>,
    @InjectModel(Product.name)
    private readonly productModel: Model<ProductDocument>,
    @InjectModel(ProductModel.name)
    private readonly productModelModel: Model<ProductModelDocument>,
    @InjectModel(ProductAttribute.name)
    private readonly productAttributeModel: Model<ProductAttributeDocument>,
    @InjectModel(ProductAttributeTerm.name)
    private readonly productAttributeTermModel: Model<ProductAttributeTermDocument>,
    @InjectModel(Advert.name)
    private readonly advertModel: Model<AdvertDocument>,
    @InjectModel(Brand.name) private readonly brandModel: Model<BrandDocument>,
    @InjectModel(Slider.name)
    private readonly sliderModel: Model<SliderDocument>,
    @InjectModel(HomeSection.name)
    private readonly homeSectionModel: Model<HomeSectionDocument>,
  ) { }

  getProductsByIds(productIds: ObjectId[]) {
    return this.productModel
      .find({
        _id: productIds,
      })
      .lean();
  }

  async getProducts(query: QueryDto) {
    const filter: any = {};
    const sort: any = {};
    let models = [];

    if (query.sectionId) {
      const { products: sectionProducts } = await this.homeSectionModel
        .findOne({ slug: query.sectionId }, { products: 1 })
        .lean();
      filter._id = { $in: sectionProducts };
    }

    if (query.sortBy === 'price_asc') {
      sort.price = 1;
    } else if (query.sortBy === 'price_desc') {
      sort.price = -1;
    } else if (query.sortBy === 'date_asc') {
      sort.date = 1;
    }

    if (query.modelId) {
      const model = await this.productModelModel
        .findOne({ slug: query.modelId }, { _id: 1 })
        .lean();

      models = [model._id];
      filter.models = { $in: models }
    }

    if (query.brands) {
      let brands = [];
      for (let i = 0; i < query.brands.length; i++) {
        if (query.brands[i].includes("-")) {
          const brandData = await this.brandModel.findOne({ slug: query.brands[i] })
          brands.push(brandData._id);
        } else {
          const brandData = await this.brandModel.findById(query.brands[i]);
          brands.push(brandData._id);
        }
      }
      filter.brands = { $in: brands }
    }
    if (query.models) {
      for (let i = 0; i < query.models.length; i++) {
        if (query.models[i].includes("-")) {
          const modelData = await this.productModelModel.findOne({ slug: query.models[i] })
          models.push(modelData._id);
        } else {
          const modelData = await this.productModelModel.findById(query.models[i]);
          models.push(modelData._id);
        }
      }
      filter.models = { $in: models }
    }

    if (query.categories?.length) {
      filter.category = new Types.ObjectId(query.categories[0])
    }

    if (query.gender && query.gender !== "ALL") {
      filter.gender = query.gender;
    }

    if (query.color && query.color !== "ALL") {
      filter.color = query.color;
    }

    const countPerPage = !Number.isNaN(+query.countPerPage)
      ? +query.countPerPage
      : 20;


    if (query.searchText !== 'undefined' && !!query.searchText && query.searchText !== "" && query.searchText) {
      const searchKeywords = query.searchText.split(/\s+/).filter(Boolean);

      const brands = await this.brandModel.find({
        title: { $regex: searchKeywords[0], $options: 'i' },
      }, { _id: 1 }).lean();
      const brandsData = [];
      brands.map(item => {
        brandsData.push(item._id)
      })

      if (brandsData.length !== 0) {
        if (searchKeywords.length > 1) {
          const andConditions = [
            {
              $and: searchKeywords.splice(1).map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
            },
            { brands: brandsData }
          ];

          filter.$and = [...(filter.$and || []), ...andConditions];
        } else {
          filter.brands = { $in: brandsData }
        }
      } else {
        const andConditions = [
          {
            $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
          }
        ];

        filter.$and = [...(filter.$and || []), ...andConditions];
      }
    }

    const skip = (query.page * countPerPage) || 0

    const [result] = await this.productGroupModel
      .aggregate([
        {
          $match:
          {
            ...filter,
            variantCount: {
              $gt: 0,
            },
          }
        },
        {
          $lookup: {
            from: this.brandModel.collection.name,
            localField: 'brands',
            foreignField: '_id',
            as: 'brands'
          }
        },
        {
          $lookup: {
            from: this.advertModel.collection.name,
            localField: '_id',
            foreignField: 'productGroup',
            as: 'lowestAsk',
            pipeline: [
              {
                $match: {
                  status: 'PENDING',
                  vacationMode: false,
                  size: query?.size && Array.isArray(query.size)
                    ? { $in: query.size.map(s => new Types.ObjectId(s)) }
                    : { $exists: true },
                  price: {
                    $gte: parseInt(query?.min) || 0,
                    $lte: parseInt(query?.max) || Number.MAX_SAFE_INTEGER,
                  },
                }
              },
              {
                $sort: {
                  price: 1
                }
              },
              {
                $limit: 1,
              },
              {
                $project: {
                  price: 1,
                  size: 1
                }
              }
            ]
          }
        },
        {
          $match: {
            lowestAsk: { $exists: true, $not: { $size: 0 } }
          }
        },
        {
          $addFields: {
            lowestAsk: { $first: '$lowestAsk' }
          }
        },
        {
          $addFields: {
            lowestAsk: '$lowestAsk.price',
            size: '$lowestAsk.size'
          }
        },
        (query?.sortBy && query?.sortBy !== "null") ? {
          $sort: sort.price ? { lowestAsk: sort.price } : { createdAt: sort.date }
        } : { $sample: { size: 1000 } },
        { $limit: 200 },
        {
          $group: {
            _id: null,
            items: {
              $push: '$$ROOT'
            }
          }
        },
        {
          $addFields: {
            totalCount: { $size: '$items' },
            items: { $slice: ['$items', skip, countPerPage] }
          }
        }
      ])

    if (!result) {
      return {
        nextPageCursor: null,
        totalCount: 0,
        items: [],
      }
    }

    const totalPage = result.totalCount / countPerPage

    return {
      nextPageCursor: totalPage > +query.page + 1 ? +query.page + 1 : null,
      totalCount: result.totalCount,
      items: result.items,
    };
  }

  async getProductsForSearchBar(query) {
    const filter: any = {};

    const countPerPage = !Number.isNaN(+query.countPerPage)
      ? +query.countPerPage
      : 90;
    if (query.searchText !== 'undefined' && !!query.searchText && query.searchText !== "" && query.searchText) {
      const searchKeywords = query.searchText.split(/\s+/).filter(Boolean);

      const brands = await this.brandModel.find({
        title: { $regex: searchKeywords[0], $options: 'i' },
      }, { _id: 1 }).lean();
      const brandsData = [];
      brands.map(item => {
        brandsData.push(item._id)
      })

      if (brandsData.length !== 0) {
        if (searchKeywords.length > 1) {
          const andConditions = [
            {
              $and: searchKeywords.splice(1).map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
            },
            { brands: brandsData }
          ];

          filter.$and = [...(filter.$and || []), ...andConditions];
        } else {
          filter.brands = { $in: brandsData }
        }
      } else {
        const andConditions = [
          {
            $and: searchKeywords.map(keyword => ({ title: { $regex: keyword, $options: 'i' } })),
          }
        ];

        filter.$and = [...(filter.$and || []), ...andConditions];
      }
    }

    if (parseInt(query.limit)) {
      const skip = ((query.page - 1) * parseInt(query.limit))

      const result = await this.productGroupModel
        .find({
          ...filter,
        }).skip(skip).limit(parseInt(query.limit));


      if (!result) {
        return {
          nextPageCursor: null,
          totalCount: 0,
          items: [],
        }
      }

      const totalCount = await this.productGroupModel.count(filter)
      const totalPage = Math.ceil(totalCount / parseInt(query.limit))

      return {
        nextPageCursor: totalPage > +query.page + 1 ? +query.page + 1 : null,
        totalCount,
        totalPage,
        items: result,
      };
    } else {
      const skip = (query.page * countPerPage) || 0

      const result = await this.productGroupModel
        .find({
          ...filter,
        }).skip(skip).limit(countPerPage);

      if (!result) {
        return {
          nextPageCursor: null,
          totalCount: 0,
          items: [],
        }
      }

      const totalPage = result.length / countPerPage

      return {
        nextPageCursor: totalPage > +query.page + 1 ? +query.page + 1 : null,
        totalCount: result.length,
        items: result,
      };
    }
  }

  async getProductTitles(query) {
    const filter: any = {};

    if (query.brands?.length) {
      const brands = await this.brandModel
        .find(
          {
            slug: query.brands,
          },
          { _id: 1 },
        )
        .lean();

      filter.brands = {
        $in: brands.map((brand) => brand._id),
      };
    }

    if (query.searchText !== 'undefined' && !!query.searchText) {
      filter.$or = [
        ...(filter.$or || []),
        {
          title: { $regex: query.searchText, $options: 'i' },
        },
      ];
    }

    const items = await this.productGroupModel
      .find(
        {
          ...filter,
        },
        {
          title: 1,
          photos: 1
        },
      )
      .limit(200)
      .lean();

    return {
      items
    }
  }

  async getModelDetail(modelId: string) {
    const res = await this.productModelModel.findOne({ slug: modelId }).lean();

    return res;
  }

  getBrandDetail(brandId: string) {
    return this.brandModel.findOne({ slug: brandId }).lean();
  }

  getAttributes() {
    return this.productAttributeModel.find().lean();
  }

  getAttributeTerm(id: ObjectId) {
    return this.productAttributeTermModel
      .findById(id)
      .lean();
  }

  getAttributeTerms(attributeId: ObjectId) {
    return this.productAttributeTermModel
      .find({
        attribute: attributeId,
      })
      .lean();
  }

  async getProductIdBySlug(slug: string) {
    const { _id } = await this.productGroupModel
      .findOne({ slug }, { _id: 1 })
      .lean();

    return this.getProductWithAttributes(_id);
  }

  async getProductWithAttributes(groupId: ObjectId) {
    const group = await this.productGroupModel
      .findById(groupId)
      .populate([
        {
          path: 'brands',
          select: 'title',
        },
        {
          path: 'category',
          select: 'title',
        },
        {
          path: 'attributes',
          select: 'title view',
        },
        {
          path: 'comments',
          select: 'title review description',
          populate: {
            path: 'user',
            select: 'name surname email',
          },
        },
      ])
      .lean();

    const averageReview =
      group.comments?.reduce((acc, comment) => {
        return acc + comment.review;
      }, 0) / group.comments?.length;

    const sizeId = new Types.ObjectId('64e35922fa23d8b59c904203');
    const availableProducsOfGroup = await this.productModel
      .find(
        {
          group: groupId,
        },
        {
          terms: 1,
        },
      )
      .populate('terms');

    const sizes = availableProducsOfGroup.reduce((prev, cur) => {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      const sizeTerm = cur.terms.find((item) => sizeId.equals(item.attribute));

      if (!sizeTerm) return prev;

      return [...prev, sizeTerm];
    }, []);

    return {
      group,
      sizes,
      averageReview,
    };
  }

  getLowestPriceAdvert(groupId: ObjectId, q?) {
    return this.advertModel
      .findOne({
        productGroup: groupId,
        status: 'PENDING',
        vacationMode: false,
        size: q?.size ? q.size : { $exists: true },
      })
      .sort({
        price: 1,
      })
      .populate('productGroup size')
      .lean();
  }

  getBrandsAndProducts() {
    return this.brandModel.aggregate([
      {
        $sort: {
          soldCount: -1,
        },
      },
      {
        $lookup: {
          from: 'productgroups',
          let: { brandId: '$_id' },
          as: 'products',
          pipeline: [
            {
              $match: {
                $expr: { $eq: ['$brand', '$$brandId'] },
              },
            },
            {
              $limit: 15,
            },
          ],
        },
      },
    ]);
  }

  async getRelatedProducts() {
    const productGroups = await this.productGroupModel
      .find({
        variantCount: {
          $gt: 0,
        },
      })
      .sort({ price: -1 })
      .limit(10)
      .populate([
        {
          path: 'comments',
          select: 'title review description',
          populate: {
            path: 'user',
            select: 'name surname email',
          },
        },
        {
          path: 'brands',
          select: 'title logo',
        },
      ])
      .lean();

    const groupIds = productGroups.map((group) => group._id);

    const pendingAdverts = await Promise.all(
      groupIds.map((groupId) => {
        return this.advertModel
          .findOne(
            {
              productGroup: groupId,
              status: 'PENDING',
            },
            {
              price: 1,
            },
          )
          .sort({
            price: 1,
          })
          .lean();
      }),
    );

    const soldAdverts = await Promise.all(
      groupIds.map((groupId) => {
        return this.advertModel
          .findOne(
            {
              productGroup: groupId,
              status: {
                $ne: 'PENDING',
              },
            },
            {
              price: 1,
            },
          )
          .sort({
            _id: -1,
          })
          .lean();
      }),
    );

    const pendingAdvertsNormalized = pendingAdverts
      .filter((item) => !!item)
      .reduce((prev, cur) => {
        return {
          ...prev,
          [cur._id]: cur.price,
        };
      }, {});

    const soldAdvertsNormalized = soldAdverts
      .filter((item) => !!item)
      .reduce((prev, cur) => {
        return {
          ...prev,
          [cur._id]: cur.price,
        };
      }, {});

    return productGroups.map((group) => ({
      ...group,
      lowestAsk: pendingAdvertsNormalized[group._id.toString()],
      latestSale: soldAdvertsNormalized[group._id.toString()],
    }));
  }

  async getSimilaProductsByCategory(
    categoryId: ObjectId,
  ): Promise<ProductGroup[]> {
    const products = await this.productGroupModel
      .find({
        category: categoryId,
        variantCount: {
          $gt: 0,
        },
      })
      .limit(10);
    return products;
  }

  async getMostViewedProducts(currentPage = 0) {
    const filter = {
      variantCount: {
        $gt: 0,
      },
    };

    const countPerPage = 20;
    const totalCount = await this.productGroupModel.count(filter);
    const totalPage = Math.ceil(totalCount / countPerPage);

    const topTenProducts = await this.productGroupModel
      .find(filter)
      .populate({
        path: 'comments',
        select: 'review title description',
        populate: {
          path: 'user',
          select: 'name surname email',
        },
      })
      .skip(currentPage * countPerPage)
      .limit(countPerPage)
      .lean();

    return {
      nextPageCursor: totalPage > +currentPage + 1 ? +currentPage + 1 : null,
      totalCount,
      items: topTenProducts,
    };

    const groupIds = topTenProducts.map((group) => group._id);

    const pendingAdverts = await Promise.all(
      groupIds.map((groupId) => {
        return this.advertModel
          .findOne(
            {
              productGroup: groupId,
              status: 'PENDING',
            },
            {
              price: 1,
            },
          )
          .sort({
            _id: -1,
          })
          .lean();
      }),
    );

    const pendingAdvertsNormalized = pendingAdverts
      .filter((item) => !!item)
      .reduce((prev, cur) => {
        return {
          ...prev,
          [cur._id]: cur.price,
        };
      }, {});

    return topTenProducts.map((group) => ({
      ...group,
      lowestAsk: pendingAdvertsNormalized[group._id.toString()] || '-',
    }));
  }

  async getModelSizes(modelId) {
    if (!modelId || modelId === 'NONE') return await this.getAllSizes();

    const model = await this.productModelModel
      .findOne({ slug: modelId }, { _id: 1 })
      .lean();

    const group = await this.productGroupModel
      .findOne({ models: model._id }, { _id: 1 })
      .lean();

    if (!group) return []

    return await this.getProductSizes(group._id);
  }

  async getProductSizes(groupId: ObjectId) {
    const group = await this.productGroupModel
      .findById(groupId, { attributes: 1 })
      .lean();
    console.log("groupId", groupId)
    let sizeOptions = [];
    for (let i = 0; i < group?.attributes?.length; i++) {
      const options = await this.productAttributeTermModel
        .find({
          attribute: group?.attributes[i],
        })
        .lean();
      for (let j = 0; j < options.length; j++) {
        sizeOptions.push(options[j])
      }
    }

    const adverts = await this.advertModel
      .find(
        {
          productGroup: groupId,
          size: sizeOptions?.map((item) => item._id),
          status: "PENDING"
        },
        {
          price: 1,
          size: 1,
        },
      )
      .lean();

    const advertsNormalized = adverts.reduce(
      (prev, cur) => ({
        ...prev,
        [cur.size.toString()]: cur.price,
      }),
      {},
    );

    return sizeOptions.map((item) => ({
      ...item,
      price: advertsNormalized[item._id.toString()] || '-',
    }));
  }

  async getAllSizes() {
    const sizeId = new Types.ObjectId('64e35922fa23d8b59c904203');
    const sizeOptions = await this.getAttributeTerms(sizeId);

    return sizeOptions.sort((a, b) => {
      return a.value.localeCompare(b.value);
    });
  }

  async getSize(id: string) {
    const sizeId = new Types.ObjectId(id);
    const size = await this.productAttributeTermModel.findById(sizeId);
    return size;
  }

  getSliders() {
    return this.sliderModel.find().lean();
  }

  async getProductGroupById(id: ObjectId) {
    const productGroup = await this.productGroupModel.findById(id);
    return productGroup;
  }
}
