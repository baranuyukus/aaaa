import { Controller, Get, Param, Query } from '@nestjs/common';
import { ProductService } from './product.service';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';
import { QueryDto } from './dto/query.dto';
import { ProductGroup } from 'src/schemas/product/product-group.schema';

@Controller('product')
export class ProductController {
  constructor(private readonly productService: ProductService) { }

  @Get()
  getProducts(@Query() query: QueryDto) {
    return this.productService.getProducts(query);
  }

  @Get("getProductsForSearchBar")
  getProductsForSearchBar(@Query() query: QueryDto) {
    return this.productService.getProductsForSearchBar(query);
  }

  @Get('titles')
  getProductTitles(@Query() query) {
    return this.productService.getProductTitles(query);
  }

  @Get('/model-detail/:modelId')
  getModelDetail(@Param('modelId') modelId: string) {
    return this.productService.getModelDetail(modelId);
  }

  @Get('/brand-detail/:brandId')
  getBrandDetail(@Param('brandId') brandId: string) {
    return this.productService.getBrandDetail(brandId);
  }

  @Get('/attributes')
  getAttributes() {
    return this.productService.getAttributes();
  }

  @Get('/attribute-term/:id')
  getAttributeTerm(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ) {
    return this.productService.getAttributeTerm(id);
  }

  @Get('/attribute-terms/:attributeId')
  getAttributeTerms(
    @Param('attributeId', new ParseObjectIdPipe()) attributeId: ObjectId,
  ) {
    return this.productService.getAttributeTerms(attributeId);
  }

  @Get('/related-products')
  getRelatedProducts() {
    return this.productService.getRelatedProducts();
  }

  @Get('/brands-and-products')
  getBrandsAndProducts() {
    return this.productService.getBrandsAndProducts();
  }

  @Get('/similarproductsbycategory/:categoryId')
  getSimilaProductsByCategory(
    @Param('categoryId', new ParseObjectIdPipe()) categoryId: ObjectId,
  ): Promise<ProductGroup[]> {
    return this.productService.getSimilaProductsByCategory(categoryId);
  }

  @Get('/mostviewed')
  getMostViewedProducts() {
    return this.productService.getMostViewedProducts();
  }

  @Get('/sliders')
  getSliders() {
    return this.productService.getSliders();
  }

  @Get('/:slug/slug')
  getProductIdBySlug(
    @Param('slug') slug: string,
  ) {
    return this.productService.getProductIdBySlug(slug);
  }

  @Get('/:groupId')
  getProductWithAttributes(
    @Param('groupId', new ParseObjectIdPipe()) groupId: ObjectId,
  ) {
    return this.productService.getProductWithAttributes(groupId);
  }

  @Get('/:groupId/lowest-price-advert')
  getLowestPriceAdvert(
    @Param('groupId', new ParseObjectIdPipe()) groupId: ObjectId,
    @Query() q,
  ) {
    return this.productService.getLowestPriceAdvert(groupId, q);
  }

  @Get('/:modelId/model-sizes')
  getModelSizes(
    @Param('modelId') modelId,
  ) {
    return this.productService.getModelSizes(modelId);
  }

  @Get('/:groupId/sizes')
  getProductSizes(
    @Param('groupId', new ParseObjectIdPipe()) groupId: ObjectId,
  ) {
    return this.productService.getProductSizes(groupId);
  }

  @Get('/sizes/all')
  getAllSizes() {
    return this.productService.getAllSizes();
  }

  @Get(`/size/:sizeId`)
  getSize(@Param("sizeId") id: string) {
    return this.productService.getSize(id);
  }

  @Get(`/getProductGroupById/:id`)
  getProductGroupById(@Param("id", new ParseObjectIdPipe()) id: ObjectId) {
    return this.productService.getProductGroupById(id);
  }
}
