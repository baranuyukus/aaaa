import { Module } from '@nestjs/common';
import { ProductController } from './product.controller';
import { ProductService } from './product.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Product, ProductSchema } from '../../schemas/product/product.schema';
import {
  ProductAttributeTerm,
  ProductAttributeTermSchema,
} from 'src/schemas/product/product-attribute-term.schema';
import {
  ProductGroup,
  ProductGroupSchema,
} from 'src/schemas/product/product-group.schema';
import {
  ProductAttribute,
  ProductAttributeSchema,
} from 'src/schemas/product/product-attribute.schema';
import { Advert, AdvertSchema } from 'src/schemas/advert.schema';
import { User, UserSchema } from 'src/schemas/user.schema';
import { Order, OrderSchema } from 'src/schemas/order.schema';
import { Brand, BrandSchema } from 'src/schemas/brand.schema';
import { Slider, SliderSchema } from 'src/schemas/slider.schema';
import {
  ProductModel,
  ProductModelSchema,
} from 'src/schemas/product-model.schema';
import {
  HomeSection,
  HomeSectionSchema,
} from 'src/schemas/home-section.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: ProductGroup.name,
        schema: ProductGroupSchema,
      },
      {
        name: Product.name,
        schema: ProductSchema,
      },
      {
        name: ProductAttribute.name,
        schema: ProductAttributeSchema,
      },
      {
        name: ProductAttributeTerm.name,
        schema: ProductAttributeTermSchema,
      },
      { name: Advert.name, schema: AdvertSchema },
      {
        name: User.name,
        schema: UserSchema,
      },
      {
        name: Order.name,
        schema: OrderSchema,
      },
      {
        name: Brand.name,
        schema: BrandSchema,
      },
      {
        name: Slider.name,
        schema: SliderSchema,
      },
      {
        name: ProductModel.name,
        schema: ProductModelSchema,
      },
      {
        name: HomeSection.name,
        schema: HomeSectionSchema,
      },
    ]),
  ],
  controllers: [ProductController],
  providers: [ProductService],
  exports: [ProductService],
})
export class ProductModule {}
