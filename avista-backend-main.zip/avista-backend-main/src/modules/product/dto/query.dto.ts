import { Transform, Type } from 'class-transformer';
import { IsMongoId, IsNumber, IsOptional, IsString } from 'class-validator';
import { Types } from 'mongoose';

export class QueryDto {
  @Transform(({ value }) => +value, { toClassOnly: true })
  // @IsNumber()
  @IsOptional()
  page: number;

  @Transform(({ value }) => value.split(','), { toClassOnly: true })
  @IsString({ each: true })
  @IsOptional()
  brands: string[];

  @Transform(({ value }) => value.split(','), { toClassOnly: true })
  @IsString({ each: true })
  @IsOptional()
  models: string[];

  @Transform(({ value }) => value.split(','), { toClassOnly: true })
  @Type(() => Types.ObjectId)
  @IsMongoId({ each: true })
  @IsOptional()
  categories: string[];

  @IsString()
  @IsOptional()
  gender: string;

  @IsOptional()
  min: string;

  @IsOptional()
  max: string;

  @IsOptional()
  type: string;

  @IsOptional()
  sortBy: string;

  @IsOptional()
  limit: string;

  @IsOptional()
  searchText: string;

  @IsOptional()
  customFilter: string;

  @IsOptional()
  modelId: string;

  @Transform(({ value }) => value.split(','), { toClassOnly: true })
  @IsMongoId({ each: true })
  @IsOptional()
  size: string;

  @IsOptional()
  color: string;

  @IsOptional()
  sectionId: string;

  @IsOptional()
  countPerPage: number;
}
