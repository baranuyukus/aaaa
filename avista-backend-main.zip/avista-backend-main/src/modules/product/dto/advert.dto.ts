/* eslint-disable prettier/prettier */
import { IsMongoId, IsNotEmpty, IsString, IsOptional } from 'class-validator';
import { Types } from 'mongoose';

export class AdvertDto {
  @IsMongoId()
  @IsNotEmpty()
  productGroup: Types.ObjectId;

  @IsMongoId()
  @IsNotEmpty()
  size: Types.ObjectId;

  @IsNotEmpty()
  @IsString()
  usingStatus: string;

  @IsOptional()
  @IsString()
  authenticityCode: string;

  @IsNotEmpty()
  @IsString()
  price: string;

  @IsNotEmpty()
  @IsString()
  serviceFee: string;

  @IsNotEmpty()
  @IsString()
  commission: string;

  @IsNotEmpty()
  @IsString()
  finalAmount: string;

  @IsOptional()
  @IsString()
  sku: string;
}
