import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Comment, CommentDocument } from 'src/schemas/comment.schema';
import {
  ProductGroup,
  ProductGroupDocument,
} from 'src/schemas/product/product-group.schema';
import { User, UserDocument } from 'src/schemas/user.schema';
import { CreateCommentDto } from './dto/create-comment.dto';
import { UpdateCommentDto } from './dto/update-comment.dto';

@Injectable()
export class CommentService {
  constructor(
    @InjectModel(Comment.name)
    private readonly commentModel: Model<CommentDocument>,
    @InjectModel(User.name)
    private readonly userModel: Model<UserDocument>,
    @InjectModel(ProductGroup.name)
    private readonly productGroupModel: Model<ProductGroupDocument>,
  ) {}

  async createComment(
    userId: ObjectId,
    commentDto: CreateCommentDto,
  ) {
    const comment = await this.commentModel.create({
      user: userId,
      ...commentDto,
    });

    const group = await this.productGroupModel
      .findById(commentDto.productGroup)
      .populate({
        path: 'comments',
        select: 'review',
      });

    if (!group) {
      throw new Error('Ürün grubu bulunamadı.');
    }

    group.comments?.push(comment._id);

    const averageReview =
      group.comments?.reduce((acc, curr) => {
        return acc + curr.review;
      }, 0) / group.comments?.length;

    group.averageReview = Number(averageReview.toFixed(1));

    await group.save();

    return 'Yorumunuz için teşekkürler.';
  }

  // async updateComment(
  //   userId: ObjectId,
  //   commentDto: UpdateCommentDto,
  //   commentId: ObjectId,
  // ) {
  //   const comment = await this.commentModel.findById(commentId);

  //   if (!comment) {
  //     throw new Error('Yorum bulunamadı.');
  //   }

  //   if (comment.user.toString() !== userId.toString()) {
  //     throw new Error('Bu yorumu güncellemeye yetkiniz yok.');
  //   }

  //   await this.commentModel.findOneAndUpdate(
  //     {
  //       _id: commentId,
  //     },
  //     {
  //       $set: {
  //         ...commentDto,
  //       },
  //       averageReview: {
  //         $avg: '$comments.review',
  //       },
  //     },
  //     {
  //       new: true,
  //       runValidators: true,
  //     },
  //   );

  //   return 'Yorumunuz güncellendi.';
  // }

  async deleteComment(userId: ObjectId, commentId: ObjectId) {
    const comment = await this.commentModel.findById(commentId);

    if (!comment) {
      throw new Error('Yorum bulunamadı.');
    }

    if (comment.user.toString() !== userId.toString()) {
      throw new Error('Bu yorumu silmeye yetkiniz yok.');
    }

    const deleteComment = await this.commentModel.findByIdAndDelete(commentId);

    if (!deleteComment) {
      throw new Error('Yorum bulunamadı.');
    }

    const group = await this.productGroupModel
      .findById(deleteComment.productGroup)
      .populate({
        path: 'comments',
        select: 'review',
      });

    if (!group) {
      throw new Error('Ürün grubu bulunamadı.');
    }

    const updatedComments = group.comments?.filter((comment) => {
      return comment._id.toString() !== deleteComment._id.toString();
    });

    const averageReview =
      updatedComments?.reduce((acc, curr) => {
        return acc + curr.review;
      }, 0) / updatedComments?.length;

    group.averageReview = Number(averageReview.toFixed(1));

    group.comments = updatedComments;

    await group.save();

    // await this.productGroupModel.findByIdAndUpdate(
    //   deleteComment.productGroup,
    //   {
    //     $pull: {
    //       comments: deleteComment._id,
    //     },
    //     averageReview: {
    //       $avg: comment.review,
    //     },
    //   },
    //   {
    //     new: true,
    //   },
    // );

    return 'Yorumunuz silindi.';
  }
}
