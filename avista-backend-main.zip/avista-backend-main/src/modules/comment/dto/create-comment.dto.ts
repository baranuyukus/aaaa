import { IsMongoId, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { ObjectId, Types } from 'mongoose';

export class CreateCommentDto {
  @IsString()
  title: string;

  @IsNotEmpty()
  @IsString()
  description: string;

  @IsNotEmpty()
  @IsString()
  type: string;

  @IsNumber()
  review: number;

  productGroup: ObjectId;

  user: ObjectId;
  createdBy: ObjectId;
}
