import { Module } from '@nestjs/common';
import { CommentService } from './comment.service';
import { CommentController } from './comment.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Comment, CommentSchema } from 'src/schemas/comment.schema';
import { User, UserSchema } from 'src/schemas/user.schema';
import {
  ProductGroup,
  ProductGroupSchema,
} from 'src/schemas/product/product-group.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Comment.name, schema: CommentSchema },
      {
        name: User.name,
        schema: UserSchema,
      },
      {
        name: ProductGroup.name,
        schema: ProductGroupSchema,
      },
    ]),
  ],
  providers: [CommentService],
  controllers: [CommentController],
})
export class CommentModule {}
