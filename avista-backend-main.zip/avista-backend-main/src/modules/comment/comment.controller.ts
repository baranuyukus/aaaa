import {
  Controller,
  Post,
  Body,
  UseGuards,
  Param,
  Put,
  Delete,
} from '@nestjs/common';
import { CommentService } from './comment.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';
import { CreateCommentDto } from './dto/create-comment.dto';
import { UpdateCommentDto } from './dto/update-comment.dto';

@UseGuards(JwtAuthGuard)
@Controller('comment')
export class CommentController {
  constructor(private readonly commentService: CommentService) {}

  @Post()
  createComment(
    @CurrentUser() currentUser,
    @Body() commentDto: CreateCommentDto,
  ) {
    return this.commentService.createComment(
      currentUser._id,
      commentDto,
    );
  }

  // @Put('/:commentId')
  // updateComment(
  //   @CurrentUser() currentUser,
  //   @Body() commentDto: UpdateCommentDto,
  //   @Param('commentId', new ParseObjectIdPipe()) commentId: ObjectId,
  // ) {
  //   return this.commentService.updateComment(
  //     currentUser._id,
  //     commentDto,
  //     commentId,
  //   );
  // }

  @Delete('/:commentId')
  deleteComment(
    @CurrentUser() currentUser,
    @Param('commentId', new ParseObjectIdPipe()) commentId: ObjectId,
  ) {
    return this.commentService.deleteComment(currentUser._id, commentId);
  }
}
