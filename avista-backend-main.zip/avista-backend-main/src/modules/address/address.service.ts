import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Address, AddressDocument } from 'src/schemas/address.schema';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { User, UserDocument } from 'src/schemas/user.schema';
import { CreateAddressDto } from './dto/create-address.dto';

@Injectable()
export class AddressService {
  constructor(
    @InjectModel(Address.name)
    private readonly addressModel: Model<AddressDocument>,
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
  ) {}

  async createAddress(userId: ObjectId, createAddressDto: CreateAddressDto) {
    const user = await this.userModel.findById(userId);

    if (!user) {
      throw new NotFoundException(`User not found`);
    }

    const address = await this.addressModel.create({
      user: userId,
      ...createAddressDto,
    });

    return address;
  }

  async getMyAddresses(userId: ObjectId) {
    const user = await this.userModel.findById(userId);

    if (!user) {
      throw new NotFoundException(`User not found`);
    }

    const addresses = await this.addressModel.find({ user: userId });

    return addresses;
  }

  async deleteAddress(id: ObjectId) {
    const address = await this.addressModel.findByIdAndDelete(id);

    if (!address) {
      throw new NotFoundException(`Address not found`);
    }

    return address;
  }
}
