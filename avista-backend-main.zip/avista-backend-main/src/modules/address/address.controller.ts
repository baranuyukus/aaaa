import {
  Controller,
  Post,
  UseGuards,
  Body,
  Get,
  Delete,
  Param,
} from '@nestjs/common';
import { AddressService } from './address.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { CreateAddressDto } from './dto/create-address.dto';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';

@UseGuards(JwtAuthGuard)
@Controller('address')
export class AddressController {
  constructor(private addressService: AddressService) {}

  @Post()
  createAddress(
    @CurrentUser() currentUser,
    @Body() createAddressDto: CreateAddressDto,
  ) {
    return this.addressService.createAddress(currentUser._id, createAddressDto);
  }

  @Get()
  getMyAddresses(@CurrentUser() currentUser) {
    return this.addressService.getMyAddresses(currentUser._id);
  }

  @Delete('/:id')
  deleteAddress(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.addressService.deleteAddress(id);
  }
}
