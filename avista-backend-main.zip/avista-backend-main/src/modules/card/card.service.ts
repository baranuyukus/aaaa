import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { CreditCard, CreditCardDocument } from 'src/schemas/credit-card.schema';
import { User, UserDocument } from 'src/schemas/user.schema';

@Injectable()
export class CardService {
  constructor(
    @InjectModel(CreditCard.name)
    private readonly cardModel: Model<CreditCardDocument>,
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
  ) {}

  async createCard(userId: ObjectId, createCardDto: any) {
    const user = await this.userModel.findById(userId);

    if (!user) {
      throw new NotFoundException(`User not found`);
    }

    const card = await this.cardModel.create({
      user: userId,
      ...createCardDto,
    });

    return card;
  }

  async getMyCards(userId: ObjectId) {
    const dummyDataForCards = [
      {
        id: 1,
        number: '1234 2342 2342 1234',
        nameSurname: 'mehmet tas',
        date: '12/26',
        cvv: '456',
        bank: 'Ziraat Bankası',
      },
      {
        id: 2,
        number: '1234 4565 8755 1234',
        nameSurname: 'ali kalem',
        date: '12/24',
        cvv: '487',
        bank: 'Garanti Bankası',
      },
      {
        id: 3,
        number: '1234 4637 1234 0987',
        nameSurname: 'ramazan dursun',
        date: '09/24',
        cvv: '123',
        bank: 'İş Bankası',
      },
    ];

    return dummyDataForCards;
  }
}
