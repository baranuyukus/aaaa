import { Module } from '@nestjs/common';
import { CardService } from './card.service';
import { CardController } from './card.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { CreditCard, CreditCardSchema } from 'src/schemas/credit-card.schema';
import { User, UserSchema } from 'src/schemas/user.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: CreditCard.name, schema: CreditCardSchema },
      {
        name: User.name,
        schema: UserSchema,
      },
    ]),
  ],
  providers: [CardService],
  controllers: [CardController],
})
export class CardModule {}
