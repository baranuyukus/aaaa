import { Controller, Get, UseGuards, Post, Body } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CardService } from './card.service';
import { CurrentUser } from 'src/decorators/current-user';

@UseGuards(JwtAuthGuard)
@Controller('card')
export class CardController {
  constructor(private cardService: CardService) {}

  @Post()
  createCard(@CurrentUser() currentUser, @Body() createCardDto) {
    return this.cardService.createCard(currentUser._id, createCardDto);
  }

  @Get()
  getMyCards(@CurrentUser() currentUser) {
    return this.cardService.getMyCards(currentUser._id);
  }
}
