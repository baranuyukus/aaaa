import { Controller, Get, Param, Query } from '@nestjs/common';
import { CategoryService } from './category.service';
import { Category } from 'src/schemas/category.schema';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';

@Controller('category')
export class CategoryController {
  constructor(private categoryService: CategoryService) {}

  @Get('articles')
  listArticles() {
    return this.categoryService.listArticles();
  }

  @Get('articles/:id')
  getArticleById(@Param('id', new ParseObjectIdPipe()) id: ObjectId) {
    return this.categoryService.getArticleById(id);
  }

  @Get()
  findAllCategories(@Query() query) {
    return this.categoryService.findAllCategories(query);
  }

  @Get('brands-and-models')
  findAllBrandsAndModels() {
    return this.categoryService.findAllBrandsAndModels();
  }

  @Get('home-sections')
  findAllHomeSections() {
    return this.categoryService.findAllHomeSections();
  }

  @Get('/:id')
  findCategoryById(
    @Param('id', new ParseObjectIdPipe()) id: ObjectId,
  ): Promise<Category> {
    return this.categoryService.findCategoryById(id);
  }
}
