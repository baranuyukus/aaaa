import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Category, CategoryDocument } from 'src/schemas/category.schema';
import {
  HomeSection,
  HomeSectionDocument,
} from 'src/schemas/home-section.schema';
import { ProductService } from '../product/product.service';
import { Article, ArticleDocument } from 'src/schemas/article.schema';

@Injectable()
export class CategoryService {
  constructor(
    @InjectModel(Category.name)
    private readonly categoryModel: Model<CategoryDocument>,
    @InjectModel(HomeSection.name)
    private readonly homeSectionModel: Model<HomeSectionDocument>,
    @InjectModel(Article.name)
    private readonly articleModel: Model<ArticleDocument>,
    private readonly productService: ProductService,
  ) { }

  listArticles() {
    return this.articleModel.find().sort({ _id: -1 }).limit(3).lean();
  }

  getArticleById(id: ObjectId) {
    return this.articleModel.findById(id).lean();
  }

  async findAllHomeSections() {
    const sections = await this.homeSectionModel
      .find()
      .populate({
        path: 'products',
        populate: {
          path: 'brands',
        },
      })
      .sort({
        order: 1,
      })
      .lean();

    const listOfPromises = sections.map(async (section) => {
      const products = await Promise.all(
        section.products.map(async (item) => {
          const lowestAdvert = await this.productService.getLowestPriceAdvert(
            // @ts-ignore
            item._id,
          );

          return {
            ...item,
            lowestAsk: lowestAdvert?.price,
            size: lowestAdvert?.size,
          };
        }),
      );

      return {
        ...section,
        products: products.filter((item: any) => {
          if (!item.lowestAsk) return false;

          return true;
        }),
      };
    });

    return await Promise.all(listOfPromises);
  }

  findAllCategories(query) {
    const filter: any = {};

    if (query.category) filter.category = query.category;

    return this.categoryModel
      .find(filter)
      .sort({
        order: 1,
      })
      .lean();
  }

  async findCategoryById(id: ObjectId): Promise<Category> {
    const category = await this.categoryModel.findById(id);

    if (!category) {
      throw new NotFoundException(`Category not found`);
    }

    return category;
  }

  async findAllBrandsAndModels() {
    return this.categoryModel.aggregate([
      {
        $lookup: {
          from: 'brands',
          as: 'brands',
          let: { categoryId: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ['$category', '$$categoryId'] },
              },
            },
            {
              $lookup: {
                from: 'productmodels',
                localField: '_id',
                foreignField: 'brand',
                as: 'models',
              },
            },
          ],
        },
      },
    ]);
  }
}
