import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  UseGuards,
} from '@nestjs/common';
import { OfferService } from './offer.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from 'src/decorators/current-user';
import { ObjectId, ParseObjectIdPipe } from 'src/pipes/parse-object-id.pipe';

@UseGuards(JwtAuthGuard)
@Controller('offer')
export class OfferController {
  constructor(private readonly offerService: OfferService) { }

  @Get('/:offerId/detail')
  getOfferById(@Param('offerId', new ParseObjectIdPipe()) offerId: ObjectId) {
    return this.offerService.getOfferById(offerId);
  }

  @Get('/:advertId/price-range')
  getAdvertPriceRange(
    @Param('advertId', new ParseObjectIdPipe()) advertId: ObjectId,
  ) {
    return this.offerService.getAdvertPriceRange(advertId);
  }

  @Post()
  makeOffer(@CurrentUser() currentUser, @Body() dto) {
    return this.offerService.makeOffer(currentUser._id, dto);
  }

  @Put('/:offerId/approve')
  approveOffer(
    @CurrentUser() currentUser,
    @Param('offerId', new ParseObjectIdPipe()) offerId: ObjectId,
  ) {
    return this.offerService.approveOffer(currentUser._id, offerId);
  }

  @Put('/:offerId/decline')
  declineOffer(
    @CurrentUser() currentUser,
    @Param('offerId', new ParseObjectIdPipe()) offerId: ObjectId,
  ) {
    return this.offerService.declineOffer(currentUser._id, offerId);
  }

  @Post('/:offerId/counter')
  makeCounterOffer(
    @CurrentUser() currentUser,
    @Param('offerId', new ParseObjectIdPipe()) offerId: ObjectId,
    @Body() dto,
  ) {
    return this.offerService.makeCounterOffer(currentUser._id, offerId, dto);
  }

  @Get('outgoing')
  listOutgoingOffers(@CurrentUser() currentUser) {
    return this.offerService.listOutgoingOffers(currentUser._id);
  }

  @Get('incoming')
  listIncomingOffers(@CurrentUser() currentUser) {
    return this.offerService.listIncomingOffers(currentUser._id);
  }

  @Delete(':id')
  deleteOffer(@Param("id") id: string) {
    return this.offerService.deleteOffer(id);
  }
}
