import { Module } from '@nestjs/common';
import { OfferController } from './offer.controller';
import { OfferService } from './offer.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Offer, OfferSchema } from 'src/schemas/offer.schema';
import { Advert, AdvertSchema } from 'src/schemas/advert.schema';
import { NotificationModule } from '../notification/notification.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: Advert.name,
        schema: AdvertSchema,
      },
      {
        name: Offer.name,
        schema: OfferSchema,
      },
    ]),
    NotificationModule,
  ],
  controllers: [OfferController],
  providers: [OfferService],
})
export class OfferModule {}
