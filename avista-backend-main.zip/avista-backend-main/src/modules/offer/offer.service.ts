import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ObjectId } from 'src/pipes/parse-object-id.pipe';
import { Advert, AdvertDocument } from 'src/schemas/advert.schema';
import { Offer, OfferDocument } from 'src/schemas/offer.schema';
import { NotificationService } from '../notification/notification.service';

@Injectable()
export class OfferService {
  constructor(
    private readonly notificationService: NotificationService,
    @InjectModel(Offer.name) private readonly offerModel: Model<OfferDocument>,
    @InjectModel(Advert.name)
    private readonly advertModel: Model<AdvertDocument>,
  ) { }

  getOfferById(offerId: ObjectId) {
    return this.offerModel
      .findById(offerId)
      .populate({
        path: 'advert',
        populate: {
          path: 'productGroup',
          select: 'photos title',
        },
      })
      .lean();
  }

  async getAdvertPriceRange(advertId: ObjectId) {
    const lowestOffer = await this.offerModel
      .findOne({
        advert: advertId,
      })
      .sort({
        price: 1,
      })
      .lean();

    const highestOffer = await this.offerModel
      .findOne({
        advert: advertId,
      })
      .sort({
        price: -1,
      })
      .lean();

    return {
      lowestOffer: lowestOffer?.price || 0,
      highestOffer: highestOffer?.price || 0,
    };
  }

  async makeOffer(currentUserId: ObjectId, dto) {
    const advert = await this.advertModel
      .findById({ _id: dto.advert }, { user: 1 })
      .lean();

    const offer = await this.offerModel.create({
      ...dto,
      sender: currentUserId,
      receiver: advert.user,
    });

    await this.notificationService.sendNotification({
      title: 'Ürününüze teklif geldi.',
      body: `Teklif: ${offer.price}`,
      userId: advert.user,
      advert: dto.advert,
    });

    return offer;
  }

  approveOffer(currentUserId: ObjectId, offerId: ObjectId) {
    return this.offerModel
      .findOneAndUpdate(
        {
          _id: offerId,
          receiver: currentUserId,
          status: 'PENDING',
        },
        {
          status: 'APPROVED',
        },
        {
          projection: {
            _id: 1,
          },
        },
      )
      .lean();
  }

  declineOffer(currentUserId: ObjectId, offerId: ObjectId) {
    return this.offerModel
      .findOneAndUpdate(
        {
          _id: offerId,
          receiver: currentUserId,
          status: 'PENDING',
        },
        {
          status: 'DECLINED',
        },
        {
          projection: {
            _id: 1,
          },
        },
      )
      .lean();
  }

  async makeCounterOffer(currentUserId: ObjectId, offerId: ObjectId, dto) {
    const targetOffer = await this.offerModel.findById(offerId).lean();

    const counterOffer = await this.offerModel.create({
      advert: targetOffer.advert,
      price: dto.price,
      sender: currentUserId,
      receiver: targetOffer.sender,
    });

    await this.notificationService.sendNotification({
      title: 'Teklifinize karşı teklif geldi.',
      body: `Teklif: ${counterOffer.price}`,
      userId: targetOffer.sender,
      advert: targetOffer.advert,
    });

    return counterOffer;
  }

  listOutgoingOffers(currentUserId: ObjectId) {
    return this.offerModel
      .find({
        sender: currentUserId,
      })
      .populate({
        path: 'advert',
        populate: [
          {
            path: 'productGroup',
            select: 'photos title',
          },
          {
            path: 'size',
          },
        ],
      })
      .lean();
  }

  listIncomingOffers(currentUserId: ObjectId) {
    return this.offerModel
      .find({
        receiver: currentUserId,
      })
      .populate({
        path: 'advert',
        populate: {
          path: 'productGroup',
          select: 'photos title',
        },
      })
      .lean();
  }

  async deleteOffer(id: string) {
    const offer = await this.offerModel.findById(id).lean();

    await this.notificationService.sendNotification({
      title: 'Teklifinize Rededildi',
      body: 'Hangi Teklifinin Reddedildiğini Öğrenmek İçin Tıkla',
      userId: offer.sender,
      advert: offer.advert,
    });

    return await this.offerModel.findByIdAndDelete(offer._id);
  }
}
