import { Schema, Connection, Model } from 'mongoose';

export const AutoIncrementFactory = (connection: Connection) => {
  let counterModel: Model<any>;

  // eslint-disable-next-line func-names
  const createCounterModel = function () {
    const CounterSchema = new Schema(
      {
        id: { type: String, required: true },
        seq: { type: Number, default: 1, required: true },
      },
      {
        validateBeforeSave: false,
      },
    );

    if (connection.modelNames().indexOf('counters') >= 0) {
      return connection.model('counters');
    }

    return connection.model('counters', CounterSchema);
  };

  const plugin = (schema: Schema, options) => {
    counterModel = createCounterModel();

    // eslint-disable-next-line func-names
    schema.pre('validate', async function (next) {
      const doc = this as any;

      if (!doc.identifier) {
        const { seq } = await counterModel.findOneAndUpdate(
          {
            id: options.id,
          },
          {
            $inc: {
              seq: 1,
            },
          },
          {
            new: true,
            upsert: true,
          },
        );

        doc.identifier = seq;
      }

      next();
    });
  };

  return plugin;
};
