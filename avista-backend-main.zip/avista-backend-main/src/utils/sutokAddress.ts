const sutokAddress = {
    name: `Ramazan Dursun`,
    email: "ramazan@sutok.com",
    phone: "+905303080943",
    address1: "Bomonti the house residence 807",
    countryCode: 'TR',
    cityName: "İstanbul",
    districtName: "Şişli",
};

export default sutokAddress;