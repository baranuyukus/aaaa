const getEmailTemplate = (style: any, body) => {
  return `
    <!DOCTYPE html>
    <html>
        <head>
            ${style ? style : `<style>
            .maindiv {
              background-color: #efefef;
              width: 100%;
              padding: 30px 0px;
              color: black;
              font-family: Helvetica, Arial, sans-serif;
              font-size: 15px;
            }
            .mainFooter {
              width: 100%;
              text-align: center;
              color: #636363;
              margin-top: 10px;
              font-size: 15px;
            }
            .container {
              background-color: white;
              width: 80%;
              margin: auto;
              padding: 20px;
              color: black;
            }
            h4 {
              color: #6b6b6b;
              padding-left: 8px;
            }
            h3 {
              color: black;
              padding-left: 8px;
            }
            h2 {
              color: black;
              padding-left: 8px;
            }
            .code-button {
              background-color: #a41d23;
              color: white;
              padding: 10px 20px;
              border: none;
              cursor: pointer;
              text-decoration: none;
              font-weight: bold;
              font-size: 18px;
              margin-left: 8px;
            }
            .customRed {
              color: #a41d23 !important;
            }
            .footer {
              margin-top: 20px;
              color: #6b6b6b;
            }
            .txtBlack {
              color: black;
            }
            .txt6b{
              color: #6b6b6b;
            }
            .logo {
              width:100px;
              height:50px;
              object:cover;
            }
            .socialMediaImage{
              width:20px;
              height:20px;
            }
            p {
              padding-left: 8px;
            }
            .pl8 {
              padding-left: 8px;
            }
          </style>`}
        </head>
        <body>
          <div class="maindiv">
            ${body}
            ${/* 
          <div class="mainFooter">
              <a href="https://instagram.com/sutokcom">
                <img class="socialMediaImage" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png" alt="instagram"/>
              <a/>
            </div>
            <div class="mainFooter">
              <span>SUTOK</span>
            </div>
          */""}
          </div>
        </body>
    </html>
    `;
}

export default getEmailTemplate;