import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { Brand } from './brand.schema';
import slugify from 'slugify';
import { nanoid } from 'nanoid';

@Schema({
  timestamps: true,
})
export class ProductModel {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: 'Brand',
    required: true,
  })
  brand: Brand;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: 'ProductModel',
    required: false,
  })
  parentModel: ProductModel;

  @Prop({
    type: String,
    required: true,
  })
  cover: string;

  @Prop({
    type: String,
    required: true,
  })
  title: string;

  @Prop({
    type: String,
    required: true,
  })
  description: string;

  @Prop({
    type: String,
    required: true,
    default: function () {
      return (
        slugify(this.title, {
          strict: true,
        }) +
        '-' +
        nanoid(5)
      );
    },
  })
  slug: String;

  @Prop({
    type: String,
    required: false,
  })
  pageTitle: string;

  @Prop({
    type: String,
    required: false,
  })
  pageDescription: string;
}

export type ProductModelDocument = ProductModel & Document;

export const ProductModelSchema = SchemaFactory.createForClass(ProductModel);
