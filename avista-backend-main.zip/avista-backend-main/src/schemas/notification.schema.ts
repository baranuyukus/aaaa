import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ObjectId } from '../pipes/parse-object-id.pipe';
import { User, UserDocument } from './user.schema';
import { Advert, AdvertDocument } from './advert.schema';

@Schema({
  timestamps: true,
})
export class Notification {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  user: UserDocument | ObjectId;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Advert.name,
    required: true,
  })
  advert: AdvertDocument | ObjectId;

  @Prop({
    type: String,
    required: true,
  })
  title: string;

  @Prop({
    type: String,
    required: true,
  })
  body: string;

  @Prop({
    type: Boolean,
    required: true,
    default: false,
  })
  seen: boolean;
}

export type NotificationDocument = Notification & Document;

export const NotificationSchema = SchemaFactory.createForClass(Notification);
