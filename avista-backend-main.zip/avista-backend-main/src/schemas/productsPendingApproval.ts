import { Prop, Schema, SchemaFactory, } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { User } from './user.schema';

export type ProductsPendingApprovalDocument = ProductsPendingApproval & Document;

@Schema()
export class ProductsPendingApproval {
  @Prop({ type: Object })
  advert: object;

  @Prop({ type: Object })
  productGroup: object;

  @Prop({ type: Number })
  stock: number;

  @Prop({ type: Number })
  price: number;

  @Prop({ type: String })
  type: string;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name })
  createdBy: User;
}

export const ProductsPendingApprovalSchema = SchemaFactory.createForClass(ProductsPendingApproval);
