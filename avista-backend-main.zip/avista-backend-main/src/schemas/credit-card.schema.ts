import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type CreditCardDocument = CreditCard & Document;

@Schema()
export class CreditCard {
  @Prop({ type: String })
  number: string;

  @Prop({ type: String })
  nameSurname: string;

  @Prop({ type: String })
  date: string;

  @Prop({ type: String })
  cvc: string;

  @Prop({ type: String })
  bank: string;

  @Prop({ type: Number })
  id: number;
}

export const CreditCardSchema = SchemaFactory.createForClass(CreditCard);
