import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({
  timestamps: true,
})
export class Slider {
  @Prop({
    type: String,
    required: true,
  })
  url: string;
}

export type SliderDocument = Slider & Document;

export const SliderSchema = SchemaFactory.createForClass(Slider);
