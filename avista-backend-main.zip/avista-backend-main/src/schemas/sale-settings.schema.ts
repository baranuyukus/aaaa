import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({
  timestamps: true,
})
export class SaleSettings {
  @Prop({
    type: Number,
    required: true,
  })
  serviceFee: number;

  @Prop({
    type: Number,
    required: true,
  })
  commissionRate: number;

  @Prop({
    type: Number,
    required: true,
  })
  sellerServiceFee: number;

  @Prop({
    type: Number,
    required: true,
  })
  sellerCommissionRate: number;
}

export type SaleSettingsDocument = SaleSettings & Document;

export const SaleSettingsSchema = SchemaFactory.createForClass(SaleSettings);
