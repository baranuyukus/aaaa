import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { Advert } from './advert.schema';

export type BasketItemDocument = BasketItem & Document;

@Schema()
export class BasketItem {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Advert.name,
    required: true,
  })
  advert: Advert;

  @Prop({ type: Number, required: true, min: 1 })
  quantity: number;

  @Prop({ type: Number, required: true })
  price: number;
}

export const BasketItemSchema = SchemaFactory.createForClass(BasketItem);
