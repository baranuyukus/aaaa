import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ProductGroupDocument } from './product/product-group.schema';
import { ObjectId } from '../pipes/parse-object-id.pipe';
import * as bcrypt from 'bcrypt';
import { ProductModel } from './product-model.schema';

const sellerValidation = function () {
  return this.role === 'SELLER';
};

@Schema({
  timestamps: true,
})
export class User {
  @Prop({
    type: String,
    enum: ['NONE', 'SELLER', 'ADMIN'],
    required: true,
    default: 'NONE',
  })
  role: string;

  @Prop({
    type: String,
  })
  authId: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: true,
  })
  surname: string;

  @Prop({
    type: String,
    required: true,
    enum: ['EMAIL', 'GOOGLE', 'APPLE', 'FACEBOOK'],
  })
  authType: string;

  @Prop({
    type: String,
    index: true,
    trim: true,
    unique: true,
    sparse: true,
  })
  email: string;

  @Prop({
    type: String,
  })
  password: string;

  @Prop({
    type: String,
    required: true,
  })
  phoneNumber: string;

  @Prop({
    type: String,
    required: false,
  })
  notificationToken: string;

  @Prop({
    type: Date,
    required: true,
    default: new Date(),
  })
  lastSession: Date;

  @Prop({
    type: Date,
  })
  birthDate: Date;

  @Prop({
    type: String,
    enum: ['MALE', 'FEMALE'],
  })
  gender: string;

  @Prop({
    type: [{ _id: MongooseSchema.Types.ObjectId, size: MongooseSchema.Types.ObjectId }],
    ref: 'ProductGroup',
    required: true,
  })
  group: Array<{ _id: ObjectId, size: ObjectId }>;

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: 'ProductGroup',
    required: true,
  })
  mostViewed: Array<ProductGroupDocument | ObjectId>;

  @Prop({
    type: Number,
    required: true,
    default: 0,
  })
  advertCount: number;

  @Prop({
    type: Boolean,
    required: true,
    default: false,
  })
  vacationMode: boolean;

  @Prop({
    type: String,
    enum: ['PENDING', 'VERIFIED', 'NOT_VERIFIED'],
    required: true,
    default: 'PENDING',
  })
  status: string;

  @Prop({
    type: String,
    required: false,
  })
  companyName: string;

  @Prop({
    type: String,
    required: false,
  })
  vkn: string;

  @Prop({
    type: String,
    required: false,
  })
  vd: string;

  @Prop({
    type: String,
    required: true,
  })
  identityNumber: string;

  @Prop({
    type: String,
    required: true,
  })
  city: string;

  @Prop({
    type: String,
    required: true,
  })
  district: string;

  @Prop({
    type: String,
    required: true,
  })
  postcode: string;

  @Prop({
    type: String,
    required: true,
  })
  openAddress: string;

  @Prop({
    type: String,
  })
  resetPasswordToken: string;

  @Prop({
    type: Date,
  })
  resetPasswordExpires: Date;

  @Prop({
    type: Number,
    required: false,
  })
  commissionRate: number

  @Prop({
    type: Number,
    required: false,
  })
  serviceFee: number

  @Prop({
    type: String,
    required: false,
  })
  ibanBankName: string

  @Prop({
    type: String,
    required: false,
  })
  ibanAccountName: string

  @Prop({
    type: String,
    required: false,
  })
  ibanNumber: string

  @Prop({
    type: Number,
    required: false,
    default: 0
  })
  pendingPayment: number;

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    required: false,
    default: null,
    ref: ProductModel.name
  })
  models: ProductModel[];
}

export type UserDocument = User &
  Document & { getResetPasswordTokenFromUser: any };

const UserSchema = SchemaFactory.createForClass(User);

UserSchema.pre('save', function (next) {
  // eslint-disable-next-line @typescript-eslint/no-this-alias
  const user = this;
  if (!user.isModified('password') || !user.password) return next();

  bcrypt.hash(user.password, 10, function (err, hash) {
    if (err) return next(err);
    // override the cleartext password with the hashed one
    user.password = hash;
    next();
  });
});

UserSchema.methods.getResetPasswordTokenFromUser = function () {
  const resetPasswordToken = Math.floor(1000 + Math.random() * 9000);

  const resetPasswordExpires = Date.now() + 3600000;

  this.resetPasswordToken = resetPasswordToken;
  this.resetPasswordExpires = resetPasswordExpires;

  return {
    resetPasswordToken,
  };
};

export { UserSchema };
