import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ProductGroup } from './product/product-group.schema';
import slugify from 'slugify';
import { nanoid } from 'nanoid';

export type HomeSectionDocument = HomeSection & Document;

@Schema()
export class HomeSection {
  @Prop({ type: String, required: true })
  title: string;

  @Prop({
    type: String,
    required: true,
    default: function () {
      return (
        slugify(this.title, {
          strict: true,
        }) +
        '-' +
        nanoid(5)
      );
    },
  })
  slug: String;

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: ProductGroup.name,
    required: true,
    default: [],
  })
  products: ProductGroup[];

  @Prop({
    type: Number,
    required: true,
    min: 0,
    unique: true,
  })
  order: number;
}

export const HomeSectionSchema = SchemaFactory.createForClass(HomeSection);
