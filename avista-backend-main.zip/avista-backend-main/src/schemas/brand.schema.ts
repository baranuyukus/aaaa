import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { Category } from './category.schema';
import slugify from 'slugify';
import { nanoid } from 'nanoid';

@Schema({
  timestamps: true,
})
export class Brand {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Category.name,
    required: true,
  })
  category: Category;

  @Prop({
    type: String,
    required: true,
  })
  title: string;

  @Prop({
    type: String,
    required: true,
  })
  description: string;

  @Prop({
    type: Boolean,
    required: true,
    default: false
  })
  popularityStatus: boolean;

  @Prop({
    type: String,
    required: true,
  })
  logo: string;

  @Prop({
    type: String,
    required: true,
  })
  background: string;

  @Prop({
    type: String,
    required: true,
  })
  cover: string;

  @Prop({
    type: Number,
    required: true,
    default: 0,
    min: 0,
  })
  soldCount: number;

  @Prop({
    type: String,
    required: true,
    default: function () {
      return (
        slugify(this.title, {
          strict: true,
        }) +
        '-' +
        nanoid(5)
      );
    },
  })
  slug: String;

  @Prop({
    type: String,
    required: false,
  })
  pageTitle: string;

  @Prop({
    type: String,
    required: false,
  })
  pageDescription: string;
}

export type BrandDocument = Brand & Document;

export const BrandSchema = SchemaFactory.createForClass(Brand);
