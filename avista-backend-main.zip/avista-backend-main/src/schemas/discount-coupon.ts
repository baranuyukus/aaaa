import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { User } from './user.schema';

@Schema({
    timestamps: true,
})
export class DiscountCoupon {
    @Prop({
        type: String,
        required: true,
    })
    couponCode: string;

    @Prop({
        type: Number,
        required: true,
    })
    discountRate: number;

    @Prop({ type: Array<MongooseSchema.Types.ObjectId>, required: true })
    thoseWhoUse: User[];
}

export type DiscountCouponDocument = DiscountCoupon & Document;

export const DiscountCouponSchema = SchemaFactory.createForClass(DiscountCoupon);
