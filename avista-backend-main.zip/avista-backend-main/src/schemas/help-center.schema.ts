import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { User } from './user.schema';

export type HelpCenterDocument = HelpCenter & Document;

@Schema({
  timestamps: true,
})
export class HelpCenter {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  user: User;

  @Prop({ required: true })
  email: string;

  @Prop({ required: true })
  subject: string;
}

export const HelpCenterSchema = SchemaFactory.createForClass(HelpCenter);
