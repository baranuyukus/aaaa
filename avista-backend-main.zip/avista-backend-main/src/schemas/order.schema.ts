import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { User } from './user.schema';
import { BasketItem, BasketItemSchema } from './basket-item.schema';
import { Payment } from './payment.schema';
import { DiscountCoupon } from './discount-coupon';

export type OrderDocument = Order & Document;

@Schema({
  timestamps: true,
})
export class Order {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Payment.name,
    required: true,
  })
  paymentId: Payment;

  @Prop({ required: true, type: Number })
  identifier: number;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  user: User;

  @Prop({ type: Array<MongooseSchema.Types.ObjectId>, required: true })
  sellers: User[];

  @Prop([{ type: BasketItemSchema, required: true }])
  basket: BasketItem[];

  @Prop({ required: true })
  totalAmount: number;

  @Prop({ required: true })
  cargoPrice: number;

  @Prop({ required: true })
  serviceFee: number;

  @Prop({ required: true })
  kdv: number;

  @Prop({
    type: String,
    enum: ['PENDING', 'DECLINED', 'SHIPPED', 'DELIVERED'],
    default: 'PENDING',
  })
  status: string;

  @Prop({
    type: Object,
    required: true,
  })
  shippingAddress: any;

  @Prop({
    type: Object,
    required: true,
  })
  billingAddress: any;

  @Prop({ type: Object, required: true })
  creditCard: any;

  @Prop({ required: false })
  apiTrackingUrl: string;

  @Prop({ required: false })
  trackingUrl: string;

  @Prop({ required: false })
  shipmentId: string;

  @Prop({ required: false })
  barcode: string;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: DiscountCoupon.name,
    required: false,
  })
  discountCoupon: DiscountCoupon;

  @Prop({ required: false })
  timelines: object[];
}

export const OrderSchema = SchemaFactory.createForClass(Order);
