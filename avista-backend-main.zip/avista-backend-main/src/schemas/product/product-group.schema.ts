import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types, Schema as MongooseSchema } from 'mongoose';
import { Brand } from '../brand.schema';
import { ProductAttributeDocument } from './product-attribute.schema';
import { Category } from '../category.schema';
import { CommentDocument } from '../comment.schema';
import { ProductModel } from '../product-model.schema';
import { User } from '../user.schema';
import slugify from 'slugify';
import { nanoid } from 'nanoid';
import { ProductAttributeTermDocument } from './product-attribute-term.schema';

@Schema({
  timestamps: true,
})
export class ProductGroup {
  @Prop({
    type: String,
    required: true,
  })
  title: string;

  @Prop({
    type: String,
    required: false,
  })
  subtitle: string;

  @Prop({
    type: Number,
  })
  price: number;

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: ProductModel.name,
    required: true,
  })
  models: Types.ObjectId[] | Brand[];

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: Brand.name,
    required: true,
  })
  brands: Types.ObjectId[] | Brand[];

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Category.name,
    required: true,
  })
  category: Types.ObjectId | Category;

  @Prop({
    type: String,
    required: false,
  })
  sku: string;

  @Prop({
    type: String,
  })
  cargo: string;

  @Prop({
    type: String,
    required: true,
  })
  description: string;

  @Prop({
    type: String,
    required: true,
  })
  season: string;

  @Prop({
    type: String,
    enum: ['UNISEX', 'MALE', 'FEMALE'],
    default: 'UNISEX',
  })
  gender: string;

  @Prop({
    type: [String],
    required: true,
  })
  photos: string[];

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: 'ProductAttribute',
    required: true,
  })
  attributes: Array<ProductAttributeDocument>;

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: 'Comment',
  })
  comments: Array<CommentDocument>;

  @Prop({
    type: Number,
  })
  averageReview: number;

  @Prop({
    type: Number,
    required: true,
    default: 0,
    min: 0,
  })
  variantCount: number;

  @Prop({
    type: Number,
    required: false,
    default: 0,
  })
  soldCount: number;

  @Prop({
    type: Boolean,
    required: false,
    default: false,
  })
  stockState: boolean;

  @Prop({
    type: MongooseSchema.Types.Mixed,
  })
  metaTags: any;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name })
  createdBy: User;

  @Prop({
    type: String,
    required: false,
    default: function () {
      return (
        slugify(this.title, {
          strict: true,
        }) +
        '-' +
        nanoid(5)
      );
    },
  })
  slug: String;

  @Prop({
    type: String,
    required: false,
  })
  pageTitle: string;

  @Prop({
    type: String,
    required: false,
  })
  pageDescription: string;

  @Prop({
    type: [Object],
    ref: 'ProductAttribute',
    required: false,
  })
  productattributeterms: Array<Object>;
}

export type ProductGroupDocument = ProductGroup & Document;

export const ProductGroupSchema = SchemaFactory.createForClass(ProductGroup);
