import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ProductAttributeTerm } from './product-attribute-term.schema';
import { ProductGroup } from './product-group.schema';

@Schema()
export class Product {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: 'ProductGroup',
    required: true,
  })
  group: ProductGroup;

  @Prop({
    type: [MongooseSchema.Types.ObjectId],
    ref: 'ProductAttributeTerm',
    required: true,
  })
  terms: ProductAttributeTerm[];

  @Prop({
    type: String,
    required: false,
  })
  sku: string;

  @Prop({
    type: Date,
    required: false,
  })
  releaseDate: Date;

  @Prop({
    type: String,
    required: false,
  })
  colorway: string;

  @Prop({
    type: String,
    required: false,
  })
  style: string;

  @Prop({
    type: String,
    required: false,
  })
  stock: string;

  @Prop({
    type: String,
    required: false,
  })
  price: string;

  @Prop({
    type: Array,
    required: false,
  })
  Images: string[];

  @Prop({
    type: Number,
    required: false,
  })
  kg: number;

  @Prop({
    type: Number,
    required: false,
  })
  cmU: number;

  @Prop({
    type: Number,
    required: false,
  })
  cmG: number;

  @Prop({
    type: Number,
    required: false,
  })
  cmY: number;
}

export type ProductDocument = Product & Document;
export const ProductSchema = SchemaFactory.createForClass(Product);
