import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ProductAttribute } from './product-attribute.schema';

@Schema()
export class ProductAttributeTerm {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: 'ProductAttribute',
    required: true,
  })
  attribute: ProductAttribute;

  @Prop({
    type: String,
    required: true,
  })
  value: string;

  @Prop({
    type: String,
    required: false,
  })
  colorCode: string;
}

export type ProductAttributeTermDocument = ProductAttributeTerm & Document;
export const ProductAttributeTermSchema =
  SchemaFactory.createForClass(ProductAttributeTerm);
