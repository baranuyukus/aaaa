import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { User } from './user.schema';

@Schema({
  timestamps: true,
})
export class SellerPayment {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  createdBy: User;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  seller: User;

  @Prop({ required: false })
  products: object[];

  @Prop({
    type: String,
    required: true,
  })
  status: string;

  @Prop({
    type: String,
    required: true,
  })
  method: string;

  @Prop({
    type: Number,
    required: true,
  })
  amount: number;

  @Prop({ required: false })
  timelines: object[];
}

export type SellerPaymentDocument = SellerPayment & Document;

export const SellerPaymentSchema = SchemaFactory.createForClass(SellerPayment);
