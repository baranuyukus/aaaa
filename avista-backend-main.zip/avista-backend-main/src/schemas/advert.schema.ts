import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { User } from './user.schema';
import { ProductGroup } from './product/product-group.schema';
import { ProductAttributeTerm } from './product/product-attribute-term.schema';
import { Category } from './category.schema';

export type AdvertDocument = Advert & Document;

@Schema({
  timestamps: true,
})
export class Advert {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  user: User;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Category.name,
    required: true,
  })
  category: Category;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: ProductGroup.name,
    required: true,
  })
  productGroup: ProductGroup;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: ProductAttributeTerm.name,
    required: true,
  })
  size: ProductAttributeTerm;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: ProductAttributeTerm.name,
    required: false,
  })
  color: ProductAttributeTerm;

  @Prop({
    type: Array,
    ref: ProductAttributeTerm.name,
    required: false,
  })
  terms: ProductAttributeTerm[];

  @Prop({ required: true, type: String, enum: ['SECONDHAND', 'NEW'] })
  usingStatus: string;

  @Prop({ required: false })
  authenticityCode: string;

  @Prop({ type: Number, required: true })
  price: number;

  @Prop({ type: Number, required: true })
  serviceFee: number;

  @Prop({ type: Number, required: true })
  commission: number;

  @Prop({ type: Number, required: true })
  finalAmount: number;

  @Prop({ type: Number, required: false })
  soldPrice: number;

  @Prop({ required: false })
  sku: string;

  @Prop({
    default: 'PENDING',
    enum: [
      'PENDING',
      'SOLD',
      'WAITING_FOR_CARGO',
      'WAITING_FOR_CONTROL',
      'WAITING_FOR_ACCEPT',
      'SHIPPED',
    ],
    type: String,
    required: true,
  })
  status: string;

  @Prop({
    type: Boolean,
    required: true,
    default: false,
  })
  vacationMode: boolean;
}

export const AdvertSchema = SchemaFactory.createForClass(Advert);
