import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type AgreementsDocument = HydratedDocument<Agreements>;

@Schema({
  timestamps: true,
})
export class Agreements {
  @Prop({ type: String, required: true })
  type: string;

  @Prop({ type: String, required: true })
  content: string;
}

export const AgreementsSchema = SchemaFactory.createForClass(Agreements);
