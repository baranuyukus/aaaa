import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({
  timestamps: true,
})
export class Payment {
  @Prop({ type: Object, required: true })
  sendData: object;

  @Prop({ type: Object, required: true })
  resultData: object;
}

export type PaymentDocument = Payment & Document;

const PaymentSchema = SchemaFactory.createForClass(Payment);

export { PaymentSchema };
