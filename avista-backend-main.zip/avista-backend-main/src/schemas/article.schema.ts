import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type ArticleDocument = HydratedDocument<Article>;

@Schema({
  timestamps: true,
})
export class Article {
  @Prop({ type: String, required: true })
  cover: string;

  @Prop({ type: String, required: true })
  title: string;

  @Prop({ type: String, required: true })
  description: string;

  @Prop({ type: String, required: true })
  content: string;
}

export const ArticleSchema = SchemaFactory.createForClass(Article);
