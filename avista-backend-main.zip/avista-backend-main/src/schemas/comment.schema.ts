import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import {
  ProductGroup,
  ProductGroupDocument,
} from './product/product-group.schema';
import { ObjectId } from '../pipes/parse-object-id.pipe';
import { User, UserDocument } from './user.schema';

@Schema({
  timestamps: true,
})
export class Comment {
  @Prop({
    type: String,
    required: false,
    maxlength: 50,
  })
  title: string;

  @Prop({
    type: String,
    required: true,
    maxlength: 400,
  })
  description: string;

  @Prop({
    type: Number,
    min: 1,
    max: 5,
    default: 1,
    required: false,
  })
  review: number;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: ProductGroup.name,
    required: false,
  })
  productGroup: ProductGroupDocument | ObjectId;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: false })
  user: UserDocument | ObjectId;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: false })
  createdBy: UserDocument | ObjectId;
}

export type CommentDocument = Comment & Document;

const CommentSchema = SchemaFactory.createForClass(Comment);

export { CommentSchema };
