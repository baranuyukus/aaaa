import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { ObjectId } from '../pipes/parse-object-id.pipe';
import { User, UserDocument } from './user.schema';
import { Advert, AdvertDocument } from './advert.schema';

@Schema({
  timestamps: true,
})
export class Offer {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  sender: UserDocument | ObjectId;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: User.name, required: true })
  receiver: UserDocument | ObjectId;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Advert.name,
    required: true,
  })
  advert: AdvertDocument | ObjectId;

  @Prop({
    type: Number,
    required: true,
  })
  price: number;

  @Prop({
    default: 'PENDING',
    enum: ['PENDING', 'DECLINED', 'APPROVED'],
    type: String,
    required: true,
  })
  status: string;
}

export type OfferDocument = Offer & Document;

const OfferSchema = SchemaFactory.createForClass(Offer);

export { OfferSchema };
