import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';
import { Category } from './category.schema';
import { Order } from './order.schema';

@Schema({
  timestamps: true,
})
export class Cargo {
  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: Order.name,
    required: true,
  })
  order: Order;

  @Prop({
    type: String,
    enum: ['USER', 'SUTOK'],
    required: true,
  })
  sender: string;

  @Prop({
    type: String,
    required: true,
  })
  trackingUrl: string;
}

export type CargoDocument = Cargo & Document;

const CargoSchema = SchemaFactory.createForClass(Cargo);

CargoSchema.index({ order: 1, sender: 1 }, { unique: true });

export { CargoSchema };
