import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type AddressDocument = Address & Document;

@Schema()
export class Address {
  @Prop({ type: String })
  user: string;

  @Prop({ type: String })
  address: string;

  @Prop({ type: String })
  city: string;

  @Prop({ type: String })
  district: string;

  @Prop({ type: String })
  street: string;

  @Prop({ type: String })
  addressDefinition: string;

  @Prop({ type: String })
  tcIdentity: string;

  @Prop({ type: String })
  phone: string;

  @Prop({ type: String })
  email: string;

  @Prop({ type: String })
  nameSurname: string;

  @Prop({
    type: String,
    enum: ['Bireysel', 'Kurumsal'],
    default: 'Bireysel',
  })
  typeBilling: string;
}

export const AddressSchema = SchemaFactory.createForClass(Address);
