declare module '@aginix/nestjs-firebase-admin' {
  const FirebaseAdminModule: any;
  type FirebaseMessagingService = any;
}
