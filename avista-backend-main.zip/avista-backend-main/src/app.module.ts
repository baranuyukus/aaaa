import { Module } from '@nestjs/common';
import { AuthModule } from './modules/auth/auth.module';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MediaModule } from './modules/media/media.module';
import { UserModule } from './modules/user/user.module';
import { WebsocketModule } from './modules/websocket/websocket.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { OrderModule } from './modules/order/order.module';
import { PanelModule } from './modules/panel/panel.module';
import { ProductModule } from './modules/product/product.module';
import { BrandModule } from './modules/brand/brand.module';
import { CategoryModule } from './modules/category/category.module';
import { AddressModule } from './modules/address/address.module';
import { CardModule } from './modules/card/card.module';
import { FirebaseAdminModule } from '@aginix/nestjs-firebase-admin';
import { CommentModule } from './modules/comment/comment.module';
import * as admin from 'firebase-admin';
import { OfferModule } from './modules/offer/offer.module';
import { AdvertModule } from './modules/advert/advert.module';
import { NotificationModule } from './modules/notification/notification.module';
import { PaymentModule } from './modules/payment/payment.module';
import { DiscountCouponModule } from './modules/discountcoupon/discountcoupon.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: '.env',
      isGlobal: true,
    }),
    FirebaseAdminModule.forRootAsync({
      useFactory: () => ({
        projectId: 'avista-da469',
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        credential: admin.credential.cert(
          // eslint-disable-next-line @typescript-eslint/no-var-requires
          require('../avista-da469-firebase-adminsdk-t8etf-924371d89c.json'),
        ),
      }),
    }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: configService.get<string>('MONGODB_URI'),
      }),
      inject: [ConfigService],
    }),
    AuthModule,
    UserModule,
    WebsocketModule,
    MediaModule,
    OrderModule,
    PanelModule,
    ProductModule,
    BrandModule,
    CategoryModule,
    AddressModule,
    CardModule,
    CommentModule,
    AdvertModule,
    OfferModule,
    NotificationModule,
    PaymentModule,
    DiscountCouponModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
